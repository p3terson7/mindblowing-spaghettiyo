// Local-only browser diagnostics. No telemetry endpoint, request headers,
// bodies, URLs with queries, storage values, or identities are recorded.
(function installSaphirBrowserPerformance() {
  if (typeof window === "undefined" || typeof performance === "undefined") return;
  let mode = "off";
  try { mode = new URLSearchParams(window.location.search).get("saphirTrace") || "off"; } catch (_) { /* no diagnostics in non-browser harnesses */ }
  let enabled = mode === "summary" || mode === "detailed";
  if (!enabled) return; // no fetch proxy, buffers, timers or diagnostic UI
  const events = [];
  const limit = 20000;
  let dropped = 0;
  const workflows = {};
  let synchronousParent = null;
  function id() {
    return Array.from({ length: 32 }, () => Math.floor(Math.random() * 16).toString(16)).join("");
  }
  const traceId = enabled ? id() : null;
  function event(type, frame, extra = {}) {
    if (!enabled) return;
    if (events.length >= limit) { dropped++; return; }
    events.push({ schemaVersion: 2, source: "browser", event: type, traceId, spanId: frame.id,
      parentSpanId: frame.parentId, operation: frame.name, component: frame.component,
      operationType: frame.type, timestampUtc: new Date().toISOString(), offsetMs: performance.now(), ...extra });
  }
  function begin(name, component = "Browser", type = "function", parent) {
    if (!enabled) return null;
    const frame = { id: id(), parentId: parent || synchronousParent || workflows.dashboard || workflows.bootstrap || workflows.authentication || null,
      name, component, type, start: performance.now() };
    event("span_start", frame);
    return frame;
  }
  function end(frame, status = "success", extra = {}) {
    if (!frame) return;
    const now = performance.now();
    event("span_end", frame, { status, startOffsetMs: frame.start, endOffsetMs: now, durationMs: now - frame.start, ...extra });
  }
  const segments = new Set(["auth", "login", "me", "logout", "change-password", "dashboard", "bootstrap", "sync", "status", "health", "employees", "employee", "review", "projects", "self", "profile", "scripts", "assets"]);
  function safePath(resource) {
    try { return new URL(typeof resource === "string" ? resource : resource.url, window.location.href).pathname.split("/").map(part => !part || segments.has(part) ? part : "{resource}").join("/"); }
    catch (_) { return "/{resource}"; }
  }
  function wrap(name, component, workflow) {
    const original = window[name];
    if (typeof original !== "function" || original.saphirDiagnosticWrapper) return;
    const wrapped = function (...args) {
      if (!enabled) return original.apply(this, args);
      const frame = begin(name, component, workflow ? "workflow" : "function");
      if (workflow) workflows[workflow] = frame.id;
      const previous = synchronousParent;
      synchronousParent = frame.id;
      let value;
      try { value = original.apply(this, args); }
      catch (error) { end(frame, "error"); if (workflow) delete workflows[workflow]; throw error; }
      finally { synchronousParent = previous; }
      const finish = result => {
        end(frame, result === false ? "error" : "success");
        if (workflow) delete workflows[workflow];
        if (workflow === "dashboard" && result !== false) {
          const paint = begin("Dashboard.UsableAfterPaint", "Dashboard", "render", frame.id);
          const raf = window.requestAnimationFrame || (callback => setTimeout(callback, 0));
          raf(() => raf(() => end(paint)));
        }
        return result;
      };
      if (value && typeof value.then === "function") return value.then(finish, error => { end(frame, "error"); if (workflow) delete workflows[workflow]; throw error; });
      return finish(value);
    };
    wrapped.saphirDiagnosticWrapper = true;
    window[name] = wrapped;
  }
  function observeDashboard() {
    if (!enabled) return;
    wrap("refreshDashboardView", "Dashboard", "dashboard");
    for (const name of ["loadDashboardCollections", "fetchEmployeeData", "applyDashboardBootstrap"]) wrap(name, "Dashboard");
    if (mode === "detailed") for (const name of ["renderDashboardOverview", "renderDashboardResponsibleProjects", "renderDashboardApprovalQueue", "renderDashboardActiveSessions", "renderEmployeeEntries", "populateDashboardEmployeeControls", "populateDashboardProjectFilter"]) wrap(name, "Dashboard");
  }
  const originalFetch = window.fetch.bind(window);
  window.fetch = function (resource, options) {
    if (!enabled) return originalFetch(resource, options);
    const frame = begin(`HTTP ${String(options && options.method || resource && resource.method || "GET").toUpperCase()} ${safePath(resource)}`, "Browser.Network", "http");
    try {
      return originalFetch(resource, options).then(response => {
        const backendId = response.headers.get("X-SAPHIR-Trace");
        const correlation = /^[0-9a-f]{32}$/i.test(backendId || "") ? { backendTraceId: backendId } : {};
        end(frame, response.ok ? "success" : "error", { ...correlation, httpStatus: response.status, observation: "request-to-response-headers" });
        return response;
      }, error => { end(frame, error && error.name === "AbortError" ? "cancelled" : "error"); throw error; });
    } catch (error) { end(frame, "error"); throw error; }
  };
  function parseJson(text) {
    if (!enabled) return JSON.parse(text);
    const frame = begin("Browser.ParseJson", "Browser", "json");
    try { const value = JSON.parse(text); end(frame); return value; }
    catch (error) { end(frame, "error"); throw error; }
  }
  function readText(response) {
    if (!enabled) return response.text();
    const frame = begin("Browser.ReadResponseBody", "Browser.Network", "http-body");
    return response.text().then(text => { end(frame); return text; }, error => { end(frame, "error"); throw error; });
  }
  function exportTrace() {
    const navigation = performance.getEntriesByType("navigation")[0];
    const safeNavigation = navigation ? { startTime: navigation.startTime, responseEnd: navigation.responseEnd, domContentLoadedEventEnd: navigation.domContentLoadedEventEnd, loadEventEnd: navigation.loadEventEnd } : null;
    const header = { schemaVersion: 2, source: "browser", event: "browser_summary", traceId, level: mode, dropped, navigation: safeNavigation };
    const text = [header, ...events].map(item => JSON.stringify(item)).join("\n") + "\n";
    const link = document.createElement("a");
    const url = URL.createObjectURL(new Blob([text], { type: "application/x-ndjson" }));
    link.href = url; link.download = `SAPHIR-browser-performance-${traceId}.jsonl`; link.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    return text;
  }
  window.SaphirPerformance = { begin, end, parseJson, readText, observeDashboard, export: exportTrace, enabled: () => enabled };
  if (enabled) {
    const initialize = begin("Browser.ApplicationInitialize", "Browser", "workflow");
    document.addEventListener("DOMContentLoaded", () => {
      wrap("bootstrapApplication", "AppShell", "bootstrap");
      wrap("restoreSession", "Authentication", "authentication");
      wrap("submitLogin", "Authentication", "authentication");
      wrap("applySession", "Authentication");
      wrap("loadAuthenticatedWorkspace", "AppShell");
      const button = document.createElement("button");
      button.type = "button"; button.textContent = "Export performance trace";
      button.className = "btn btn-sm btn-outline-secondary";
      button.style.cssText = "position:fixed;bottom:12px;right:12px;z-index:2000";
      button.addEventListener("click", exportTrace); document.body.appendChild(button);
      end(initialize);
    }, { once: true });
  }
})();

const APP_API_URL_KEY = "saphirAppApiUrl";
const APP_SESSION_KEY = "saphirAppSession";
const APP_THEME_KEY = "saphirAppTheme";
const PRE_SAPHIR_APP_STORAGE_PREFIX = ["over", "timeApp"].join("");
const PRE_SAPHIR_API_URL_KEY = `${PRE_SAPHIR_APP_STORAGE_PREFIX}ApiUrl`;
const PRE_SAPHIR_SESSION_KEY = `${PRE_SAPHIR_APP_STORAGE_PREFIX}Session`;
const PRE_SAPHIR_THEME_KEY = `${PRE_SAPHIR_APP_STORAGE_PREFIX}Theme`;
const APP_SYNC_POLL_VISIBLE_MS = 10000;
const APP_SYNC_POLL_HIDDEN_MS = 30000;
const LEGACY_API_URL_KEYS = [PRE_SAPHIR_API_URL_KEY, "adminApiUrl", "employeeApiUrl"];
const LEGACY_SESSION_KEYS = [PRE_SAPHIR_SESSION_KEY, "adminSession", "employeeSession"];
const ROLE_VIEW_MAP = {
  superAdmin: ["dashboardView", "employeesView", "adminView", "projectsView", "bugReportsView"],
  admin: ["dashboardView", "employeesView", "adminView", "projectsView", "bugReportsView"],
  employee: ["selfView", "bugReportsView"],
};
const MANAGER_VIEW_IDS = ["dashboardView", "employeesView", "adminView", "projectsView"];
const MANAGER_SCRIPT_SOURCE = {
  chart: "assets/vendor/chart.umd.min.js?v=20260603-empty-timeline",
  employees: "scripts/Views/EmployeesView.js?v=20261008-loading-performance-v1-views-20261015-v1-no-dashboard-history-v1-it-v1-punch-ux-v1-gc179-receipt-v1-schedule-icons-v1-entry-notes-layout-v1-calendar-actions-v1-entry-inspector-v2",
  dashboard: "scripts/Views/DashboardView.js?v=20261008-loading-performance-v1-views-20261015-v1-no-history-v1-it-v1-punch-ux-v1-review-ux-v1-entry-notes-layout-v1",
  approvals: "scripts/Views/ApprovalsView.js?v=20261008-loading-performance-v1-views-20261015-v1-money-v1-review-cards-v1-review-pages-v1-no-dashboard-history-v1-it-v1-punch-ux-v1-review-ux-v1-workflow-recovery-v1-card-meta-v1-entry-notes-layout-v1",
  history: "scripts/Views/HistoryView.js?v=20261008-loading-performance-v1-views-20261015-v1-project-audit-v1-review-ux-v1",
  projects: "scripts/Views/ProjectsView.js?v=20261008-loading-performance-v1-projects-lite-v1-period-nav-v1-main-echarts-v1-chart-polish-v1-flat-summary-v1-project-audit-v1-review-ux-v1",
};
const MANAGER_VIEW_SCRIPT_SOURCES = {
  dashboardView: [MANAGER_SCRIPT_SOURCE.dashboard],
  employeesView: [MANAGER_SCRIPT_SOURCE.dashboard, MANAGER_SCRIPT_SOURCE.employees],
  adminView: [MANAGER_SCRIPT_SOURCE.dashboard, MANAGER_SCRIPT_SOURCE.approvals, MANAGER_SCRIPT_SOURCE.history],
  projectsView: [MANAGER_SCRIPT_SOURCE.chart, MANAGER_SCRIPT_SOURCE.projects],
};

function normalizeClientRole(role) {
  const normalized = String(role || "").trim().toLowerCase().replace(/[\s_-]/g, "");
  if (normalized === "superadmin" || normalized === "super") {
    return "superAdmin";
  }
  if (normalized === "admin") {
    return "admin";
  }
  return "employee";
}

function isSuperAdminUser(user = getCurrentUser()) {
  return Boolean(user && normalizeClientRole(user.role) === "superAdmin");
}

function isManagerUser(user = getCurrentUser()) {
  const role = user ? normalizeClientRole(user.role) : "";
  return role === "admin" || role === "superAdmin";
}

function userHasEmployeeWorkspace(user = getCurrentUser()) {
  return Boolean(user && user.employeeCode);
}

function getSyncStateChangeKey(syncState) {
  const changeId = String(syncState && syncState.changeId || "").trim();
  if (changeId) {
    return `id:${changeId}`;
  }

  return [
    String(syncState && syncState.version != null ? syncState.version : 0),
    String(syncState && syncState.updatedAtUtc || ""),
    String(syncState && syncState.category || ""),
    String(syncState && syncState.resource || ""),
  ].join("|");
}

function getStoredTheme() {
  const currentTheme = localStorage.getItem(APP_THEME_KEY);
  if (currentTheme === "system" || currentTheme === "dark" || currentTheme === "light") {
    return currentTheme;
  }

  const previousTheme = localStorage.getItem(PRE_SAPHIR_THEME_KEY);
  if (previousTheme === "dark" || previousTheme === "light") {
    localStorage.setItem(APP_THEME_KEY, previousTheme);
    localStorage.removeItem(PRE_SAPHIR_THEME_KEY);
    return previousTheme;
  }

  return "system";
}

function resolveAppTheme(themeMode) {
  if (themeMode === "dark" || themeMode === "light") {
    return themeMode;
  }

  if (typeof window.matchMedia === "function") {
    return window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
  }

  return "light";
}

function updateThemeToggle(themeMode) {
  const toggleButton = document.getElementById("appThemeToggleButton");
  const toggleText = document.getElementById("appThemeToggleText");
  if (!toggleButton || !toggleText) {
    updateSettingsThemeOptions(themeMode);
    return;
  }

  const themeCycle = ["system", "light", "dark"];
  const currentIndex = Math.max(0, themeCycle.indexOf(themeMode));
  const nextTheme = themeCycle[(currentIndex + 1) % themeCycle.length];
  const icon = toggleButton.querySelector("i");
  if (icon) {
    icon.className = nextTheme === "system"
      ? "fa-solid fa-circle-half-stroke"
      : (nextTheme === "dark" ? "fa-solid fa-moon" : "fa-solid fa-sun");
  }
  toggleText.textContent = t(`theme.${nextTheme}`);
  toggleButton.setAttribute("aria-label", t("theme.label"));
  toggleButton.setAttribute("title", t("theme.label"));
  updateSettingsThemeOptions(themeMode);
}

function updateSettingsThemeOptions(theme) {
  document.querySelectorAll("[data-settings-theme]").forEach(button => {
    const isActive = button.getAttribute("data-settings-theme") === theme;
    button.classList.toggle("active", isActive);
    button.setAttribute("aria-pressed", isActive ? "true" : "false");
  });
}

function applyAppTheme(theme) {
  const themeMode = theme === "system" || theme === "dark" || theme === "light" ? theme : "system";
  const resolvedTheme = resolveAppTheme(themeMode);
  document.documentElement.setAttribute("data-theme", resolvedTheme);
  document.documentElement.setAttribute("data-theme-mode", themeMode);
  localStorage.setItem(APP_THEME_KEY, themeMode);
  updateThemeToggle(themeMode);
  window.dispatchEvent(new CustomEvent("app:theme-changed", {
    detail: {
      theme: resolvedTheme,
      mode: themeMode,
    },
  }));
}

function toggleAppTheme() {
  const themeCycle = ["system", "light", "dark"];
  const currentIndex = Math.max(0, themeCycle.indexOf(getStoredTheme()));
  applyAppTheme(themeCycle[(currentIndex + 1) % themeCycle.length]);
}

const appShellState = {
  nativeFetch: window.fetch.bind(window),
  initialized: false,
  syncTimerId: null,
  lastSyncVersion: null,
  lastSyncChangeKey: null,
  syncRequestInFlight: false,
  getRequestInflight: {},
  scriptLoadPromises: {},
  managerAssetPromisesByView: {},
  viewState: {},
  storedSession: null,
  storedSessionLoaded: false,
  budgetPeriodConfiguration: null,
  compensationBands: [],
  compensationSuggestedBands: [],
};

function loadScriptOnce(source) {
  const absoluteSource = new URL(source, document.baseURI).href;
  if (appShellState.scriptLoadPromises[absoluteSource]) {
    return appShellState.scriptLoadPromises[absoluteSource];
  }

  const existingScript = Array.from(document.scripts || []).find(script => script.src === absoluteSource);
  if (existingScript) {
    const isManagedScript = Boolean(existingScript.getAttribute("data-app-manager-script"));
    const isLoaded = existingScript.getAttribute("data-app-manager-script-loaded") === "true"
      || existingScript.readyState === "loaded"
      || existingScript.readyState === "complete";
    const existingPromise = !isManagedScript || isLoaded
      ? Promise.resolve(existingScript)
      : new Promise((resolve, reject) => {
        const handleLoad = () => {
          existingScript.setAttribute("data-app-manager-script-loaded", "true");
          resolve(existingScript);
        };
        const handleError = () => {
          if (existingScript.parentNode) {
            existingScript.parentNode.removeChild(existingScript);
          }
          const error = new Error(`Unable to load application script: ${source}`);
          error.isManagerAssetLoadError = true;
          reject(error);
        };
        existingScript.addEventListener("load", handleLoad, { once: true });
        existingScript.addEventListener("error", handleError, { once: true });
      });
    appShellState.scriptLoadPromises[absoluteSource] = existingPromise;
    existingPromise.catch(() => {
      if (appShellState.scriptLoadPromises[absoluteSource] === existingPromise) {
        delete appShellState.scriptLoadPromises[absoluteSource];
      }
    });
    return existingPromise;
  }

  const script = document.createElement("script");
  script.src = source;
  script.async = false;
  script.setAttribute("data-app-manager-script", source);

  const loadPromise = new Promise((resolve, reject) => {
    script.onload = () => {
      script.setAttribute("data-app-manager-script-loaded", "true");
      resolve(script);
    };
    script.onerror = () => {
      if (script.parentNode) {
        script.parentNode.removeChild(script);
      }
      const error = new Error(`Unable to load application script: ${source}`);
      error.isManagerAssetLoadError = true;
      reject(error);
    };
    document.head.appendChild(script);
  });

  appShellState.scriptLoadPromises[absoluteSource] = loadPromise;
  loadPromise.catch(() => {
    if (appShellState.scriptLoadPromises[absoluteSource] === loadPromise) {
      delete appShellState.scriptLoadPromises[absoluteSource];
    }
  });
  return loadPromise;
}

function ensureManagerAssetsForView(viewId, user = getCurrentUser()) {
  const isBugReportView = viewId === "bugReportsView";
  if (!isBugReportView && (MANAGER_VIEW_IDS.indexOf(viewId) < 0 || !isManagerUser(user))) {
    return Promise.resolve();
  }

  if (!appShellState.managerAssetPromisesByView[viewId]) {
    const sources = isBugReportView
      ? ["scripts/Views/BugReportsView.js?v=20261008-loading-performance-v1"]
      : (MANAGER_VIEW_SCRIPT_SOURCES[viewId] || []);
    const viewPromise = Promise.all(sources.map(source => loadScriptOnce(source)))
      .then(() => undefined)
      .catch(error => {
        if (appShellState.managerAssetPromisesByView[viewId] === viewPromise) {
          delete appShellState.managerAssetPromisesByView[viewId];
        }
        throw error;
      });
    appShellState.managerAssetPromisesByView[viewId] = viewPromise;
  }

  return appShellState.managerAssetPromisesByView[viewId];
}

function resetViewState() {
  appShellState.viewState = {};
  window.resetGc179Exports?.();
  window.resetSelfPunchUi?.();
  window.cancelEntryRejection?.();
  window.resetReviewHistory?.();
  window.resetReviewWorkspace?.();
  window.resetEmployeesViewData?.();
}

function clearClientLookupCaches() {
  if (typeof clearLookupCaches === "function") {
    clearLookupCaches();
    return;
  }

  if (typeof clearOvertimeEntryLookupCache === "function") {
    clearOvertimeEntryLookupCache();
  }
  if (typeof clearScopedProjectLookupCache === "function") {
    clearScopedProjectLookupCache();
  }
}

function ensureViewState(viewId) {
  if (!appShellState.viewState[viewId]) {
    appShellState.viewState[viewId] = {
      loaded: false,
      stale: true,
      refreshPromise: null,
      lastLoadedAt: null,
    };
  }

  return appShellState.viewState[viewId];
}

function markViewsStale(viewIds) {
  (viewIds || []).forEach(viewId => {
    if (!viewId) {
      return;
    }

    const state = ensureViewState(viewId);
    state.stale = true;
  });
}

function getActiveViewId() {
  return document.querySelector(".view.active")?.id || localStorage.getItem("activeView") || "";
}

function requestViewRefresh(viewIds, options = {}) {
  const affectedViews = Array.isArray(viewIds) ? viewIds.filter(Boolean) : [];
  markViewsStale(affectedViews);

  if (options.refreshActive === false) {
    return Promise.resolve();
  }

  const activeViewId = getActiveViewId();
  if (!activeViewId || affectedViews.indexOf(activeViewId) < 0) {
    return Promise.resolve();
  }

  return refreshViewById(activeViewId, {
    force: !!options.forceActive,
  });
}

function markAllowedViewsStale(user) {
  markViewsStale(getAllowedViewsForUser(user));
}

function getViewsAffectedBySyncState(syncState) {
  const user = getCurrentUser();
  const category = String(syncState && syncState.category || "").toLowerCase();
  const resource = String(syncState && syncState.resource || "");

  if (!user) {
    return [];
  }

  if (category === "seed") {
    return getAllowedViewsForUser(user);
  }
  if (category === "sessions") {
    // /sync/status has already authenticated this session. Session lifecycle
    // events do not change hours or permissions; auth events remain separate.
    return [];
  }

  if (category === "history") {
    return [];
  }

  if (category === "bug-reports") {
    return ["bugReportsView"];
  }

  if (category === "employee-directory") {
    return isManagerUser(user)
      ? ["dashboardView", "employeesView", "adminView"]
      : [];
  }

  if (category === "project") {
    return isManagerUser(user)
      ? ["dashboardView", "projectsView", "adminView", "employeesView"]
      : ["selfView"];
  }

  if (category === "auth") {
    if (isManagerUser(user)) {
      return ["employeesView", "adminView"];
    }

    return resource && user.employeeCode === resource
      ? ["selfView"]
      : [];
  }

  if (category === "employee") {
    if (isManagerUser(user)) {
      const affectedViews = ["dashboardView", "employeesView", "adminView", "projectsView"].filter(view =>
        view !== "employeesView" || typeof window === "undefined" || typeof window.employeeDirectoryNeedsEntryRefresh !== "function" || window.employeeDirectoryNeedsEntryRefresh());
      if (userHasEmployeeWorkspace(user) && (resource === "*" || user.employeeCode === resource)) {
        affectedViews.push("selfView");
      }
      return affectedViews;
    }

    return resource && (resource === "*" || user.employeeCode === resource)
      ? ["selfView"]
      : [];
  }

  return getAllowedViewsForUser(user);
}

function normalizeApiUrl(value, fallbackValue) {
  const rawValue = String(value || fallbackValue || "").trim();
  if (!rawValue) {
    return "";
  }

  return rawValue.endsWith("/") ? rawValue : `${rawValue}/`;
}

function upgradeLegacyEmployeeApiUrl(value) {
  if (!value) {
    return value;
  }

  try {
    const parsed = new URL(value, window.location.href);
    const isLocalHost = parsed.hostname === "localhost" || parsed.hostname === "127.0.0.1";
    if (isLocalHost && parsed.port === "8080") {
      parsed.port = "8081";
      return parsed.toString();
    }
  } catch (error) {
    return value;
  }

  return value;
}

function getStoredApiUrl() {
  const currentValue = localStorage.getItem(APP_API_URL_KEY);
  if (currentValue) {
    return normalizeApiUrl(currentValue, window.defaultApiUrl);
  }

  const previousAppUrl = localStorage.getItem(PRE_SAPHIR_API_URL_KEY);
  if (previousAppUrl) {
    const migratedUrl = normalizeApiUrl(previousAppUrl, window.defaultApiUrl);
    localStorage.setItem(APP_API_URL_KEY, migratedUrl);
    localStorage.removeItem(PRE_SAPHIR_API_URL_KEY);
    return migratedUrl;
  }

  const legacyAdminUrl = localStorage.getItem("adminApiUrl");
  if (legacyAdminUrl) {
    return normalizeApiUrl(legacyAdminUrl, window.defaultApiUrl);
  }

  const legacyEmployeeUrl = localStorage.getItem("employeeApiUrl");
  if (legacyEmployeeUrl) {
    return normalizeApiUrl(upgradeLegacyEmployeeApiUrl(legacyEmployeeUrl), window.defaultApiUrl);
  }

  return normalizeApiUrl(window.defaultApiUrl, window.defaultApiUrl);
}

function updateConnectionDisplay() {
  const apiInput = document.getElementById("apiUrlInput");

  if (apiInput) {
    apiInput.value = window.apiUrl;
  }
}

function setStoredApiUrl(value) {
  window.apiUrl = normalizeApiUrl(value, window.defaultApiUrl);
  localStorage.setItem(APP_API_URL_KEY, window.apiUrl);
  LEGACY_API_URL_KEYS.forEach(key => localStorage.removeItem(key));
  updateConnectionDisplay();
}

function tryReadSession(key) {
  try {
    const rawValue = localStorage.getItem(key);
    return rawValue ? JSON.parse(rawValue) : null;
  } catch (error) {
    return null;
  }
}

function getStoredSession() {
  if (appShellState.storedSessionLoaded) {
    return appShellState.storedSession;
  }

  const keysToCheck = [APP_SESSION_KEY].concat(LEGACY_SESSION_KEYS);
  for (const key of keysToCheck) {
    const session = tryReadSession(key);
    if (session && session.token && session.user) {
      if (key !== APP_SESSION_KEY) {
        try {
          localStorage.setItem(APP_SESSION_KEY, JSON.stringify(session));
          LEGACY_SESSION_KEYS.forEach(legacyKey => localStorage.removeItem(legacyKey));
        } catch (error) {
          // The in-memory session remains usable when browser storage is restricted.
        }
      }
      appShellState.storedSession = session;
      appShellState.storedSessionLoaded = true;
      return session;
    }
  }

  appShellState.storedSession = null;
  appShellState.storedSessionLoaded = true;
  return null;
}

function setStoredSession(session) {
  appShellState.storedSession = session;
  appShellState.storedSessionLoaded = true;
  localStorage.setItem(APP_SESSION_KEY, JSON.stringify(session));
  LEGACY_SESSION_KEYS.forEach(key => localStorage.removeItem(key));
}

function clearStoredSession() {
  appShellState.storedSession = null;
  appShellState.storedSessionLoaded = true;
  localStorage.removeItem(APP_SESSION_KEY);
  LEGACY_SESSION_KEYS.forEach(key => localStorage.removeItem(key));
}

function getSessionToken() {
  const session = getStoredSession();
  return session && session.token ? session.token : null;
}

function getCurrentApiUrl() {
  return normalizeApiUrl(window.apiUrl || getStoredApiUrl(), window.defaultApiUrl);
}

function getFetchTargetUrl(resource) {
  if (typeof resource === "string") {
    return resource;
  }

  if (resource && typeof resource.url === "string") {
    return resource.url;
  }

  if (resource && typeof resource.href === "string") {
    return resource.href;
  }

  return "";
}

function getBearerTokenFromHeader(headerValue) {
  const match = String(headerValue || "").match(/^Bearer\s+(.+)$/i);
  return match ? match[1].trim() : null;
}

function isApiRequestUrl(targetUrl, routePrefix) {
  const activeApiUrl = getCurrentApiUrl();
  if (!targetUrl || !activeApiUrl) {
    return false;
  }

  try {
    const requestUrl = new URL(targetUrl, window.location.href);
    const apiBaseUrl = new URL(activeApiUrl, window.location.href);
    if (requestUrl.origin !== apiBaseUrl.origin) {
      return false;
    }

    const basePath = apiBaseUrl.pathname.endsWith("/") ? apiBaseUrl.pathname : `${apiBaseUrl.pathname}/`;
    if (basePath !== "/" && requestUrl.pathname.indexOf(basePath) !== 0 && requestUrl.pathname !== apiBaseUrl.pathname) {
      return false;
    }

    if (!routePrefix) {
      return true;
    }

    const relativePath = basePath === "/"
      ? requestUrl.pathname.replace(/^\//, "")
      : requestUrl.pathname.slice(basePath.length);
    return relativePath.indexOf(routePrefix) === 0;
  } catch (error) {
    const normalizedApiUrl = normalizeApiUrl(activeApiUrl, window.defaultApiUrl);
    if (String(targetUrl).indexOf(normalizedApiUrl) !== 0) {
      return false;
    }

    return routePrefix
      ? String(targetUrl).indexOf(normalizedApiUrl + routePrefix) === 0
      : true;
  }
}

function getCurrentUser() {
  const session = getStoredSession();
  return session && session.user ? session.user : null;
}

function setSyncStatus(message) {
  const syncElement = document.getElementById("appSyncStatus");
  if (syncElement) {
    syncElement.textContent = message;
  }
}

function formatAppDateTime(value) {
  if (!value) {
    return "";
  }

  const date = new Date(value);
  if (Number.isNaN(date.getTime())) {
    return "";
  }

  const locale = typeof getI18nLocale === "function" ? getI18nLocale() : undefined;
  return date.toLocaleString(locale, {
    month: "short",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
  });
}

function setLastSyncStatus(syncState) {
  const syncElement = document.getElementById("appLastSyncStatus");
  if (!syncElement) {
    return;
  }

  const timestamp = syncState && syncState.updatedAtUtc ? syncState.updatedAtUtc : "";
  const formattedTimestamp = formatAppDateTime(timestamp);
  syncElement.textContent = formattedTimestamp
    ? t("status.lastSyncAt", { time: formattedTimestamp })
    : t("status.lastSyncNever");
}

function renderSettingsHealthLoading() {
  const panel = document.getElementById("settingsHealthPanel");
  if (panel) {
    panel.innerHTML = `<span class="panel-note">${escapeHtml(t("settings.healthLoading"))}</span>`;
  }
}

function renderSettingsHealthError(message) {
  const panel = document.getElementById("settingsHealthPanel");
  if (panel) {
    panel.innerHTML = `<span class="panel-note">${escapeHtml(message || t("settings.healthUnavailable"))}</span>`;
  }
}

function renderSettingsHealth(payload) {
  const panel = document.getElementById("settingsHealthPanel");
  if (!panel) {
    return;
  }

  const status = String(payload && payload.status || "warning").toLowerCase();
  const statusLabel = status === "ok" ? t("settings.healthOk") : t("settings.healthWarning");
  const syncVersion = payload && payload.sync && payload.sync.version != null ? String(payload.sync.version) : "-";
  const rows = [
    [t("settings.healthDataFolder"), payload && payload.dataFolder ? payload.dataFolder : "-"],
    [t("settings.healthWritable"), payload && payload.dataFolderWritable ? t("settings.healthOk") : t("settings.healthWarning")],
    [t("settings.healthPowerShell"), payload && payload.powershell ? payload.powershell : "-"],
    [t("settings.healthUsers"), payload && payload.usersCount != null ? String(payload.usersCount) : "-"],
    [t("settings.healthProjects"), payload && payload.projectsCount != null ? String(payload.projectsCount) : "-"],
    [t("settings.healthSync"), syncVersion],
    [t("settings.healthGc179"), payload && payload.gc179Template && payload.gc179Template.exists ? t("settings.healthOk") : t("settings.healthWarning")],
  ];

  const checks = Array.isArray(payload && payload.checks) ? payload.checks : [];
  panel.innerHTML = `
    <div class="settings-health-summary">
      <span class="status-badge ${status === "ok" ? "approved" : "pending"}">${escapeHtml(statusLabel)}</span>
      <span class="panel-note">${escapeHtml(formatAppDateTime(payload && payload.serverTimeUtc))}</span>
    </div>
    <details class="settings-health-details">
      <summary>${escapeHtml(t("settings.healthDetails"))}</summary>
      <dl class="settings-health-grid">
        ${rows.map(([label, value]) => `
          <div class="settings-health-item">
            <dt class="settings-health-label">${escapeHtml(label)}</dt>
            <dd class="settings-health-value">${escapeHtml(value)}</dd>
          </div>
        `).join("")}
      </dl>
      ${checks.length > 0 ? `
        <div class="settings-health-checks">
          ${checks.map(check => {
            const isOk = Boolean(check?.ok);
            const label = check?.label || "";
            const detail = check?.detail || "";
            return `
              <div class="settings-health-check ${isOk ? "is-ok" : "is-warning"}">
                <i class="fa-solid ${isOk ? "fa-check" : "fa-triangle-exclamation"}" aria-hidden="true"></i>
                <span>${escapeHtml(label)}${detail && detail !== payload?.dataFolder ? ` · ${escapeHtml(detail)}` : ""}</span>
              </div>
            `;
          }).join("")}
        </div>
      ` : ""}
    </details>
  `;
}

async function loadSettingsHealth(triggerButton) {
  if (!getSessionToken()) {
    return;
  }

  const loadHealth = async () => {
    renderSettingsHealthLoading();
    try {
      const response = await fetch(apiUrl + "health");
      const payload = await parseResponse(response);
      renderSettingsHealth(payload);
    } catch (error) {
      renderSettingsHealthError(error.message || t("settings.healthUnavailable"));
    }
  };

  return triggerButton
    ? runButtonAction(triggerButton, loadHealth, { key: "settings-health" })
    : loadHealth();
}

const BUDGET_PERIOD_ENDPOINT = "budget-periods";
const DEFAULT_BUDGET_PERIOD_COUNT = 12;
const MAX_BUDGET_PERIOD_COUNT = 60;

function getBudgetPeriodNumber(id) {
  const match = /^P([1-9][0-9]{0,2})$/i.exec(String(id || "").trim());
  return match ? Number(match[1]) : Number.MAX_SAFE_INTEGER;
}

function createDefaultBudgetPeriods(count = DEFAULT_BUDGET_PERIOD_COUNT) {
  return Array.from({ length: count }, (_, index) => ({
    id: `P${index + 1}`,
    startDate: "",
    endDate: "",
  }));
}

function setBudgetPeriodSettingsMessage(message, type) {
  const messageBox = document.getElementById("budgetPeriodSettingsMessage");
  if (!messageBox) {
    return;
  }

  if (!message) {
    messageBox.className = "alert d-none";
    messageBox.textContent = "";
    return;
  }

  messageBox.className = `alert alert-${type || "danger"}`;
  messageBox.textContent = message;
}

function normalizeBudgetPeriodConfiguration(payload) {
  const sourcePeriods = payload && Array.isArray(payload.periods) ? payload.periods : [];
  const normalizedSource = sourcePeriods
    .map(period => ({
      id: String(period && period.id || "").trim().toUpperCase(),
      startDate: normalizeCompensationGridDate(period && period.startDate),
      endDate: normalizeCompensationGridDate(period && period.endDate),
    }))
    .filter(period => getBudgetPeriodNumber(period.id) !== Number.MAX_SAFE_INTEGER)
    .sort((left, right) => getBudgetPeriodNumber(left.id) - getBudgetPeriodNumber(right.id));
  return {
    schemaVersion: 2,
    cycleLabel: String(payload && payload.cycleLabel || "").trim().slice(0, 80),
    periods: normalizedSource.length > 0 ? normalizedSource : createDefaultBudgetPeriods(),
  };
}

function renderBudgetPeriodSettings(configuration) {
  const normalized = normalizeBudgetPeriodConfiguration(configuration);
  appShellState.budgetPeriodConfiguration = normalized;
  const cycleLabelInput = document.getElementById("budgetPeriodCycleLabelInput");
  const rows = document.getElementById("budgetPeriodSettingsRows");
  if (cycleLabelInput) {
    cycleLabelInput.value = normalized.cycleLabel;
  }
  const generatorCountInput = document.getElementById("budgetPeriodGeneratorCount");
  if (generatorCountInput && !generatorCountInput.value) {
    generatorCountInput.value = String(DEFAULT_BUDGET_PERIOD_COUNT);
  }
  const firstConfiguredPeriod = normalized.periods.find(period => period.startDate);
  const generatorMonthInput = document.getElementById("budgetPeriodGeneratorStartMonth");
  const generatorDayInput = document.getElementById("budgetPeriodGeneratorDay");
  if (firstConfiguredPeriod && generatorMonthInput && generatorDayInput) {
    generatorMonthInput.value = firstConfiguredPeriod.startDate.slice(0, 7);
    generatorDayInput.value = String(Number(firstConfiguredPeriod.startDate.slice(8, 10)));
  } else if (generatorMonthInput && !generatorMonthInput.value) {
    const now = new Date();
    generatorMonthInput.value = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}`;
  }
  if (!rows) {
    return;
  }

  rows.innerHTML = normalized.periods.map(period => `
    <tr data-budget-period-id="${period.id}">
      <th scope="row"><span class="budget-period-id">${period.id}</span></th>
      <td><input type="date" class="form-control form-control-sm budget-period-start-input" value="${escapeHtml(period.startDate)}" aria-label="${escapeHtml(t("settings.budgetStartDateFor", { period: period.id }))}"></td>
      <td><input type="date" class="form-control form-control-sm budget-period-end-input" value="${escapeHtml(period.endDate)}" aria-label="${escapeHtml(t("settings.budgetEndDateFor", { period: period.id }))}"></td>
      <td class="budget-period-row-actions"><button type="button" class="btn btn-outline-danger btn-sm budget-period-remove-button" data-budget-period-remove="${period.id}" aria-label="${escapeHtml(t("settings.budgetRemovePeriod", { period: period.id }))}" title="${escapeHtml(t("settings.budgetRemovePeriod", { period: period.id }))}"${normalized.periods.length === 1 ? " disabled" : ""}><i class="fa-solid fa-trash-can" aria-hidden="true"></i></button></td>
    </tr>
  `).join("");
}

function renderBudgetPeriodSettingsLoading() {
  const rows = document.getElementById("budgetPeriodSettingsRows");
  if (rows) {
    rows.innerHTML = `<tr><td colspan="4" class="budget-period-empty">${escapeHtml(t("settings.budgetLoading"))}</td></tr>`;
  }
}

function getBudgetPeriodConfigurationFromForm() {
  const rows = document.getElementById("budgetPeriodSettingsRows");
  const cycleLabelInput = document.getElementById("budgetPeriodCycleLabelInput");
  return {
    schemaVersion: 2,
    cycleLabel: String(cycleLabelInput && cycleLabelInput.value || "").trim().slice(0, 80),
    periods: Array.from(rows ? rows.querySelectorAll("[data-budget-period-id]") : []).map(row => {
      const id = String(row.getAttribute("data-budget-period-id") || "").trim().toUpperCase();
      return {
        id,
        startDate: normalizeCompensationGridDate(row && row.querySelector(".budget-period-start-input")?.value),
        endDate: normalizeCompensationGridDate(row && row.querySelector(".budget-period-end-input")?.value),
      };
    }),
  };
}

function addBudgetPeriod() {
  const configuration = getBudgetPeriodConfigurationFromForm();
  if (configuration.periods.length >= MAX_BUDGET_PERIOD_COUNT) {
    setBudgetPeriodSettingsMessage(t("settings.budgetPeriodLimit", { count: MAX_BUDGET_PERIOD_COUNT }), "warning");
    return;
  }

  const nextNumber = configuration.periods.reduce((highest, period) => Math.max(highest, getBudgetPeriodNumber(period.id)), 0) + 1;
  configuration.periods.push({ id: `P${nextNumber}`, startDate: "", endDate: "" });
  renderBudgetPeriodSettings(configuration);
  setBudgetPeriodSettingsMessage("");
  document.querySelector(`[data-budget-period-id="P${nextNumber}"] .budget-period-start-input`)?.focus();
}

function removeBudgetPeriod(id) {
  const configuration = getBudgetPeriodConfigurationFromForm();
  if (configuration.periods.length <= 1) {
    setBudgetPeriodSettingsMessage(t("settings.budgetKeepOneConfiguredPeriod"), "warning");
    return;
  }
  configuration.periods = configuration.periods.filter(period => period.id !== id);
  renderBudgetPeriodSettings(configuration);
  setBudgetPeriodSettingsMessage("");
}

function formatBudgetPeriodDate(date) {
  return `${date.getUTCFullYear()}-${String(date.getUTCMonth() + 1).padStart(2, "0")}-${String(date.getUTCDate()).padStart(2, "0")}`;
}

function getMonthlyBudgetBoundary(year, monthIndex, requestedDay) {
  const lastDay = new Date(Date.UTC(year, monthIndex + 1, 0)).getUTCDate();
  return new Date(Date.UTC(year, monthIndex, Math.min(requestedDay, lastDay)));
}

function createMonthlyBudgetPeriods(startYear, startMonthIndex, requestedDay, count) {
  return Array.from({ length: count }, (_, index) => {
    const start = getMonthlyBudgetBoundary(startYear, startMonthIndex + index, requestedDay);
    const nextStart = getMonthlyBudgetBoundary(startYear, startMonthIndex + index + 1, requestedDay);
    const end = new Date(nextStart.getTime() - 86400000);
    return { id: `P${index + 1}`, startDate: formatBudgetPeriodDate(start), endDate: formatBudgetPeriodDate(end) };
  });
}

function generateMonthlyBudgetPeriods() {
  const monthInput = document.getElementById("budgetPeriodGeneratorStartMonth");
  const dayInput = document.getElementById("budgetPeriodGeneratorDay");
  const countInput = document.getElementById("budgetPeriodGeneratorCount");
  const monthMatch = /^(\d{4})-(\d{2})$/.exec(String(monthInput && monthInput.value || ""));
  const requestedDay = Number(dayInput && dayInput.value);
  const count = Number(countInput && countInput.value);
  if (!monthMatch || !Number.isInteger(requestedDay) || requestedDay < 1 || requestedDay > 31 || !Number.isInteger(count) || count < 1 || count > MAX_BUDGET_PERIOD_COUNT) {
    setBudgetPeriodSettingsMessage(t("settings.budgetGeneratorInvalid"), "danger");
    return;
  }

  const startYear = Number(monthMatch[1]);
  const startMonthIndex = Number(monthMatch[2]) - 1;
  const periods = createMonthlyBudgetPeriods(startYear, startMonthIndex, requestedDay, count);

  const configuration = getBudgetPeriodConfigurationFromForm();
  configuration.periods = periods;
  renderBudgetPeriodSettings(configuration);
  setBudgetPeriodSettingsMessage(t("settings.budgetGeneratorReady", { count }), "success");
}

function getBudgetPeriodValidationError(configuration) {
  const periods = configuration && Array.isArray(configuration.periods) ? configuration.periods : [];
  if (periods.length === 0) {
    return t("settings.budgetKeepOneConfiguredPeriod");
  }
  let previousConfiguredPeriod = null;
  for (const period of periods) {
    const hasStart = Boolean(period.startDate);
    const hasEnd = Boolean(period.endDate);
    if (hasStart !== hasEnd) {
      return t("settings.budgetBothDatesRequired", { period: period.id });
    }
    if (!hasStart) {
      continue;
    }
    if (period.endDate < period.startDate) {
      return t("settings.budgetInvalidDateRange", { period: period.id });
    }
    if (previousConfiguredPeriod && period.startDate <= previousConfiguredPeriod.endDate) {
      return t("settings.budgetPeriodsOverlap", { period: period.id, previous: previousConfiguredPeriod.id });
    }
    previousConfiguredPeriod = period;
  }
  return "";
}

async function loadBudgetPeriods() {
  if (!getSessionToken() || !isSuperAdminUser()) {
    return;
  }

  setBudgetPeriodSettingsMessage("");
  renderBudgetPeriodSettingsLoading();
  try {
    const response = await fetch(apiUrl + BUDGET_PERIOD_ENDPOINT, { cache: "no-store" });
    const payload = await parseResponse(response);
    renderBudgetPeriodSettings(payload);
  } catch (error) {
    renderBudgetPeriodSettings({ periods: [] });
    setBudgetPeriodSettingsMessage(error.message || t("settings.budgetLoadError"), "warning");
  }
}

async function saveBudgetPeriods(triggerButton) {
  if (!isSuperAdminUser()) {
    return;
  }

  const configuration = getBudgetPeriodConfigurationFromForm();
  const validationError = getBudgetPeriodValidationError(configuration);
  if (validationError) {
    setBudgetPeriodSettingsMessage(validationError, "danger");
    return;
  }

  setBudgetPeriodSettingsMessage("");
  const saveButton = triggerButton || document.getElementById("budgetPeriodSaveButton");
  const savePeriods = async () => {
    try {
      const response = await fetch(apiUrl + BUDGET_PERIOD_ENDPOINT, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(configuration),
      });
      const payload = await parseResponse(response);
      renderBudgetPeriodSettings(payload);
      showToast(t("settings.budgetSaveSuccess"), "success");
    } catch (error) {
      setBudgetPeriodSettingsMessage(error.message || t("settings.budgetSaveError"), "danger");
    }
  };

  return runButtonAction(saveButton, savePeriods, {
    key: "budget-period-save",
    disableWhileRunning: () => document.querySelectorAll("#budgetPeriodSettingsSection input, #budgetPeriodSettingsSection button"),
  });
}

const COMPENSATION_GRID_ENDPOINT = "compensation-grid";

function getCompensationGridSettingsRowsElement() {
  return document.getElementById("compensationGridSettingsRows");
}

function setCompensationGridSettingsMessage(message, type) {
  const messageBox = document.getElementById("compensationGridSettingsMessage");
  if (!messageBox) {
    return;
  }

  if (!message) {
    messageBox.className = "alert d-none";
    messageBox.textContent = "";
    return;
  }

  messageBox.className = `alert alert-${type || "danger"}`;
  messageBox.textContent = message;
}

function normalizeCompensationGridCode(value, maximumLength) {
  const normalized = String(value || "")
    .trim()
    .toUpperCase()
    .replace(/\s+/g, "")
    .slice(0, maximumLength);

  return /^[0-9A-Z._/-]*$/.test(normalized) ? normalized : "";
}

function normalizeCompensationGroupCode(value) {
  return String(value || "").trim().toUpperCase();
}

function normalizeCompensationTwoDigitCode(value) {
  const text = String(value || "").trim();
  return /^[0-9]{1,2}$/.test(text) ? text.padStart(2, "0") : text;
}

function normalizeCompensationGridDate(value) {
  const text = String(value || "").trim();
  if (!/^\d{4}-\d{2}-\d{2}$/.test(text)) {
    return "";
  }

  const [year, month, day] = text.split("-").map(Number);
  const candidate = new Date(Date.UTC(year, month - 1, day));
  return candidate.getUTCFullYear() === year
    && candidate.getUTCMonth() === month - 1
    && candidate.getUTCDate() === day
    ? text
    : "";
}

function parseCompensationAnnualSalaryCents(value) {
  let text = String(value == null ? "" : value)
    .trim()
    .replace(/\bCAD\b/gi, "")
    .replace(/[\s\u00a0$]/g, "");
  if (!text || !/^[0-9.,]+$/.test(text)) {
    return null;
  }

  const lastComma = text.lastIndexOf(",");
  const lastPeriod = text.lastIndexOf(".");
  const lastSeparator = Math.max(lastComma, lastPeriod);
  let normalized = text;
  if (lastComma >= 0 && lastPeriod >= 0) {
    const decimalSeparator = lastComma > lastPeriod ? "," : ".";
    const thousandsSeparator = decimalSeparator === "," ? "." : ",";
    normalized = text.replace(new RegExp(`\\${thousandsSeparator}`, "g"), "").replace(decimalSeparator, ".");
  } else if (lastSeparator >= 0) {
    const decimalDigits = text.length - lastSeparator - 1;
    if (decimalDigits > 0 && decimalDigits <= 2) {
      normalized = text.replace(text.charAt(lastSeparator), ".");
    } else {
      normalized = text.replace(/[.,]/g, "");
    }
  }

  if (!/^\d+(?:\.\d{1,2})?$/.test(normalized)) {
    return null;
  }

  const dollars = Number(normalized);
  const cents = Math.round(dollars * 100);
  return Number.isSafeInteger(cents) && cents > 0 ? cents : null;
}

function formatCompensationAnnualSalaryCents(value) {
  const cents = Number(value);
  if (!Number.isSafeInteger(cents) || cents <= 0) {
    return "";
  }

  const locale = typeof getI18nLocale === "function" ? getI18nLocale() : "en-CA";
  return new Intl.NumberFormat(locale, {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(cents / 100);
}

function createCompensationBandId() {
  if (window.crypto && typeof window.crypto.randomUUID === "function") {
    return window.crypto.randomUUID();
  }

  return `band-${Date.now()}-${Math.random().toString(36).slice(2, 12)}`;
}

function createEmptyCompensationBand() {
  return {
    id: createCompensationBandId(),
    group: "",
    subGroup: "",
    level: "",
    annualSalaryCents: "",
    effectiveFrom: "",
    effectiveTo: "",
  };
}

function normalizeCompensationBandForDisplay(band) {
  const source = band && typeof band === "object" ? band : {};
  const cents = Number(source.annualSalaryCents);
  const annualSalaryCents = Number.isSafeInteger(cents) && cents > 0
    ? cents
    : parseCompensationAnnualSalaryCents(source.annualSalary);
  return {
    id: String(source.id || "").trim() || createCompensationBandId(),
    group: normalizeCompensationGroupCode(source.group),
    subGroup: normalizeCompensationTwoDigitCode(source.subGroup),
    level: normalizeCompensationTwoDigitCode(source.level),
    annualSalaryCents: annualSalaryCents || "",
    effectiveFrom: normalizeCompensationGridDate(source.effectiveFrom),
    effectiveTo: normalizeCompensationGridDate(source.effectiveTo),
  };
}

function getCompensationGridPayloadBands(payload) {
  if (Array.isArray(payload)) {
    return payload;
  }
  if (payload && Array.isArray(payload.bands)) {
    return payload.bands;
  }
  return [];
}

function renderCompensationGridSettingsRows(bands) {
  const rowsElement = getCompensationGridSettingsRowsElement();
  if (!rowsElement) {
    return;
  }

  const normalizedBands = Array.isArray(bands) ? bands.map(normalizeCompensationBandForDisplay) : [];
  appShellState.compensationBands = normalizedBands;
  if (normalizedBands.length === 0) {
    rowsElement.innerHTML = `<tr class="compensation-grid-empty"><td colspan="7">${escapeHtml(t("settings.compensationEmpty"))}</td></tr>`;
    return;
  }

  rowsElement.innerHTML = normalizedBands.map(band => `
    <tr data-compensation-band-id="${escapeHtml(band.id)}">
      <td><input type="text" class="form-control form-control-sm compensation-grid-group-input" value="${escapeHtml(band.group)}" maxlength="6" pattern="[A-Za-z]+" autocomplete="off" autocapitalize="characters" spellcheck="false" aria-label="${escapeHtml(t("settings.compensationGroup"))}"></td>
      <td><input type="text" class="form-control form-control-sm compensation-grid-sub-group-input" value="${escapeHtml(band.subGroup)}" maxlength="2" pattern="[0-9]{2}" inputmode="numeric" autocomplete="off" spellcheck="false" aria-label="${escapeHtml(t("settings.compensationSubGroup"))}"></td>
      <td><input type="text" class="form-control form-control-sm compensation-grid-level-input" value="${escapeHtml(band.level)}" maxlength="2" pattern="[0-9]{2}" inputmode="numeric" autocomplete="off" spellcheck="false" aria-label="${escapeHtml(t("settings.compensationLevel"))}"></td>
      <td><input type="text" class="form-control form-control-sm compensation-grid-salary-input" value="${escapeHtml(formatCompensationAnnualSalaryCents(band.annualSalaryCents))}" inputmode="decimal" autocomplete="off" aria-label="${escapeHtml(t("settings.compensationAnnualSalary"))}"></td>
      <td><input type="date" class="form-control form-control-sm compensation-grid-date-input compensation-grid-effective-from-input" value="${escapeHtml(band.effectiveFrom)}" aria-label="${escapeHtml(t("settings.compensationEffectiveFrom"))}"></td>
      <td><input type="date" class="form-control form-control-sm compensation-grid-date-input compensation-grid-effective-to-input" value="${escapeHtml(band.effectiveTo)}" aria-label="${escapeHtml(t("settings.compensationEffectiveTo"))}"></td>
      <td><button type="button" class="btn btn-outline-danger btn-sm compensation-grid-remove-button" data-compensation-remove-band="${escapeHtml(band.id)}" aria-label="${escapeHtml(t("action.remove"))}" title="${escapeHtml(t("action.remove"))}"><i class="fa-solid fa-trash-can" aria-hidden="true"></i></button></td>
    </tr>
  `).join("");

  rowsElement.querySelectorAll("[data-compensation-remove-band]").forEach(button => {
    button.addEventListener("click", () => {
      const id = String(button.getAttribute("data-compensation-remove-band") || "");
      const formBands = getCompensationGridBandsFromForm();
      const currentBands = formBands.length > 0 ? formBands : appShellState.compensationBands;
      renderCompensationGridSettingsRows(currentBands.filter(band => band.id !== id));
    });
  });

  rowsElement.querySelectorAll(".compensation-grid-group-input").forEach(input => {
    input.addEventListener("input", () => {
      input.value = normalizeCompensationGroupCode(input.value);
    });
  });
  rowsElement.querySelectorAll(".compensation-grid-sub-group-input, .compensation-grid-level-input").forEach(input => {
    input.addEventListener("blur", () => {
      input.value = normalizeCompensationTwoDigitCode(input.value);
    });
  });
}

function renderCompensationGridLoading() {
  const rowsElement = getCompensationGridSettingsRowsElement();
  if (rowsElement) {
    rowsElement.innerHTML = `<tr class="compensation-grid-empty"><td colspan="7">${escapeHtml(t("settings.compensationLoading"))}</td></tr>`;
  }
}

function getCompensationGridBandsFromForm() {
  const rowsElement = getCompensationGridSettingsRowsElement();
  if (!rowsElement) {
    return [];
  }

  return Array.from(rowsElement.querySelectorAll("tr[data-compensation-band-id]")).map(row => ({
    id: String(row.getAttribute("data-compensation-band-id") || "").trim(),
    group: normalizeCompensationGroupCode(row.querySelector(".compensation-grid-group-input").value),
    subGroup: normalizeCompensationTwoDigitCode(row.querySelector(".compensation-grid-sub-group-input").value),
    level: normalizeCompensationTwoDigitCode(row.querySelector(".compensation-grid-level-input").value),
    annualSalaryCents: parseCompensationAnnualSalaryCents(row.querySelector(".compensation-grid-salary-input").value),
    effectiveFrom: normalizeCompensationGridDate(row.querySelector(".compensation-grid-effective-from-input").value),
    effectiveTo: normalizeCompensationGridDate(row.querySelector(".compensation-grid-effective-to-input").value),
  }));
}

function getCompensationGridValidationError(bands) {
  if (!Array.isArray(bands) || bands.length === 0) {
    return t("settings.compensationRequiredFields");
  }

  const bandsByClassification = new Map();
  for (const band of bands) {
    if (!band.id || !band.group || !band.subGroup || !band.level || !band.effectiveFrom) {
      return t("settings.compensationRequiredFields");
    }
    if (!/^[A-Z]{1,6}$/.test(band.group) || !/^[0-9]{2}$/.test(band.subGroup) || !/^[0-9]{2}$/.test(band.level)) {
      return t("settings.compensationInvalidClassification");
    }
    if (!Number.isSafeInteger(band.annualSalaryCents) || band.annualSalaryCents <= 0) {
      return t("settings.compensationInvalidSalary");
    }
    if (!normalizeCompensationGridDate(band.effectiveFrom)
      || (band.effectiveTo && !normalizeCompensationGridDate(band.effectiveTo))) {
      return t("settings.compensationInvalidDate");
    }
    if (band.effectiveTo && band.effectiveTo < band.effectiveFrom) {
      return t("settings.compensationInvalidDateRange");
    }

    const classification = [band.group, band.subGroup, band.level].join("|");
    const existingBands = bandsByClassification.get(classification) || [];
    const effectiveTo = band.effectiveTo || "9999-12-31";
    for (const existingBand of existingBands) {
      const existingEffectiveTo = existingBand.effectiveTo || "9999-12-31";
      if (band.effectiveFrom <= existingEffectiveTo && existingBand.effectiveFrom <= effectiveTo) {
        return band.effectiveFrom === existingBand.effectiveFrom
          ? t("settings.compensationDuplicateBand")
          : t("settings.compensationOverlappingBand");
      }
    }
    existingBands.push(band);
    bandsByClassification.set(classification, existingBands);
  }

  return "";
}

function getCompensationIT02Additions(currentBands, suggestedBands) {
  const existingClasses = new Set(currentBands.map(band => [band.group, band.subGroup, band.level].join("|")));
  const existingIds = new Set(currentBands.map(band => band.id));
  return (suggestedBands || []).map(normalizeCompensationBandForDisplay).filter(band => {
    const key = [band.group, band.subGroup, band.level].join("|");
    if (band.group !== "IT" || band.subGroup !== "02" || existingClasses.has(key)
      || !Number.isSafeInteger(band.annualSalaryCents) || !band.effectiveFrom) return false;
    existingClasses.add(key);
    if (existingIds.has(band.id)) band.id = createCompensationBandId();
    existingIds.add(band.id);
    return true;
  });
}

function addCompensationIT02Bands() {
  if (!isSuperAdminUser()) return;
  const currentBands = getCompensationGridBandsFromForm();
  const additions = getCompensationIT02Additions(currentBands, appShellState.compensationSuggestedBands);
  if (additions.length === 0) {
    setCompensationGridSettingsMessage(t("settings.compensationIT02Exists"), "info");
    return;
  }
  renderCompensationGridSettingsRows([...currentBands, ...additions]);
  setCompensationGridSettingsMessage(t("settings.compensationIT02Added", { count: additions.length }), "info");
}

function addCompensationGridBand() {
  const currentBands = getCompensationGridBandsFromForm();
  const existingBands = currentBands.length > 0 ? currentBands : appShellState.compensationBands;
  renderCompensationGridSettingsRows([...existingBands, createEmptyCompensationBand()]);
  const rowsElement = getCompensationGridSettingsRowsElement();
  const firstInput = rowsElement && rowsElement.querySelector("tr:last-child .compensation-grid-group-input");
  if (firstInput) {
    firstInput.focus();
  }
}

async function loadCompensationGrid() {
  if (!getSessionToken() || !isSuperAdminUser()) {
    return;
  }

  setCompensationGridSettingsMessage("");
  appShellState.compensationSuggestedBands = [];
  renderCompensationGridLoading();
  try {
    const response = await fetch(apiUrl + COMPENSATION_GRID_ENDPOINT, { cache: "no-store" });
    const payload = await parseResponse(response);
    appShellState.compensationSuggestedBands = Array.isArray(payload.suggestedBands) ? payload.suggestedBands : [];
    renderCompensationGridSettingsRows(getCompensationGridPayloadBands(payload));
  } catch (error) {
    renderCompensationGridSettingsRows([]);
    setCompensationGridSettingsMessage(error.message || t("settings.compensationLoadError"), "warning");
  }
}

async function saveCompensationGrid(triggerButton) {
  if (!isSuperAdminUser()) {
    return;
  }

  const bands = getCompensationGridBandsFromForm();
  const validationError = getCompensationGridValidationError(bands);
  if (validationError) {
    setCompensationGridSettingsMessage(validationError, "danger");
    return;
  }

  setCompensationGridSettingsMessage("");
  const saveButton = triggerButton || document.getElementById("compensationGridSaveButton");
  const saveGrid = async () => {
    try {
      const response = await fetch(apiUrl + COMPENSATION_GRID_ENDPOINT, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ bands }),
      });
      const payload = await parseResponse(response);
      renderCompensationGridSettingsRows(getCompensationGridPayloadBands(payload).length > 0
        ? getCompensationGridPayloadBands(payload)
        : bands);
      showToast(t("settings.compensationSaveSuccess"), "success");
    } catch (error) {
      setCompensationGridSettingsMessage(error.message || t("settings.compensationSaveError"), "danger");
    }
  };

  return runButtonAction(saveButton, saveGrid, {
    key: "compensation-grid-save",
    disableWhileRunning: () => document.querySelectorAll("#compensationGridSettingsSection input, #compensationGridSettingsSection button"),
  });
}

function updateSessionSummary() {
  const summary = document.getElementById("appSessionSummary");
  const settingsButton = document.getElementById("appSettingsButton");
  const logoutButton = document.getElementById("appLogoutButton");
  const user = getCurrentUser();

  if (!user) {
    summary.textContent = t("session.notSignedIn");
    settingsButton.classList.add("d-none");
    logoutButton.classList.add("d-none");
    return;
  }

  const identity = user.displayName || user.username;
  const role = normalizeClientRole(user.role);
  const suffix = role === "employee" && user.employeeCode
    ? t("session.employeeCode", { code: user.employeeCode })
    : t(`session.role.${role}`);

  summary.textContent = `${identity} | ${suffix}`;
  settingsButton.classList.remove("d-none");
  logoutButton.classList.remove("d-none");
}

function setAuthMessage(message, type) {
  const messageBox = document.getElementById("authMessage");
  if (!message) {
    messageBox.className = "alert d-none";
    messageBox.textContent = "";
    return;
  }

  messageBox.className = `alert alert-${type || "danger"}`;
  messageBox.textContent = message;
}

function toggleAuthAdvancedPanel(forceState) {
  const panel = document.getElementById("authAdvancedPanel");
  if (!panel) {
    return;
  }

  const shouldShow = typeof forceState === "boolean" ? forceState : panel.classList.contains("d-none");
  panel.classList.toggle("d-none", !shouldShow);
}

function showAuthOverlay(requirePasswordChange) {
  document.getElementById("authOverlay").classList.remove("d-none");
  document.getElementById("passwordChangeSection").classList.toggle("d-none", !requirePasswordChange);
  document.getElementById("loginSubmitButton").classList.toggle("d-none", requirePasswordChange);
  document.getElementById("changePasswordButton").classList.toggle("d-none", !requirePasswordChange);
  if (requirePasswordChange) {
    toggleAuthAdvancedPanel(false);
  }
}

function hideAuthOverlay() {
  document.getElementById("authOverlay").classList.add("d-none");
  setAuthMessage("");
}

function setModalPasswordMessage(message, type) {
  const messageBox = document.getElementById("selfPasswordMessage");
  if (!message) {
    messageBox.className = "alert d-none";
    messageBox.textContent = "";
    return;
  }

  messageBox.className = `alert alert-${type || "danger"}`;
  messageBox.textContent = message;
}

function resetModalPasswordForm() {
  document.getElementById("selfCurrentPasswordInput").value = "";
  document.getElementById("selfNewPasswordInput").value = "";
  document.getElementById("selfConfirmPasswordInput").value = "";
  setModalPasswordMessage("");
}

function openModalPasswordForm() {
  openSelfSettingsForm();
  window.setTimeout(() => {
    const currentPasswordInput = document.getElementById("selfCurrentPasswordInput");
    if (currentPasswordInput) {
      currentPasswordInput.focus();
    }
  }, 150);
}

function toSelfGc179UpperText(value) {
  const text = String(value || "").trim();
  return text ? text.toUpperCase() : "";
}

function inferSelfGc179NameParts(displayName) {
  const tokens = String(displayName || "")
    .trim()
    .split(/\s+/)
    .filter(Boolean);
  if (tokens.length === 0) {
    return {
      surname: "",
      givenName: "",
      initials: "",
    };
  }

  const surname = tokens.length === 1 ? tokens[0] : tokens[tokens.length - 1];
  const givenName = tokens.length === 1 ? "" : tokens.slice(0, -1).join(" ");
  const initialParts = [];
  if (givenName) {
    initialParts.push(givenName.charAt(0).toUpperCase());
  }
  if (surname) {
    initialParts.push(surname.charAt(0).toUpperCase());
  }

  return {
    surname: toSelfGc179UpperText(surname),
    givenName: toSelfGc179UpperText(givenName),
    initials: initialParts.join("."),
  };
}

function normalizeSelfGc179Profile(profile, displayName) {
  const fallback = inferSelfGc179NameParts(displayName);
  const source = profile && typeof profile === "object" ? profile : {};
  const groupPropertyNames = ["group", "Group", "groupe", "Groupe"];
  const subGroupPropertyNames = ["subGroup", "SubGroup", "subgroup", "SousGroupe", "sousGroupe"];
  const hasExplicitGroup = hasAnyOwnProperty(source, groupPropertyNames);
  const hasExplicitSubGroup = hasAnyOwnProperty(source, subGroupPropertyNames);
  const group = getFirstNonEmptyPropertyValue(source, [
    ...groupPropertyNames,
    "position",
    "Position",
    "poste",
    "Poste",
    "classification",
    "Classification",
  ]);
  let subGroup = getFirstNonEmptyPropertyValue(source, subGroupPropertyNames);
  if (!subGroup && !hasExplicitGroup && !hasExplicitSubGroup) {
    subGroup = getFirstNonEmptyPropertyValue(source, ["echelon", "Echelon", "level", "Level"]);
  }
  const level = hasExplicitGroup || hasExplicitSubGroup
    ? getFirstNonEmptyPropertyValue(source, ["level", "Level", "niveau", "Niveau"])
    : "";

  return {
    surname: toSelfGc179UpperText(source.surname || source.Surname || source.lastName || fallback.surname),
    givenName: toSelfGc179UpperText(source.givenName || source.given || source.Given || fallback.givenName),
    initials: toSelfGc179UpperText(source.initials || source.Initials || fallback.initials),
    pri: formatGc179Pri(source.pri || source.PRI || ""),
    group: normalizeGc179Group(group),
    subGroup: normalizeGc179SubGroup(subGroup),
    level: normalizeGc179Level(level),
    compressedWorkWeek: normalizeBooleanValue(getFirstDefinedPropertyValue(source, ["compressedWorkWeek", "isCompressedWorkWeek", "compressed"]), false),
  };
}

function setSelfGc179ProfileMessage(message, type) {
  const messageBox = document.getElementById("selfGc179ProfileMessage");
  if (!message) {
    messageBox.className = "alert d-none";
    messageBox.textContent = "";
    return;
  }

  messageBox.className = `alert alert-${type || "danger"}`;
  messageBox.textContent = message;
}

function setSelfGc179ProfileForm(profile, displayName) {
  const normalized = normalizeSelfGc179Profile(profile, displayName);
  document.getElementById("selfGc179SurnameInput").value = normalized.surname;
  document.getElementById("selfGc179GivenInput").value = normalized.givenName;
  document.getElementById("selfGc179InitialsInput").value = normalized.initials;
  document.getElementById("selfGc179PriInput").value = normalized.pri;
  document.getElementById("selfGc179GroupInput").value = normalized.group;
  document.getElementById("selfGc179SubGroupInput").value = normalized.subGroup;
  document.getElementById("selfGc179LevelInput").value = normalized.level;
  document.getElementById("selfGc179CompressedWorkWeekInput").checked = Boolean(normalized.compressedWorkWeek);
  updateSelfGc179MappingPreview();
}

function updateSelfGc179MappingPreview() {
  const groupInput = document.getElementById("selfGc179GroupInput");
  const subGroupInput = document.getElementById("selfGc179SubGroupInput");
  const levelInput = document.getElementById("selfGc179LevelInput");
  const groupPreview = document.getElementById("selfGc179GroupPreview");
  const subGroupPreview = document.getElementById("selfGc179SubGroupPreview");
  const levelPreview = document.getElementById("selfGc179LevelPreview");

  if (groupPreview) {
    groupPreview.textContent = normalizeGc179Group(groupInput ? groupInput.value : "");
  }
  if (subGroupPreview) {
    subGroupPreview.textContent = normalizeGc179SubGroup(subGroupInput ? subGroupInput.value : "");
  }
  if (levelPreview) {
    levelPreview.textContent = normalizeGc179Level(levelInput ? levelInput.value : "") || "—";
  }
}

function getSelfGc179ProfileForm(displayName) {
  return normalizeSelfGc179Profile({
    surname: document.getElementById("selfGc179SurnameInput").value,
    givenName: document.getElementById("selfGc179GivenInput").value,
    initials: document.getElementById("selfGc179InitialsInput").value,
    pri: document.getElementById("selfGc179PriInput").value,
    group: document.getElementById("selfGc179GroupInput").value,
    subGroup: document.getElementById("selfGc179SubGroupInput").value,
    level: document.getElementById("selfGc179LevelInput").value,
    compressedWorkWeek: document.getElementById("selfGc179CompressedWorkWeekInput").checked,
  }, displayName);
}

function updateStoredUserGc179Profile(profile) {
  const session = getStoredSession();
  if (!session || !session.user) {
    return;
  }

  session.user.gc179Profile = profile;
  setStoredSession(session);
  if (typeof window.syncSelfWorkScheduleFromGc179Profile === "function") {
    window.syncSelfWorkScheduleFromGc179Profile(profile);
  }
}

async function openSelfSettingsForm(triggerButton) {
  const user = getCurrentUser();
  if (!user) {
    return;
  }

  setSelfGc179ProfileMessage("");
  resetModalPasswordForm();
  updateSettingsThemeOptions(getStoredTheme());
  setSelfGc179ProfileForm(user.gc179Profile, user.displayName || user.username || "");
  const modal = new bootstrap.Modal(document.getElementById("selfSettingsModal"));
  modal.show();

  const loadProfile = async () => {
    try {
      const response = await fetch(apiUrl + "self/profile");
      const profile = await parseResponse(response);
      if (profile && profile.gc179Profile) {
        updateStoredUserGc179Profile(profile.gc179Profile);
        setSelfGc179ProfileForm(profile.gc179Profile, profile.displayName || user.displayName || user.username || "");
      }
    } catch (error) {
      setSelfGc179ProfileMessage(error.message || t("self.gc179ProfileError"), "warning");
    }
  };

  const loadSettings = () => Promise.all([
    loadSettingsHealth(),
    loadProfile(),
    isSuperAdminUser(user) ? loadBudgetPeriods() : Promise.resolve(),
    isSuperAdminUser(user) ? loadCompensationGrid() : Promise.resolve(),
  ]).then(() => undefined);

  return triggerButton
    ? runButtonAction(triggerButton, loadSettings, { key: "self-settings" })
    : loadSettings();
}

async function submitSelfGc179Profile(triggerButton) {
  const user = getCurrentUser();
  if (!user || !user.employeeCode) {
    return;
  }

  setSelfGc179ProfileMessage("");
  const classificationError = getGc179ClassificationFormError("selfGc179");
  if (classificationError) {
    setSelfGc179ProfileMessage(classificationError, "danger");
    return;
  }
  const gc179Profile = getSelfGc179ProfileForm(user.displayName || user.username || "");

  const saveProfile = async () => {
    try {
      const response = await fetch(apiUrl + "self/gc179-profile", {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          gc179Profile,
        }),
      });
      const result = await parseResponse(response);
      const savedProfile = result && result.gc179Profile ? result.gc179Profile : gc179Profile;
      updateStoredUserGc179Profile(savedProfile);
      updateSessionSummary();
      setSelfGc179ProfileForm(savedProfile, user.displayName || user.username || "");
      bootstrap.Modal.getInstance(document.getElementById("selfSettingsModal")).hide();
      showToast(t("self.gc179ProfileSaved"), "success");
      markViewsStale(["selfView", "employeesView"]);
    } catch (error) {
      setSelfGc179ProfileMessage(error.message || t("self.gc179ProfileError"), "danger");
    }
  };

  const saveButton = triggerButton || document.getElementById("selfGc179ProfileSaveButton");
  return runButtonAction(saveButton, saveProfile, { key: "self-gc179-profile" });
}

function setRoleScopeVisibility(role, isVisible) {
  document.querySelectorAll(`[data-role-scope="${role}"]`).forEach(element => {
    element.classList.toggle("d-none", !isVisible);
  });
}

function clearRoleUi() {
  window.allowedViewIds = [];
  setRoleScopeVisibility("admin", false);
  setRoleScopeVisibility("employee", false);
  setRoleScopeVisibility("manager", false);
  setRoleScopeVisibility("superAdmin", false);
  setRoleScopeVisibility("authenticated", false);
}

function getAllowedViewsForUser(user) {
  if (!user) {
    return [];
  }

  const views = [];
  if (userHasEmployeeWorkspace(user)) {
    views.push("selfView");
  }

  if (isManagerUser(user)) {
    ROLE_VIEW_MAP[normalizeClientRole(user.role)].forEach(viewId => {
      if (views.indexOf(viewId) < 0) {
        views.push(viewId);
      }
    });
  } else if (normalizeClientRole(user.role) === "employee") {
    ROLE_VIEW_MAP.employee.forEach(viewId => {
      if (views.indexOf(viewId) < 0) {
        views.push(viewId);
      }
    });
  }

  return views;
}

function resolvePreferredView(user) {
  const allowedViews = getAllowedViewsForUser(user);
  const projectWorkspaceRoute = String(window.location && window.location.hash || "").match(/^#projects\/[^/]+$/);
  if (projectWorkspaceRoute && allowedViews.indexOf("projectsView") >= 0) {
    return "projectsView";
  }
  const savedView = localStorage.getItem("activeView");
  if (savedView && allowedViews.indexOf(savedView) >= 0) {
    return savedView;
  }

  return allowedViews.length > 0 ? allowedViews[0] : "dashboardView";
}

function configureRoleUi(user) {
  clearRoleUi();

  if (!user) {
    window.allowedViewIds = [];
    return;
  }

  setRoleScopeVisibility("employee", userHasEmployeeWorkspace(user));
  setRoleScopeVisibility("manager", isManagerUser(user));
  setRoleScopeVisibility("superAdmin", isSuperAdminUser(user));
  setRoleScopeVisibility("admin", isManagerUser(user));
  setRoleScopeVisibility("authenticated", true);
  window.allowedViewIds = getAllowedViewsForUser(user);

  if (typeof showView === "function") {
    showView(resolvePreferredView(user));
  }
}

function stopSyncPolling() {
  if (appShellState.syncTimerId) {
    window.clearTimeout(appShellState.syncTimerId);
    appShellState.syncTimerId = null;
  }
}

function getSyncPollDelay() {
  return document.hidden ? APP_SYNC_POLL_HIDDEN_MS : APP_SYNC_POLL_VISIBLE_MS;
}

function scheduleNextSyncPoll(delayMs) {
  stopSyncPolling();
  appShellState.syncTimerId = window.setTimeout(() => {
    pollSyncState();
  }, typeof delayMs === "number" ? delayMs : getSyncPollDelay());
}

async function runViewRefresh(viewId) {
  try {
    await ensureManagerAssetsForView(viewId);
    if (window.SaphirPerformance) window.SaphirPerformance.observeDashboard();
  } catch (error) {
    console.error(`Unable to load assets for ${viewId}:`, error);
    setSyncStatus(t("status.syncPaused"));
    showToast(error && error.message ? error.message : t("dashboard.loadError"), "error");
    throw error;
  }

  if (viewId === "selfView" && typeof refreshSelfView === "function") {
    return refreshSelfView();
  }

  if (viewId === "dashboardView" && typeof refreshDashboardView === "function") {
    return refreshDashboardView();
  }

  if (viewId === "employeesView" && typeof loadEmployeesView === "function") {
    return loadEmployeesView();
  }

  if (viewId === "adminView") {
    if (typeof loadReviewView === "function") {
      return loadReviewView();
    }

    const tasks = [];
    if (typeof loadApprovalsView === "function") {
      tasks.push(loadApprovalsView());
    }
    if (typeof fetchHistory === "function") {
      tasks.push(fetchHistory());
    }
    const results = await Promise.all(tasks);
    return results.every(result => result !== false);
  }

  if (viewId === "projectsView" && typeof refreshProjectsView === "function") {
    return refreshProjectsView();
  }

  if (viewId === "bugReportsView" && typeof refreshBugReportsView === "function") {
    return refreshBugReportsView();
  }

  return true;
}

async function refreshViewById(viewId, options) {
  const state = ensureViewState(viewId);
  const forceRefresh = !!(options && options.force);

  if (!forceRefresh && state.loaded && !state.stale) {
    return;
  }

  if (state.refreshPromise) {
    return state.refreshPromise;
  }

  state.refreshPromise = runViewRefresh(viewId)
    .then(result => {
      if (result === false) {
        state.stale = true;
        return false;
      }
      state.loaded = true;
      state.stale = false;
      state.lastLoadedAt = Date.now();
      return true;
    })
    .catch(error => {
      state.stale = true;
      if (error && error.isManagerAssetLoadError) {
        return;
      }
      throw error;
    })
    .finally(() => {
      state.refreshPromise = null;
    });

  return state.refreshPromise;
}

window.refreshAppViewById = refreshViewById;
window.refreshAdminViewById = refreshViewById;
window.requestAppViewRefresh = requestViewRefresh;
window.markAppViewsStale = markViewsStale;
window.getActiveAppViewId = getActiveViewId;

async function openEmployeeEntryInPeopleView(employeeCode, projectCode = "", entryId = "") {
  const normalizedEmployeeCode = String(employeeCode || "").trim();
  if (!normalizedEmployeeCode) {
    return false;
  }

  await ensureManagerAssetsForView("employeesView");
  if (typeof window.openPeopleProjectFilter !== "function") {
    throw new Error(t("employees.loadError"));
  }

  await window.openPeopleProjectFilter(
    normalizedEmployeeCode,
    String(projectCode || "").trim(),
    String(entryId || "").trim(),
  );
  return true;
}

window.openEmployeeEntryInPeopleView = openEmployeeEntryInPeopleView;

window.openPendingReviewFromDashboard = async function () {
  await ensureManagerAssetsForView("adminView");
  if (!isManagerUser(getCurrentUser())) return false;
  window.closeReviewHistory?.();
  window.resetReviewWorkspace?.();
  if (showView("adminView") !== "adminView") return false;
  const loaded = await refreshViewById("adminView", { force: true });
  const pendingTab = document.getElementById("pending-tab");
  pendingTab?.scrollIntoView({ block: "center" });
  pendingTab?.focus({ preventScroll: true });
  return loaded;
};

async function openProjectInReview(projectCode) {
  const normalizedProjectCode = String(projectCode || "").trim();
  if (!normalizedProjectCode) {
    return false;
  }

  await ensureManagerAssetsForView("adminView");
  if (typeof showView === "function") {
    showView("adminView");
  }
  if (typeof window.openProjectReviewPage === "function") {
    if (!await window.openProjectReviewPage(normalizedProjectCode)) throw new Error(t("projects.projectUnavailableInReview"));
    document.getElementById("reviewProjectFilter")?.focus({ preventScroll: true });
    return true;
  }
  const refreshed = await refreshViewById("adminView", { force: true });
  if (refreshed === false) {
    throw new Error(t("review.loadError"));
  }

  const projectFilter = document.getElementById("reviewProjectFilter");
  if (!projectFilter || !Array.from(projectFilter.options).some(option => option.value === normalizedProjectCode)) {
    throw new Error(t("projects.projectUnavailableInReview"));
  }
  const approvalsSearch = document.getElementById("approvalsSearchInput");
  const employeeFilter = document.getElementById("reviewEmployeeFilter");
  const startDateFilter = document.getElementById("reviewStartDate");
  const endDateFilter = document.getElementById("reviewEndDate");
  if (approvalsSearch) {
    approvalsSearch.value = "";
  }
  if (employeeFilter) {
    employeeFilter.value = "";
  }
  if (startDateFilter) {
    startDateFilter.value = "";
  }
  if (endDateFilter) {
    endDateFilter.value = "";
  }
  projectFilter.value = normalizedProjectCode;
  if (typeof window.applyApprovalFilters === "function") {
    window.applyApprovalFilters();
  } else {
    projectFilter.dispatchEvent(new Event("change", { bubbles: true }));
  }

  const pendingTab = document.getElementById("pending-tab");
  if (pendingTab) {
    if (window.bootstrap && bootstrap.Tab && typeof bootstrap.Tab.getOrCreateInstance === "function") {
      bootstrap.Tab.getOrCreateInstance(pendingTab).show();
    } else {
      pendingTab.click();
    }
  }
  projectFilter.focus({ preventScroll: true });
  return true;
}

async function openProjectEntriesInPeople(projectCode) {
  const normalizedProjectCode = String(projectCode || "").trim();
  if (!normalizedProjectCode) {
    return false;
  }

  await ensureManagerAssetsForView("employeesView");
  if (typeof showView === "function") {
    showView("employeesView");
  }
  const refreshed = await refreshViewById("employeesView");
  if (refreshed === false) {
    throw new Error(t("employees.loadError"));
  }

  const projectFilter = document.getElementById("employeesProjectSelect");
  if (!projectFilter || !Array.from(projectFilter.options).some(option => option.value === normalizedProjectCode)) {
    throw new Error(t("projects.projectUnavailableInPeople"));
  }
  const employeeSearch = document.getElementById("employeesSearchInput");
  const employeeScope = document.getElementById("employeesScopeSelect");
  if (employeeSearch) {
    employeeSearch.value = "";
  }
  if (employeeScope) {
    employeeScope.value = "all";
    employeeScope.dispatchEvent(new Event("change", { bubbles: true }));
  }
  projectFilter.value = normalizedProjectCode;
  projectFilter.dispatchEvent(new Event("change", { bubbles: true }));
  projectFilter.focus({ preventScroll: true });
  return true;
}

window.openProjectInReview = openProjectInReview;
window.openProjectEntriesInPeople = openProjectEntriesInPeople;

async function refreshActiveView(options) {
  const user = getCurrentUser();
  if (!user) {
    return;
  }

  const activeViewId = document.querySelector(".view.active")?.id || localStorage.getItem("activeView") || resolvePreferredView(user);
  await refreshViewById(activeViewId, options);
  if (!document.hidden && activeViewId === "adminView") await window.refreshReviewHistoryIfVisible?.();
  if (!document.hidden && activeViewId === "employeesView") await window.refreshSelectedEmployeeIfStale?.();
}

async function rerenderActiveViewForLanguageChange(user = getCurrentUser()) {
  if (!user) {
    return;
  }

  const activeViewId = document.querySelector(".view.active")?.id || localStorage.getItem("activeView") || resolvePreferredView(user);
  const handlerNames = {
    selfView: "rerenderSelfViewForLanguageChange",
    dashboardView: "rerenderDashboardViewForLanguageChange",
    employeesView: "rerenderEmployeesViewForLanguageChange",
    adminView: "rerenderReviewViewForLanguageChange",
    projectsView: "rerenderProjectsViewForLanguageChange",
    bugReportsView: "rerenderBugReportsViewForLanguageChange",
  };
  const handler = window[handlerNames[activeViewId]];
  if (typeof handler === "function") {
    return handler();
  }
}

async function pollSyncState() {
  if (appShellState.syncRequestInFlight) {
    scheduleNextSyncPoll();
    return;
  }

  const sessionToken = getSessionToken();
  if (!sessionToken) {
    setSyncStatus(t("status.waitingForSignIn"));
    return;
  }

  appShellState.syncRequestInFlight = true;
  try {
    const response = await fetch(apiUrl + "sync/status");
    const syncState = await parseResponse(response);
    setLastSyncStatus(syncState);
    const nextVersion = syncState && typeof syncState.version === "number" ? syncState.version : 0;
    const nextChangeKey = getSyncStateChangeKey(syncState);

    if (appShellState.lastSyncChangeKey === null) {
      appShellState.lastSyncVersion = nextVersion;
      appShellState.lastSyncChangeKey = nextChangeKey;
      setSyncStatus(t("status.liveRev", { version: nextVersion }));
      return;
    }

    if (nextChangeKey !== appShellState.lastSyncChangeKey) {
      const isSequentialChange = nextVersion === appShellState.lastSyncVersion + 1;
      const routedSyncState = isSequentialChange
        ? syncState
        : {
          ...(syncState || {}),
          category: "seed",
          resource: "sync-gap",
        };

      if (typeof window.handleSyncStateChange === "function") {
        window.handleSyncStateChange(routedSyncState);
      }
      if (["project", "auth", "seed"].includes(routedSyncState.category)) {
        if (typeof clearClientLookupCaches === "function") clearClientLookupCaches();
        window.invalidateEmployeesViewEntryCache?.("*");
      }
      if (["history", "employee", "project", "auth", "employee-directory", "seed"].includes(routedSyncState.category)) {
        window.invalidateReviewHistory?.();
      }
      if (["employee", "project", "auth", "employee-directory", "seed"].includes(routedSyncState.category)) {
        window.invalidateReviewWorkspace?.();
      }
      if (isSequentialChange) {
        markViewsStale(getViewsAffectedBySyncState(syncState));
      } else {
        markAllowedViewsStale(getCurrentUser());
      }
      setSyncStatus(t("status.updatedRev", { version: nextVersion }));
      if (document.hidden) {
        appShellState.lastSyncVersion = nextVersion;
        appShellState.lastSyncChangeKey = nextChangeKey;
        return;
      }
      await refreshActiveView();
      appShellState.lastSyncVersion = nextVersion;
      appShellState.lastSyncChangeKey = nextChangeKey;
      return;
    }

    setSyncStatus(t("status.liveRev", { version: nextVersion }));
  } catch (error) {
    console.error("Unable to refresh sync state:", error);
    setSyncStatus(t("status.syncPaused"));
  } finally {
    appShellState.syncRequestInFlight = false;
    scheduleNextSyncPoll();
  }
}

async function bootstrapApplication() {
  const user = getCurrentUser();
  if (!user) {
    return;
  }

  resetViewState();
  markAllowedViewsStale(user);
  configureRoleUi(user);

  if (userHasEmployeeWorkspace(user) && typeof initializeSelfView === "function") {
    initializeSelfView();
  }

  const preferredView = resolvePreferredView(user);
  if (typeof showView === "function") {
    showView(preferredView);
  }

  appShellState.initialized = true;
  try {
    await refreshViewById(preferredView, { force: true });
  } finally {
    pollSyncState().catch(error => {
      console.error("Unable to start sync polling:", error);
    });
  }
}

function installFetchWrapper() {
  window.fetch = function (resource, options) {
    const requestOptions = options ? { ...options } : {};
    const headers = new Headers(requestOptions.headers || (resource && resource.headers) || {});
    const targetUrl = getFetchTargetUrl(resource);
    const token = getSessionToken();
    let requestToken = getBearerTokenFromHeader(headers.get("Authorization"));

    if (token && isApiRequestUrl(targetUrl) && !headers.has("Authorization")) {
      headers.set("Authorization", `Bearer ${token}`);
      requestToken = token;
    }

    requestOptions.headers = headers;
    const method = String(requestOptions.method || (resource && resource.method) || "GET").toUpperCase();
    // An explicit reconciliation must not join a read that started before
    // the operation with an uncertain outcome.
    const shouldCoalesceGet = method === "GET" && requestOptions.cache !== "reload" && isApiRequestUrl(targetUrl);
    const requestCacheKey = shouldCoalesceGet
      ? `${requestToken || token || ""}|${new URL(targetUrl, window.location.href).href}`
      : "";

    if (requestCacheKey && appShellState.getRequestInflight[requestCacheKey]) {
      return appShellState.getRequestInflight[requestCacheKey].then(response => response.clone());
    }

    const requestPromise = appShellState.nativeFetch(resource, requestOptions).then(response => {
      const isAuthRequest = isApiRequestUrl(targetUrl, "auth/");
      if (response.status === 401 && !isAuthRequest) {
        const currentToken = getSessionToken();
        if (!currentToken || (requestToken && currentToken === requestToken)) {
          handleSessionExpired();
        }
      }
      return response;
    });

    if (requestCacheKey) {
      appShellState.getRequestInflight[requestCacheKey] = requestPromise
        .then(response => response.clone())
        .finally(() => {
          delete appShellState.getRequestInflight[requestCacheKey];
        });
    }

    return requestPromise;
  };
}

function handleSessionExpired() {
  stopSyncPolling();
  appShellState.lastSyncVersion = null;
  appShellState.lastSyncChangeKey = null;
  resetViewState();
  clearClientLookupCaches();
  clearStoredSession();
  clearRoleUi();
  updateSessionSummary();
  setSyncStatus(t("status.sessionExpired"));
  showAuthOverlay(false);
  setAuthMessage(t("auth.sessionExpired"), "warning");
}

function validateAuthenticatedUser(user) {
  if (!user || !user.role) {
    throw new Error(t("auth.authenticationIncomplete"));
  }

  const role = normalizeClientRole(user.role);
  if (!ROLE_VIEW_MAP[role]) {
    throw new Error(`Unsupported role: ${user.role}`);
  }

  if (role === "employee" && !user.employeeCode) {
    throw new Error(t("auth.employeeCodeRequired"));
  }

  user.role = role;
}

async function loadAuthenticatedWorkspace() {
  try {
    if (!appShellState.initialized) {
      await bootstrapApplication();
    } else {
      await refreshActiveView({ force: true });
      await pollSyncState();
    }
    return true;
  } catch (error) {
    console.error("Unable to load the authenticated workspace:", error);
    setSyncStatus(t("status.syncPaused"));
    showToast(error && error.message ? error.message : t("dashboard.loadError"), "error");
    return false;
  }
}

async function applySession(authResult) {
  if (!authResult || !authResult.token || !authResult.user) {
    throw new Error(t("auth.authenticationIncomplete"));
  }

  validateAuthenticatedUser(authResult.user);

  setStoredSession({
    token: authResult.token,
    user: authResult.user,
  });
  appShellState.lastSyncVersion = null;
  appShellState.lastSyncChangeKey = null;
  resetViewState();
  clearClientLookupCaches();
  markAllowedViewsStale(authResult.user);
  updateSessionSummary();
  configureRoleUi(authResult.user);

  if (authResult.user.mustChangePassword) {
    showAuthOverlay(true);
    setAuthMessage(t("auth.passwordChangeRequired"), "warning");
    setSyncStatus(t("status.passwordUpdateRequired"));
    return;
  }

  hideAuthOverlay();
  await loadAuthenticatedWorkspace();
}

async function submitLogin(event) {
  event.preventDefault();

  setStoredApiUrl(document.getElementById("apiUrlInput").value);
  setAuthMessage("");

  const username = document.getElementById("usernameInput").value.trim();
  const password = document.getElementById("passwordInput").value;

  if (!username || !password) {
    setAuthMessage(t("auth.usernamePasswordRequired"), "danger");
    return;
  }

  const loginButton = event.submitter || document.getElementById("loginSubmitButton");
  return runButtonAction(loginButton, async () => {
    try {
      const response = await appShellState.nativeFetch(apiUrl + "auth/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ username, password }),
      });

      const authResult = await parseResponse(response);
      await applySession(authResult);
    } catch (error) {
      setAuthMessage(error.message || t("auth.signInError"), "danger");
    }
  }, { key: "auth-login" });
}

async function submitPasswordChange(triggerButton) {
  setAuthMessage("");

  const currentPassword = document.getElementById("passwordInput").value;
  const newPassword = document.getElementById("newPasswordInput").value;
  const confirmPassword = document.getElementById("confirmPasswordInput").value;

  if (!currentPassword || !newPassword || !confirmPassword) {
    setAuthMessage(t("auth.passwordFieldsRequired"), "danger");
    return;
  }

  if (newPassword !== confirmPassword) {
    setAuthMessage(t("auth.newPasswordsMismatch"), "danger");
    return;
  }

  const changeButton = triggerButton || document.getElementById("changePasswordButton");
  return runButtonAction(changeButton, async () => {
    try {
      const response = await fetch(apiUrl + "auth/change-password", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          currentPassword,
          newPassword,
        }),
      });

      await parseResponse(response);

      const session = getStoredSession();
      if (session && session.user) {
        session.user.mustChangePassword = false;
        setStoredSession(session);
      }

      document.getElementById("newPasswordInput").value = "";
      document.getElementById("confirmPasswordInput").value = "";
      updateSessionSummary();
      hideAuthOverlay();

      if (!appShellState.initialized) {
        await bootstrapApplication();
      } else {
        const user = getCurrentUser();
        if (user) {
          markAllowedViewsStale(user);
        }
        await refreshActiveView({ force: true });
        await pollSyncState();
      }

      showToast(t("auth.passwordUpdated"), "success");
    } catch (error) {
      setAuthMessage(error.message || t("auth.passwordUpdateError"), "danger");
    }
  }, { key: "auth-password-change" });
}

async function submitModalPasswordChange(triggerButton) {
  setModalPasswordMessage("");

  const currentPassword = document.getElementById("selfCurrentPasswordInput").value;
  const newPassword = document.getElementById("selfNewPasswordInput").value;
  const confirmPassword = document.getElementById("selfConfirmPasswordInput").value;

  if (!currentPassword || !newPassword || !confirmPassword) {
    setModalPasswordMessage(t("auth.passwordFieldsRequired"), "danger");
    return;
  }

  if (newPassword !== confirmPassword) {
    setModalPasswordMessage(t("auth.newPasswordsMismatch"), "danger");
    return;
  }

  const saveButton = triggerButton || document.getElementById("selfPasswordSaveButton");
  return runButtonAction(saveButton, async () => {
    try {
      const response = await fetch(apiUrl + "auth/change-password", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          currentPassword,
          newPassword,
        }),
      });

      await parseResponse(response);

      const session = getStoredSession();
      if (session && session.user) {
        session.user.mustChangePassword = false;
        setStoredSession(session);
      }

      updateSessionSummary();
      resetModalPasswordForm();
      showToast(t("auth.passwordUpdated"), "success");
    } catch (error) {
      setModalPasswordMessage(error.message || t("auth.passwordUpdateError"), "danger");
    }
  }, { key: "self-password-change" });
}

async function submitLogout(triggerButton) {
  const logoutButton = triggerButton || document.getElementById("appLogoutButton");
  return runButtonAction(logoutButton, async () => {
    stopSyncPolling();

    const token = getSessionToken();
    if (token) {
      try {
        await appShellState.nativeFetch(apiUrl + "auth/logout", {
          method: "POST",
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
      } catch (error) {
        console.error("Unable to sign out cleanly:", error);
      }
    }

    appShellState.lastSyncVersion = null;
    appShellState.lastSyncChangeKey = null;
    resetViewState();
    clearClientLookupCaches();
    clearStoredSession();
    clearRoleUi();
    updateSessionSummary();
    setSyncStatus(t("status.signedOut"));
    showAuthOverlay(false);
    setAuthMessage(t("auth.signOutSuccess"), "success");
  }, { key: "auth-logout" });
}

async function restoreSession() {
  const session = getStoredSession();
  if (!session || !session.token) {
    clearRoleUi();
    updateSessionSummary();
    showAuthOverlay(false);
    setSyncStatus(t("status.waitingForSignIn"));
    return;
  }

  const restoreToken = session.token;
  try {
    const response = await fetch(apiUrl + "auth/me");
    const currentUser = await parseResponse(response);
    const latestSession = getStoredSession();
    if (!latestSession || latestSession.token !== restoreToken) {
      return;
    }

    await applySession({
      token: restoreToken,
      user: currentUser,
    });
  } catch (error) {
    const latestSession = getStoredSession();
    if (latestSession && latestSession.token !== restoreToken) {
      return;
    }

    clearStoredSession();
    clearRoleUi();
    updateSessionSummary();
    showAuthOverlay(false);
    setAuthMessage(t("auth.signInToContinue"), "warning");
    setSyncStatus(t("status.waitingForSignIn"));
  }
}

window.refreshActiveAppView = refreshActiveView;

document.addEventListener("DOMContentLoaded", () => {
  window.apiUrl = getStoredApiUrl();
  localStorage.setItem(APP_API_URL_KEY, window.apiUrl);
  initializeEntryNotesPopover();
  updateConnectionDisplay();
  document.getElementById("loginForm").addEventListener("submit", submitLogin);
  document.getElementById("selfPasswordForm").addEventListener("submit", event => {
    event.preventDefault();
    submitModalPasswordChange(event.submitter || document.getElementById("selfPasswordSaveButton"));
  });
  document.getElementById("selfGc179ProfileForm").addEventListener("submit", event => {
    event.preventDefault();
    submitSelfGc179Profile(event.submitter || document.getElementById("selfGc179ProfileSaveButton"));
  });
  document.getElementById("changePasswordButton").addEventListener("click", event => submitPasswordChange(event.currentTarget));
  document.getElementById("appSettingsButton").addEventListener("click", event => openSelfSettingsForm(event.currentTarget));
  document.getElementById("settingsHealthRefreshButton").addEventListener("click", event => loadSettingsHealth(event.currentTarget));
  document.getElementById("budgetPeriodAddButton").addEventListener("click", addBudgetPeriod);
  document.getElementById("budgetPeriodGenerateButton").addEventListener("click", generateMonthlyBudgetPeriods);
  document.getElementById("budgetPeriodSettingsRows").addEventListener("click", event => {
    const removeButton = event.target.closest("[data-budget-period-remove]");
    if (removeButton) {
      removeBudgetPeriod(removeButton.getAttribute("data-budget-period-remove"));
    }
  });
  document.getElementById("budgetPeriodSaveButton").addEventListener("click", event => saveBudgetPeriods(event.currentTarget));
  document.getElementById("selfPasswordSaveButton").addEventListener("click", event => submitModalPasswordChange(event.currentTarget));
  document.getElementById("selfGc179ProfileSaveButton").addEventListener("click", event => submitSelfGc179Profile(event.currentTarget));
  document.getElementById("compensationGridAddButton").addEventListener("click", addCompensationGridBand);
  document.getElementById("compensationGridAddIT02Button").addEventListener("click", addCompensationIT02Bands);
  document.getElementById("compensationGridSaveButton").addEventListener("click", event => saveCompensationGrid(event.currentTarget));
  bindGc179PriFormatter(document.getElementById("selfGc179PriInput"));
  bindGc179PriFormatter(document.getElementById("employeeEditorGc179PriInput"));
  bindGc179GroupFormatter(document.getElementById("selfGc179GroupInput"), updateSelfGc179MappingPreview);
  bindGc179TwoDigitFormatter(document.getElementById("selfGc179SubGroupInput"), normalizeGc179SubGroup, updateSelfGc179MappingPreview);
  bindGc179TwoDigitFormatter(document.getElementById("selfGc179LevelInput"), normalizeGc179Level, updateSelfGc179MappingPreview);
  bindGc179GroupFormatter(document.getElementById("employeeEditorGc179GroupInput"));
  bindGc179TwoDigitFormatter(document.getElementById("employeeEditorGc179SubGroupInput"), normalizeGc179SubGroup);
  bindGc179TwoDigitFormatter(document.getElementById("employeeEditorGc179LevelInput"), normalizeGc179Level);
  updateSelfGc179MappingPreview();
  document.getElementById("appLogoutButton").addEventListener("click", event => submitLogout(event.currentTarget));
  document.querySelectorAll("[data-settings-theme]").forEach(button => {
    button.addEventListener("click", () => applyAppTheme(button.getAttribute("data-settings-theme")));
  });
  const authAdvancedToggle = document.getElementById("authAdvancedToggle");
  if (authAdvancedToggle) {
    authAdvancedToggle.addEventListener("click", () => toggleAuthAdvancedPanel());
  }
  applyAppTheme(getStoredTheme());
  if (typeof window.matchMedia === "function") {
    const systemThemeQuery = window.matchMedia("(prefers-color-scheme: dark)");
    const handleSystemThemeChange = () => {
      if (getStoredTheme() === "system") {
        applyAppTheme("system");
      }
    };
    if (typeof systemThemeQuery.addEventListener === "function") {
      systemThemeQuery.addEventListener("change", handleSystemThemeChange);
    } else if (typeof systemThemeQuery.addListener === "function") {
      systemThemeQuery.addListener(handleSystemThemeChange);
    }
  }
  clearRoleUi();
  updateSessionSummary();
  setSyncStatus(t("status.waitingForSignIn"));
  setLastSyncStatus(null);
  installFetchWrapper();
  restoreSession();
});

document.addEventListener("visibilitychange", () => {
  if (!getSessionToken()) {
    return;
  }

  if (!document.hidden) {
    refreshActiveView().catch(error => {
      console.error("Unable to refresh active view after returning to app:", error);
    });
  }
  scheduleNextSyncPoll(0);
});

window.addEventListener("app:language-changed", event => {
  updateConnectionDisplay();
  updateSessionSummary();
  updateThemeToggle(getStoredTheme());

  const user = getCurrentUser();
  if (!user) {
    setSyncStatus(t("status.waitingForSignIn"));
    return;
  }

  if (appShellState.lastSyncVersion === null) {
    if (user.mustChangePassword) {
      setSyncStatus(t("status.passwordUpdateRequired"));
    } else {
      setSyncStatus(t("status.waitingForSignIn"));
    }
  } else {
    setSyncStatus(t("status.liveRev", { version: appShellState.lastSyncVersion }));
  }

  if (typeof window.updateWorkspaceHeading === "function") {
    const activeViewId = document.querySelector(".view.active")?.id || resolvePreferredView(user);
    window.updateWorkspaceHeading(activeViewId);
  }

  if (event.detail && event.detail.refresh === false) {
    return;
  }

  Promise.resolve(rerenderActiveViewForLanguageChange(user)).catch(error => {
    console.error("Unable to rerender active view after language change:", error);
  });
});
