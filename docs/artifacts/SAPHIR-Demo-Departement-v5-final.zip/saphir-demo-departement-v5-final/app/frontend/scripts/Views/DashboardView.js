const dashboardState = {
  employees: [],
  entriesByEmployee: {},
  bootstrap: null,
  projects: [],
};
let dashboardEmployeeSearchTimer = null;

function getDashboardEntryActionKey(button, employeeCodeOverride = "") {
  const employeeCode = String(employeeCodeOverride || button?.getAttribute("data-employee-code") || document.getElementById("employeeSelect")?.value || "").trim();
  const entryId = String(button?.getAttribute("data-entryid") || "").trim();
  const date = String(button?.getAttribute("data-date") || "").trim();
  const punchIn = String(button?.getAttribute("data-punchin") || "").trim();
  return `entry:${employeeCode}:${entryId || `${date}:${punchIn}`}`;
}

function buildEmployeeOptions(employees) {
  return `<option value="">${escapeHtml(t("shared.selectEmployee"))}</option>${employees.map(emp => `<option value="${escapeHtml(emp.code)}">${escapeHtml(emp.name)}</option>`).join("")}`;
}

function getDashboardEmployeeSearchLabel(employee) {
  if (!employee) {
    return "";
  }

  const name = String(employee.name || employee.code || "").trim();
  const code = String(employee.code || "").trim();
  return code ? `${name} | ${code}` : name;
}

function buildDashboardEmployeeSearchOptions(employees) {
  return (Array.isArray(employees) ? employees : [])
    .map(employee => `<option value="${escapeHtml(getDashboardEmployeeSearchLabel(employee))}"></option>`)
    .join("");
}

function populateDashboardEmployeeControls(employees) {
  const employeeSelect = document.getElementById("employeeSelect");
  const employeeSearchList = document.getElementById("dashboardEmployeeSearchList");
  if (employeeSelect) {
    employeeSelect.innerHTML = buildEmployeeOptions(employees);
  }
  if (employeeSearchList) {
    employeeSearchList.innerHTML = buildDashboardEmployeeSearchOptions(employees);
  }
}

function getDashboardEmployeeByCodeValue(employeeCode) {
  const normalizedCode = String(employeeCode || "").trim();
  if (!normalizedCode) {
    return null;
  }

  return dashboardState.employees.find(employee => String(employee.code || "").trim() === normalizedCode) || null;
}

function getDashboardEmployeeTimeEntryTypes(employee) {
  const source = Array.isArray(employee && employee.timeEntryTypes) && employee.timeEntryTypes.length > 0
    ? employee.timeEntryTypes
    : ["overtime"];
  const normalizedTypes = source
    .map(value => String(value || "").trim().toLowerCase())
    .filter(value => value === "overtime" || value === "diverse");

  return normalizedTypes.length > 0 ? Array.from(new Set(normalizedTypes)) : ["overtime"];
}

function canCreateDiverseEntryForDashboardEmployee(employee) {
  return Boolean(
    employee
    && getDashboardEmployeeTimeEntryTypes(employee).includes("diverse")
    && typeof isSuperAdminUser === "function"
    && isSuperAdminUser(),
  );
}

function getSelectedAddEntryType() {
  const selectedType = document.querySelector('input[name="addEntryType"]:checked')?.value;
  return String(selectedType || "overtime").toLowerCase() === "diverse" ? "diverse" : "overtime";
}

function setAddEntryModalType(entryType, employee, diverseAllowedOverride = null) {
  const diverseAllowed = typeof diverseAllowedOverride === "boolean"
    ? diverseAllowedOverride
    : canCreateDiverseEntryForDashboardEmployee(employee);
  const normalizedType = String(entryType || "overtime").toLowerCase() === "diverse" && diverseAllowed
    ? "diverse"
    : "overtime";
  const typeField = document.getElementById("addEntryTypeField");
  const diverseOption = document.getElementById("addEntryTypeDiverseOption");
  const overtimeInput = document.getElementById("addEntryTypeOvertime");
  const diverseInput = document.getElementById("addEntryTypeDiverse");
  const addEntryForm = document.getElementById("addEntryForm");

  if (addEntryForm) {
    addEntryForm.dataset.diverseAllowed = diverseAllowed ? "true" : "false";
  }

  if (typeField) {
    typeField.classList.toggle("d-none", !diverseAllowed);
  }
  if (diverseOption) {
    diverseOption.classList.toggle("d-none", !diverseAllowed);
  }
  if (diverseInput) {
    diverseInput.disabled = !diverseAllowed;
    diverseInput.checked = normalizedType === "diverse";
  }
  if (overtimeInput) {
    overtimeInput.checked = normalizedType === "overtime";
  }

  document.querySelectorAll(".add-overtime-field").forEach(element => {
    element.classList.toggle("d-none", normalizedType === "diverse");
  });
  document.querySelectorAll(".add-diverse-field").forEach(element => {
    element.classList.toggle("d-none", normalizedType !== "diverse");
  });

  const projectSelect = document.getElementById("addProjectCode");
  const paymentSelect = document.getElementById("addPaymentOption");
  const diverseReason = document.getElementById("addDiverseReason");
  const diverseSummary = document.getElementById("addDiverseSummary");
  if (projectSelect) {
    projectSelect.required = normalizedType === "overtime";
  }
  if (paymentSelect) {
    paymentSelect.required = normalizedType === "overtime";
  }
  if (diverseReason) {
    diverseReason.required = normalizedType === "diverse";
  }
  if (diverseSummary) {
    diverseSummary.required = normalizedType === "diverse";
  }
}

function getDashboardEmployeeSearchText(employee) {
  return [
    employee && employee.name,
    employee && employee.code,
    employee && employee.role,
    getDashboardEmployeeSearchLabel(employee),
  ].map(value => String(value || "").trim().toLowerCase()).filter(Boolean).join(" ");
}

function resolveDashboardEmployeeSearchValue(value) {
  const normalizedValue = String(value || "").trim().toLowerCase();
  if (!normalizedValue) {
    return null;
  }

  const exactMatch = dashboardState.employees.find(employee => {
    const code = String(employee.code || "").trim().toLowerCase();
    const name = String(employee.name || "").trim().toLowerCase();
    const label = getDashboardEmployeeSearchLabel(employee).toLowerCase();
    return normalizedValue === code || normalizedValue === name || normalizedValue === label;
  });
  if (exactMatch) {
    return exactMatch;
  }

  const tokens = window.Saphir.textSearch.tokenize(normalizedValue);
  if (tokens.length === 0) {
    return null;
  }

  const matches = dashboardState.employees.filter(employee => {
    const text = getDashboardEmployeeSearchText(employee);
    return window.Saphir.textSearch.matchesAll(text, tokens);
  });

  return matches.length === 1 ? matches[0] : null;
}

function syncDashboardEmployeeSearchInput(employeeCode) {
  const searchInput = document.getElementById("dashboardEmployeeSearchInput");
  if (!searchInput) {
    return;
  }

  const employee = getDashboardEmployeeByCodeValue(employeeCode);
  searchInput.value = employee ? getDashboardEmployeeSearchLabel(employee) : "";
}

function setDashboardSelectedEmployee(employeeCode, options = {}) {
  const normalizedCode = String(employeeCode || "").trim();
  const employeeSelect = document.getElementById("employeeSelect");
  if (employeeSelect) {
    employeeSelect.value = normalizedCode;
  }

  if (normalizedCode) {
    localStorage.setItem("selectedEmployee", normalizedCode);
  } else {
    localStorage.removeItem("selectedEmployee");
  }

  if (options.syncSearchInput !== false) {
    syncDashboardEmployeeSearchInput(normalizedCode);
  }
  if (options.refresh) {
    fetchEmployeeData();
  }
}

function clearDashboardSelectedEmployeeForSearchInput(options = {}) {
  const employeeSelect = document.getElementById("employeeSelect");
  if (!employeeSelect || !employeeSelect.value) {
    return false;
  }

  setDashboardSelectedEmployee("", {
    refresh: options.refresh !== false,
    syncSearchInput: false,
  });
  return true;
}

function resolveDashboardEmployeeSearchInput(options = {}) {
  const searchInput = document.getElementById("dashboardEmployeeSearchInput");
  const employeeSelect = document.getElementById("employeeSelect");
  if (!searchInput || !employeeSelect) {
    return;
  }

  const rawValue = searchInput.value;
  if (!String(rawValue || "").trim()) {
    searchInput.removeAttribute("aria-invalid");
    if (employeeSelect.value) {
      setDashboardSelectedEmployee("", { refresh: true });
    }
    return false;
  }

  const employee = resolveDashboardEmployeeSearchValue(rawValue);
  if (!employee) {
    searchInput.setAttribute("aria-invalid", "true");
    clearDashboardSelectedEmployeeForSearchInput();
    return false;
  }

  searchInput.removeAttribute("aria-invalid");
  const employeeCode = String(employee.code || "").trim();
  if (!employeeCode || employeeSelect.value === employeeCode) {
    if (options.forceSync) {
      syncDashboardEmployeeSearchInput(employeeCode);
    }
    return Boolean(employeeCode);
  }

  setDashboardSelectedEmployee(employeeCode, { refresh: true });
  return true;
}

function scheduleDashboardEmployeeSearchResolve() {
  const searchInput = document.getElementById("dashboardEmployeeSearchInput");
  const employeeSelect = document.getElementById("employeeSelect");
  const selectedEmployee = employeeSelect ? getDashboardEmployeeByCodeValue(employeeSelect.value) : null;
  if (searchInput && selectedEmployee) {
    const normalizedValue = String(searchInput.value || "").trim().toLowerCase();
    const selectedValues = [
      selectedEmployee.code,
      selectedEmployee.name,
      getDashboardEmployeeSearchLabel(selectedEmployee),
    ].map(value => String(value || "").trim().toLowerCase());
    if (!selectedValues.includes(normalizedValue)) {
      searchInput.setAttribute("aria-invalid", "true");
      clearDashboardSelectedEmployeeForSearchInput();
    }
  }

  if (dashboardEmployeeSearchTimer) {
    window.clearTimeout(dashboardEmployeeSearchTimer);
  }

  dashboardEmployeeSearchTimer = window.setTimeout(() => {
    dashboardEmployeeSearchTimer = null;
    resolveDashboardEmployeeSearchInput();
  }, 220);
}

function buildProjectFilterOptions(projects) {
  return buildProjectOptions(projects || [], t("filters.allProjects"), document.getElementById("projectFilter")?.value || "");
}

function isArchivedDashboardProject(project) {
  if (!project) {
    return false;
  }
  const archivedValue = project.archived;
  if (typeof archivedValue === "boolean") {
    return archivedValue;
  }
  if (typeof archivedValue === "number") {
    return archivedValue !== 0;
  }
  const normalizedValue = String(archivedValue || "").trim().toLowerCase();
  return normalizedValue === "true" || normalizedValue === "1" || normalizedValue === "yes";
}

function canModifyDashboardProject(project) {
  return !project || project.canModify !== false;
}

function getDashboardProjectCode(project) {
  return String(project && project.projectCode || "").trim();
}

function getDashboardProjectByCode(projectCode) {
  return findProjectByCode(dashboardState.projects, projectCode);
}

function renderDashboardEntryProjectIdentity(entry) {
  if (isDiverseEntry(entry)) {
    return `<span class="inline-code-pill">${escapeHtml(t("shared.diverse"))}</span>`;
  }
  const projectCode = String(entry && entry.projectCode || "").trim();
  if (!projectCode) {
    return `<span class="inline-code-pill">${escapeHtml(t("shared.noProject"))}</span>`;
  }
  return renderProjectIdentityPill(getDashboardProjectByCode(projectCode) || projectCode, projectCode);
}

function sortDashboardProjects(projects) {
  return (Array.isArray(projects) ? projects : [])
    .filter(project => getDashboardProjectCode(project))
    .sort((left, right) => getDashboardProjectCode(left).localeCompare(getDashboardProjectCode(right)));
}

function getDashboardScopedProjects(fallbackProjects = []) {
  const scopedProjects = Array.isArray(dashboardState.projects) ? dashboardState.projects : [];
  return scopedProjects.length > 0 ? scopedProjects : (Array.isArray(fallbackProjects) ? fallbackProjects : []);
}

function getDashboardEntryProjects(fallbackProjects, selectedProjectCode = "") {
  const projects = sortDashboardProjects(getDashboardScopedProjects(fallbackProjects));
  const activeProjects = projects.filter(project => !isArchivedDashboardProject(project));
  const normalizedSelectedProjectCode = String(selectedProjectCode || "").trim();
  if (!normalizedSelectedProjectCode || activeProjects.some(project => getDashboardProjectCode(project) === normalizedSelectedProjectCode)) {
    return activeProjects;
  }

  const selectedProject = projects.find(project => getDashboardProjectCode(project) === normalizedSelectedProjectCode);
  return selectedProject ? activeProjects.concat([selectedProject]) : activeProjects;
}

function getDashboardModifiableEntryProjects(fallbackProjects, selectedProjectCode = "") {
  const projects = getDashboardEntryProjects(fallbackProjects, selectedProjectCode);
  const modifiableProjects = projects.filter(project => canModifyDashboardProject(project));
  const normalizedSelectedProjectCode = String(selectedProjectCode || "").trim();
  if (!normalizedSelectedProjectCode || modifiableProjects.some(project => getDashboardProjectCode(project) === normalizedSelectedProjectCode)) {
    return modifiableProjects;
  }

  const selectedProject = projects.find(project => getDashboardProjectCode(project) === normalizedSelectedProjectCode);
  return selectedProject ? modifiableProjects.concat([selectedProject]) : modifiableProjects;
}

function populateDashboardProjectFilter(projects) {
  const projectFilter = document.getElementById("projectFilter");
  if (!projectFilter) {
    return;
  }

  const previousValue = projectFilter.value || "";
  const projectItems = sortDashboardProjects(projects);
  projectFilter.innerHTML = buildProjectFilterOptions(projectItems);
  if (previousValue && projectItems.some(project => getDashboardProjectCode(project) === previousValue)) {
    projectFilter.value = previousValue;
  }
}

function getDashboardProjectCodeArray(codes) {
  return (Array.isArray(codes) ? codes : [])
    .map(code => String(code || "").trim())
    .filter(Boolean);
}

function getDashboardProjectResponsibility(project) {
  const currentUser = typeof getCurrentUser === "function" ? getCurrentUser() : null;
  const employeeCode = String(currentUser && currentUser.employeeCode || "").trim();
  if (!employeeCode) {
    return "";
  }

  if (getDashboardProjectCodeArray(project && project.admins).indexOf(employeeCode) >= 0) {
    return t("dashboard.primaryAdmin");
  }

  if (getDashboardProjectCodeArray(project && project.backupAdmins).indexOf(employeeCode) >= 0) {
    return t("dashboard.backupAdmin");
  }

  return "";
}

function renderDashboardResponsibleProjects() {
  const card = document.getElementById("dashboardProjectScopeCard");
  const container = document.getElementById("dashboardResponsibleProjects");
  const currentUser = typeof getCurrentUser === "function" ? getCurrentUser() : null;
  const isAdmin = currentUser && normalizeClientRole(currentUser.role) === "admin";

  if (!card || !container) {
    return;
  }

  card.classList.toggle("d-none", !isAdmin);
  if (!isAdmin) {
    container.innerHTML = "";
    return;
  }

  const responsibleProjects = sortDashboardProjects(dashboardState.projects)
    .map(project => ({
      project,
      responsibility: getDashboardProjectResponsibility(project),
    }))
    .filter(item => item.responsibility);

  if (responsibleProjects.length === 0) {
    container.innerHTML = createEmptyState(t("dashboard.noResponsibleProjects"));
    return;
  }

  container.innerHTML = responsibleProjects.map(item => {
    const project = item.project;
    const projectCode = getDashboardProjectCode(project);
    const projectName = String(project.projectName || "").trim();
    const sector = String(project.sector || "").trim();
    return `
      <div class="project-scope-pill">
        ${renderProjectIdentityPill(project, projectCode)}
        ${projectName ? `<span class="project-scope-name">${escapeHtml(projectName)}</span>` : ""}
        ${sector ? `<span class="meta-pill">${escapeHtml(sector)}</span>` : ""}
        <span class="meta-pill">${escapeHtml(item.responsibility)}</span>
        ${isArchivedDashboardProject(project) ? `<span class="meta-pill">${escapeHtml(t("projects.archived"))}</span>` : ""}
      </div>
    `;
  }).join("");
}

function getEmployeeNameByCode(employeeCode) {
  const match = dashboardState.employees.find(employee => employee.code === employeeCode);
  return match ? match.name : employeeCode;
}

function enrichEntry(employee, entry) {
  return {
    ...entry,
    employeeCode: employee.code,
    employeeName: employee.name,
  };
}

function getFlattenedDashboardEntries() {
  return dashboardState.employees.flatMap(employee => {
    const entries = dashboardState.entriesByEmployee[employee.code] || [];
    return entries.map(entry => enrichEntry(employee, entry));
  });
}

function setDashboardLoadingState() {
  setLoadingState("dashboardApprovalQueue", "queue", 3);
  setLoadingState("dashboardActiveList", "queue", 3);
  setLoadingState("punchClockEntries", "entries", 3);
}

function buildInspectorMeta(entryCount, startDate, endDate, projectCode) {
  const parts = [tn("shared.entry", entryCount)];
  const dateRangeLabel = buildDateRangeLabel(startDate, endDate);
  if (dateRangeLabel) {
    parts.push(dateRangeLabel);
  }
  if (projectCode) {
    parts.push(projectCode);
  }
  return parts.join(" | ");
}

function formatQueueTitle(entry) {
  return getEntryRoundedTimeRange(entry);
}

function openDashboardNoteEditor(noteButton) {
  const modalElement = document.getElementById("dashboardNoteModal");
  if (!modalElement || !noteButton) {
    return;
  }

  closeEntryNotesPopover();
  document.getElementById("dashboardNoteEntryId").value = noteButton.getAttribute("data-entry-id") || "";
  document.getElementById("dashboardNoteDate").value = noteButton.getAttribute("data-date") || "";
  document.getElementById("dashboardNotePunchIn").value = noteButton.getAttribute("data-punchin") || "";
  const noteInput = document.getElementById("dashboardNoteInput");
  noteInput.value = noteButton.getAttribute("data-message") || "";
  const note = getEntryNotesFromTrigger(noteButton);
  document.getElementById("dashboardNoteContext").textContent = noteInput.value ? getEntrySupervisorNoteLabel({
    messageAuthorName: note.supervisorNoteAuthor,
    messageUpdatedAt: note.supervisorNoteTimestamp,
  }) : "";

  const modal = new bootstrap.Modal(modalElement);
  modal.show();
}

async function saveDashboardNoteFromModal(saveButton = document.getElementById("dashboardSaveNoteBtn")) {
  const employeeCode = document.getElementById("employeeSelect").value;
  if (!employeeCode) {
    showToast(t("dashboard.selectEmployeeBeforeNote"), "info");
    return;
  }

  const entryId = document.getElementById("dashboardNoteEntryId").value;
  const date = document.getElementById("dashboardNoteDate").value;
  const punchIn = document.getElementById("dashboardNotePunchIn").value;
  const message = document.getElementById("dashboardNoteInput").value;
  try {
    await runButtonAction(saveButton, async () => {
      const response = await fetch(apiUrl + "employee/message/" + employeeCode, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ entryId, date, punchIn, message }),
      });
      await parseResponse(response);
      dashboardState.entriesByEmployee[employeeCode] = undefined;
      showToast(t("dashboard.managerMessageSaved"), "success");
      const modalInstance = bootstrap.Modal.getInstance(document.getElementById("dashboardNoteModal"));
      if (modalInstance) {
        modalInstance.hide();
      }
      await refreshDashboardView();
    }, { key: `entry:${employeeCode}:${date}:${punchIn}` });
  } catch (error) {
    console.error("Error updating message:", error);
    showToast(t("dashboard.managerMessageError"), "error");
  }
}

function renderDashboardApprovalQueue(entries, pendingCount) {
  const container = document.getElementById("dashboardApprovalQueue");
  const queueEntries = entries; // Server already returns the six newest closed entries.

  document.getElementById("dashboardPendingQueueMeta").textContent = queueEntries.length > 0
    ? t("dashboard.pendingPreview", { shown: queueEntries.length, total: pendingCount })
    : t("dashboard.pendingQueueMetaEmpty");

  if (queueEntries.length === 0) {
    container.innerHTML = createEmptyState(t("dashboard.noPending"));
    return;
  }

  container.innerHTML = queueEntries.map(entry => {
    const permissionBadge = getEntryPermissionBadgeMarkup(entry);
    const canReview = !isEntryForgottenClockOut(entry) && canApproveEntry(entry);
    return `
    <article class="queue-card">
      <div class="queue-card-header">
        <div>
          <div class="queue-card-title">${escapeHtml(entry.employeeName)}</div>
          <div class="worklog-secondary">${escapeHtml(formatDateLabel(entry.date))} | ${escapeHtml(formatQueueTitle(entry))}</div>
          ${getEntryExactTimeLabel(entry) ? `<div class="panel-note">${escapeHtml(getEntryExactTimeLabel(entry))}</div>` : ""}
        </div>
        <span class="status-badge ${escapeHtml(getStatusTone(entry))}">${escapeHtml(getEntryStatusLabel(entry))}</span>
      </div>
      <div class="queue-card-meta">
        ${renderDashboardEntryProjectIdentity(entry)}
        ${!isDiverseEntry(entry) && entry.overtimeCode ? `<span class="meta-pill">${escapeHtml(entry.overtimeCode)}</span>` : ""}
        <span class="meta-pill duration-value">${escapeHtml(formatEntryRecordedDuration(entry))}</span>
        ${renderEntryWorkScheduleBadge(entry)}
      </div>
      ${renderEntryWorkComment(entry)}
      ${entry.message ? `
        <div class="review-card-message">
          <div class="entry-work-comment-label">${escapeHtml(getEntrySupervisorNoteLabel(entry))}</div>
          <div>${escapeHtml(entry.message)}</div>
        </div>
      ` : ""}
      <div class="queue-card-actions">
        ${canReview ? `
          <button type="button" class="btn btn-success btn-sm dashboard-approve-button" data-entryid="${escapeHtml(entry.entryId || "")}" data-employee-code="${escapeHtml(entry.employeeCode)}" data-date="${escapeHtml(entry.date)}" data-punchin="${escapeHtml(entry.punchIn)}"><i class="fa-solid fa-check"></i> ${escapeHtml(t("action.approve"))}</button>
          <button type="button" class="btn btn-danger btn-sm dashboard-reject-button" data-entryid="${escapeHtml(entry.entryId || "")}" data-employee-code="${escapeHtml(entry.employeeCode)}" data-employee-name="${escapeHtml(entry.employeeName)}" data-date="${escapeHtml(entry.date)}" data-punchin="${escapeHtml(entry.punchIn)}" data-punchout="${escapeHtml(entry.punchOut || "")}"><i class="fa-solid fa-ban"></i> ${escapeHtml(t("action.reject"))}</button>
        ` : ""}
        ${!canReview ? permissionBadge : ""}
        <button type="button" class="btn btn-outline-secondary btn-sm dashboard-jump-button" data-employee-code="${escapeHtml(entry.employeeCode)}" data-project-code="${escapeHtml(entry.projectCode || "")}">${escapeHtml(t("action.openEmployee"))}</button>
      </div>
    </article>
  `;
  }).join("");
}

function renderDashboardActiveSessions(entries) {
  const container = document.getElementById("dashboardActiveList");
  const activeEntries = entries
    .filter(entry => isEntryOpen(entry))
    .sort((left, right) => toEntryDateTime(right) - toEntryDateTime(left));

  document.getElementById("dashboardActiveQueueMeta").textContent = activeEntries.length > 0
    ? tn("shared.session", activeEntries.length)
    : t("dashboard.activeQueueMetaEmpty");

  if (activeEntries.length === 0) {
    container.innerHTML = createEmptyState(t("dashboard.noActive"));
    return;
  }

  container.innerHTML = activeEntries.map(entry => {
    const elapsed = Math.max(0, Math.floor((Date.now() - toEntryDateTime(entry).getTime()) / 1000));
    return `
      <article class="queue-card">
        <div class="queue-card-header">
          <div>
            <div class="queue-card-title">${escapeHtml(entry.employeeName)}</div>
            <div class="worklog-secondary">${escapeHtml(t("dashboard.started", { date: formatDateLabel(entry.date), time: formatTimeString(entry.punchIn) }))}</div>
            ${getEntryExactTimeLabel(entry) ? `<div class="panel-note">${escapeHtml(getEntryExactTimeLabel(entry))}</div>` : ""}
          </div>
          <span class="status-badge approved">${escapeHtml(t("shared.live"))}</span>
        </div>
        <div class="queue-card-meta">
          <span class="inline-code-pill duration-value">${escapeHtml(secondsToDurationLabel(elapsed))}</span>
          ${renderDashboardEntryProjectIdentity(entry)}
          ${entry.overtimeCode ? `<span class="meta-pill">${escapeHtml(entry.overtimeCode)}</span>` : ""}
          ${renderEntryWorkScheduleBadge(entry)}
        </div>
        <div class="queue-card-actions">
          <button type="button" class="btn btn-outline-secondary btn-sm dashboard-jump-button" data-employee-code="${escapeHtml(entry.employeeCode)}" data-project-code="${escapeHtml(entry.projectCode || "")}">${escapeHtml(t("action.openEmployee"))}</button>
        </div>
      </article>
    `;
  }).join("");
}

function renderDashboardOverview(payload) {
  const model = payload || dashboardState.bootstrap || {};
  const totalSeconds = timeStringToSeconds(model.totalOvertime);
  const pendingCount = Number(model.pendingApprovals || 0);
  const activeCount = Number(model.activeEmployees || 0);
  const trackedCount = Number(model.trackedEmployees || dashboardState.employees.length || 0);

  document.getElementById("totalOvertime").innerText = secondsToDurationLabel(totalSeconds);
  document.getElementById("pendingApprovals").innerText = pendingCount;
  const actionable = document.getElementById("dashboardActionableCount");
  actionable.textContent = Number.isFinite(model.actionableCount)
    ? t("dashboard.actionableCount", { count: model.actionableCount }) : "";
  const showPending = document.getElementById("dashboardOpenPendingReview");
  showPending.classList.toggle("d-none", pendingCount === 0);
  showPending.textContent = t("dashboard.viewPending", { count: pendingCount });
  document.getElementById("activeEmployees").innerText = activeCount;
  document.getElementById("trackedEmployeesCount").innerText = trackedCount;
  const summary = document.getElementById("dashboardSummaryText");
  if (summary) {
    summary.textContent = pendingCount > 0
      ? `${tn("shared.approval", pendingCount)} | ${tn("shared.session", activeCount)}`
      : tn("shared.session", activeCount);
  }

  renderDashboardApprovalQueue(model.pendingQueue || [], pendingCount);
  renderDashboardActiveSessions(model.activeSessions || []);
}

document.getElementById("dashboardOpenPendingReview")?.addEventListener("click", event => {
  runButtonAction(event.currentTarget, async () => {
    if (!await window.openPendingReviewFromDashboard()) showToast(t("review.loadError"), "error");
  }, { key: "view-navigation" }).catch(error => {
    console.error("Unable to open pending review:", error);
    showToast(t("review.loadError"), "error");
  });
});

function applyDashboardBootstrap(payload) {
  const model = payload || {};
  dashboardState.bootstrap = model;
  dashboardState.employees = Array.isArray(model.employees) ? model.employees : [];
  dashboardState.projects = sortDashboardProjects(model.projects || []);

  populateDashboardEmployeeControls(dashboardState.employees);
  populateDashboardProjectFilter(dashboardState.projects);
  renderDashboardResponsibleProjects();

  const savedEmployee = localStorage.getItem("selectedEmployee");
  const desiredEmployee = savedEmployee && dashboardState.employees.some(employee => employee.code === savedEmployee)
    ? savedEmployee
    : (model.selectedEmployeeCode && dashboardState.employees.some(employee => employee.code === model.selectedEmployeeCode)
      ? model.selectedEmployeeCode
      : (model.defaultEmployeeCode && dashboardState.employees.some(employee => employee.code === model.defaultEmployeeCode)
        ? model.defaultEmployeeCode
        : ""));

  if (desiredEmployee && Array.isArray(model.selectedEmployeeEntries)) {
    dashboardState.entriesByEmployee[desiredEmployee] = model.selectedEmployeeEntries;
  }

  if (desiredEmployee) {
    setDashboardSelectedEmployee(desiredEmployee);
  }

  renderDashboardOverview(model);
}

async function fetchEmployees() {
  const response = await fetch(apiUrl + "employees/bootstrap?scope=active");
  const employees = (await parseResponse(response)).employees;
  dashboardState.employees = Array.isArray(employees) ? employees : [];
  populateDashboardEmployeeControls(dashboardState.employees);

  const savedEmployee = localStorage.getItem("selectedEmployee");
  if (savedEmployee && dashboardState.employees.some(employee => employee.code === savedEmployee)) {
    setDashboardSelectedEmployee(savedEmployee);
  }

  return dashboardState.employees;
}

async function fetchEmployeeEntries(employeeCode) {
  const response = await fetch(apiUrl + "employee/" + employeeCode);
  if (response.status === 404) {
    return [];
  }
  const payload = await parseResponse(response);
  return Array.isArray(payload) ? payload : (payload ? [payload] : []);
}

async function loadDashboardCollections() {
  const employeeSelect = document.getElementById("employeeSelect");
  const savedEmployee = localStorage.getItem("selectedEmployee");
  const requestedEmployeeCode = (employeeSelect && employeeSelect.value) || savedEmployee || "";
  const query = requestedEmployeeCode ? `?employeeCode=${encodeURIComponent(requestedEmployeeCode)}` : "";
  const response = await fetch(apiUrl + "dashboard/bootstrap" + query);
  const payload = await parseResponse(response);
  applyDashboardBootstrap(payload);
}

function renderEmployeeEntries(employeeCode, entries) {
  const container = document.getElementById("punchClockEntries");
  container.innerHTML = "";

  if (!entries || entries.length === 0) {
    container.innerHTML = createEmptyState(t("dashboard.noEntriesFiltered"));
    return;
  }

  container.innerHTML = `
    <div class="dashboard-table-wrap">
      <table class="table dashboard-entry-table">
        <thead>
          <tr>
            <th scope="col">${escapeHtml(t("dashboard.tableDate"))}</th>
            <th scope="col">${escapeHtml(t("dashboard.tableWindow"))}</th>
            <th scope="col">${escapeHtml(t("dashboard.tableProject"))}</th>
            <th scope="col">${escapeHtml(t("dashboard.tableOvertimeCode"))}</th>
            <th scope="col">${escapeHtml(t("dashboard.tablePayment"))}</th>
            <th scope="col">${escapeHtml(t("dashboard.tableReason"))}</th>
            <th scope="col">${escapeHtml(t("dashboard.tableDuration"))}</th>
            <th scope="col">${escapeHtml(t("dashboard.tableStatus"))}</th>
            <th scope="col">${escapeHtml(t("dashboard.tableComments"))}</th>
            <th scope="col">${escapeHtml(t("dashboard.tableActions"))}</th>
          </tr>
        </thead>
        <tbody>
          ${entries.map(entry => {
            const statusTone = getStatusTone(entry);
            const isOpen = isEntryOpen(entry);
            const isPending = String(entry.status || "pending").toLowerCase() === "pending";
            const needsClockOutReview = isEntryForgottenClockOut(entry);
            const canModify = canModifyEntry(entry);
            const canApprove = canApproveEntry(entry);
            const permissionBadge = getEntryPermissionBadgeMarkup(entry);
            const exactTimeLabel = getEntryExactTimeLabel(entry);
            const entryTypeAttribute = ` data-entrytype="${escapeHtml(getEntryType(entry))}"`;
            const workScheduleAttribute = ` data-workschedule="${escapeHtml(getEntryWorkSchedule(entry))}" data-holidaynotscheduled="${typeof entry.holidayNotScheduledWorkday === "boolean" ? entry.holidayNotScheduledWorkday : ""}"`;
            const diverseReasonAttribute = ` data-diversereason="${escapeHtml(entry.diverseReason || "")}"`;
            const diverseSummaryAttribute = ` data-diversesummary="${escapeHtml(entry.diverseSummary || "")}"`;
            const workCommentAttribute = ` data-workcomment="${escapeHtml(entry.workComment || "")}"`;
            const overtimeCodeAttribute = ` data-overtimecode="${escapeHtml(entry.overtimeCode || "")}"`;
            const paymentOptionAttribute = ` data-paymentoption="${escapeHtml(entry.paymentOption || "cash")}"`;
            const reasonCodeAttribute = ` data-reasoncode="${escapeHtml(entry.reasonCode || "")}"`;
            const statusAttribute = ` data-status="${escapeHtml(entry.status || "pending")}"`;
            const entryIdAttribute = ` data-entryid="${escapeHtml(entry.entryId || "")}"`;
            const messageAttribute = ` data-message="${escapeHtml(entry.message || "")}"${renderEntryNoteMetadataAttributes(entry)}`;
            const exactPunchInAttribute = ` data-exactpunchin="${escapeHtml(getEntryExactPunchIn(entry))}"`;
            const exactPunchOutAttribute = ` data-exactpunchout="${escapeHtml(getEntryExactPunchOut(entry))}"`;
            const reviewButtons = isPending && !isOpen && !needsClockOutReview && canApprove ? `
              <button class="btn btn-success btn-sm approve-btn" data-employee-code="${escapeHtml(employeeCode)}" data-date="${escapeHtml(entry.date)}" data-punchin="${escapeHtml(entry.punchIn)}"${entryIdAttribute} title="${escapeHtml(t("action.approve"))}">
                <i class="fa-solid fa-check"></i> ${escapeHtml(t("action.approve"))}
              </button>
              <button class="btn btn-danger btn-sm reject-btn" data-employee-code="${escapeHtml(employeeCode)}" data-date="${escapeHtml(entry.date)}" data-punchin="${escapeHtml(entry.punchIn)}" data-punchout="${escapeHtml(entry.punchOut || "")}"${entryIdAttribute} title="${escapeHtml(t("action.reject"))}">
                <i class="fa-solid fa-ban"></i> ${escapeHtml(t("action.reject"))}
              </button>
            ` : "";

            return `
              <tr class="dashboard-entry-row${statusTone === "pending" ? " is-pending" : ""}${isOpen ? " is-open" : ""}">
                <td class="dashboard-entry-col-date">
                  <div class="dashboard-table-main">${escapeHtml(formatDateToWords(entry.date))}</div>
                </td>
                <td class="dashboard-entry-col-window">
                  <div class="dashboard-table-main">${escapeHtml(formatQueueTitle(entry))}</div>
                  ${exactTimeLabel ? `<div class="dashboard-table-sub">${escapeHtml(exactTimeLabel)}</div>` : ""}
                </td>
                <td class="dashboard-entry-col-project">
                  ${renderDashboardEntryProjectIdentity(entry)}
                </td>
                <td class="dashboard-entry-col-overtime-code">
                  ${!isDiverseEntry(entry) && entry.overtimeCode ? `<span class="meta-pill">${escapeHtml(entry.overtimeCode)}</span>` : `<span class="meta-pill">-</span>`}
                </td>
                <td class="dashboard-entry-col-payment">
                  <span class="meta-pill">${escapeHtml(isDiverseEntry(entry) ? "-" : formatPaymentOptionValue(entry.paymentOption || "cash"))}</span>
                </td>
                <td class="dashboard-entry-col-reason">
                  <span class="meta-pill">${escapeHtml(isDiverseEntry(entry) ? (entry.diverseReason || "-") : (entry.reasonCode || "-"))}</span>
                </td>
                <td class="dashboard-entry-col-duration">
                  <span class="inline-code-pill duration-value">${escapeHtml(formatEntryRecordedDuration(entry))}</span>
                </td>
                <td class="dashboard-entry-col-status">
                  <div class="entry-state-stack"><span class="status-badge ${escapeHtml(statusTone)}">${escapeHtml(getEntryStatusLabel(entry))}</span>${renderEntryWorkScheduleBadge(entry)}</div>
                </td>
                <td class="dashboard-entry-col-note">
                  <div class="dashboard-entry-note-tools">
                    ${renderEntryNotesPreview(entry, { showEmpty: true })}
                    ${canModify ? `
                      <button type="button" class="dashboard-note-edit-button" data-entry-id="${escapeHtml(entry.entryId || "")}" data-date="${escapeHtml(entry.date)}" data-punchin="${escapeHtml(entry.punchIn)}" data-message="${escapeHtml(entry.message || "")}" ${renderEntryNoteMetadataAttributes(entry)} aria-label="${escapeHtml(t("action.editSupervisorNote"))}" title="${escapeHtml(t("action.editSupervisorNote"))}">
                        <i class="fa-solid fa-pen" aria-hidden="true"></i>
                      </button>
                    ` : ""}
                  </div>
                </td>
                <td class="dashboard-entry-col-actions">
                  <div class="dashboard-entry-actions">
                    ${reviewButtons}
                    ${canModify ? `
                      <button class="btn btn-outline-secondary btn-sm update-button" data-employee-code="${escapeHtml(employeeCode)}" data-date="${escapeHtml(entry.date)}" data-punchin="${escapeHtml(entry.punchIn)}" data-punchout="${escapeHtml(entry.punchOut || "")}" data-overtime="${escapeHtml(entry.overtime || "")}" data-projectcode="${escapeHtml(entry.projectCode || "")}"${entryTypeAttribute}${workScheduleAttribute}${diverseReasonAttribute}${diverseSummaryAttribute}${workCommentAttribute}${overtimeCodeAttribute}${paymentOptionAttribute}${reasonCodeAttribute}${statusAttribute}${entryIdAttribute}${messageAttribute}${exactPunchInAttribute}${exactPunchOutAttribute} title="${escapeHtml(t("modal.updateEntry"))}">
                        <i class="fa-solid fa-pen"></i> ${escapeHtml(t("action.edit"))}
                      </button>
                      <button class="btn btn-outline-secondary btn-sm delete-button" data-date="${escapeHtml(entry.date)}" data-punchin="${escapeHtml(entry.punchIn)}"${entryIdAttribute} title="${escapeHtml(t("action.delete"))}">
                        <i class="fa-solid fa-trash"></i> ${escapeHtml(t("action.delete"))}
                      </button>
                    ` : ""}
                    ${permissionBadge}
                  </div>
                </td>
              </tr>
            `;
          }).join("")}
        </tbody>
      </table>
    </div>
  `;
}

async function fetchEmployeeData(options = {}) {
  const employeeCode = document.getElementById("employeeSelect").value;
  const selectedStartDate = document.getElementById("startDateFilter").value;
  const selectedEndDate = document.getElementById("endDateFilter").value;
  const selectedProjectCode = document.getElementById("projectFilter").value;
  const latestFirst = document.getElementById("latestCheck").checked;
  const container = document.getElementById("punchClockEntries");
  const addButton = document.getElementById("addEntryButton");
  const hint = document.getElementById("dashboardSelectionHint");
  const title = document.getElementById("dashboardInspectorTitle");

  addButton.disabled = !employeeCode;

  if (!employeeCode) {
    if (title) {
      title.textContent = t("dashboard.timeline");
    }
    hint.textContent = "";
    container.innerHTML = createEmptyState(t("dashboard.noEmployeeSelected"));
    return;
  }

  const employeeName = getEmployeeNameByCode(employeeCode);
  title.textContent = employeeName;

  try {
    let entries = dashboardState.entriesByEmployee[employeeCode];
    if (!entries) {
      if (options.allowFetch === false) {
        return false;
      }
      setLoadingState("punchClockEntries", "entries", 3);
      entries = await fetchEmployeeEntries(employeeCode);
      dashboardState.entriesByEmployee[employeeCode] = entries;
    }

    let filteredEntries = entries.filter(entry => {
      if (!isDateWithinRange(entry.date, selectedStartDate, selectedEndDate)) {
        return false;
      }

      if (selectedProjectCode && String(entry.projectCode || "") !== selectedProjectCode) {
        return false;
      }

      return true;
    });

    filteredEntries = sortEntriesByDateTime(filteredEntries, latestFirst);
    hint.textContent = buildInspectorMeta(filteredEntries.length, selectedStartDate, selectedEndDate, selectedProjectCode);
    renderEmployeeEntries(employeeCode, filteredEntries);
    return true;
  } catch (error) {
    console.error("Error fetching employee data:", error);
    showToast(t("dashboard.timelineLoadError"), "error");
    return false;
  }
}

async function refreshDashboardView() {
  try {
    setDashboardLoadingState();
    await loadDashboardCollections();
    const detailLoaded = await fetchEmployeeData();
    return detailLoaded !== false;
  } catch (error) {
    console.error("Error refreshing dashboard:", error);
    showToast(t("dashboard.loadError"), "error");
    return false;
  }
}

window.refreshDashboardView = refreshDashboardView;

window.rerenderDashboardViewForLanguageChange = async function () {
  const employeeSelect = document.getElementById("employeeSelect");
  const selectedEmployeeCode = employeeSelect ? employeeSelect.value : "";
  populateDashboardEmployeeControls(dashboardState.employees || []);
  if (employeeSelect && selectedEmployeeCode) {
    employeeSelect.value = selectedEmployeeCode;
  }
  syncDashboardEmployeeSearchInput(selectedEmployeeCode);
  populateDashboardProjectFilter(dashboardState.projects || []);
  renderDashboardResponsibleProjects();
  renderDashboardOverview(dashboardState.bootstrap || {});
  await fetchEmployeeData({ allowFetch: false });
};

async function refreshAfterEntryMutation(employeeCode, refreshPeopleEmployeeCode = "") {
  const affectedViews = ["dashboardView", "employeesView", "adminView", "projectsView"];
  const activeViewId = typeof window.getActiveAppViewId === "function" ? window.getActiveAppViewId() : "";

  if (activeViewId === "adminView" && typeof window.requestAppViewRefresh === "function") {
    const previousReviewScrollTop = window.scrollY;
    await window.requestAppViewRefresh(affectedViews, { forceActive: true });
    window.scrollTo({ top: previousReviewScrollTop, behavior: "auto" });
    return;
  }

  if (activeViewId === "employeesView" && refreshPeopleEmployeeCode && typeof window.refreshPeopleEmployeeDetail === "function") {
    await window.refreshPeopleEmployeeDetail(refreshPeopleEmployeeCode);
    if (typeof window.requestAppViewRefresh === "function") {
      await window.requestAppViewRefresh(["dashboardView", "adminView", "projectsView"]);
    } else if (typeof window.markAppViewsStale === "function") {
      window.markAppViewsStale(["dashboardView", "adminView", "projectsView"]);
    }
    return;
  }

  if (typeof window.requestAppViewRefresh === "function") {
    await window.requestAppViewRefresh(affectedViews, { forceActive: true });
    return;
  }

  await refreshDashboardView();
}

window.handleSyncStateChange = function (syncState) {
  const category = String(syncState && syncState.category || "").toLowerCase();
  const resource = String(syncState && syncState.resource || "");

  if (category === "seed") {
    dashboardState.employees = [];
    dashboardState.entriesByEmployee = {};
    dashboardState.bootstrap = null;
    dashboardState.projects = [];
    if (typeof clearScopedProjectLookupCache === "function") {
      clearScopedProjectLookupCache();
    }
    if (typeof clearProjectDetailCache === "function") {
      clearProjectDetailCache();
    }
    if (typeof window.invalidateEmployeesViewEntryCache === "function") {
      window.invalidateEmployeesViewEntryCache("*");
    }
    return;
  }

  if (category === "employee" && resource) {
    if (resource === "*") {
      dashboardState.entriesByEmployee = {};
    } else {
      dashboardState.entriesByEmployee[resource] = undefined;
    }
    if (typeof window.invalidateEmployeesViewEntryCache === "function") {
      window.invalidateEmployeesViewEntryCache(resource);
    }
    dashboardState.bootstrap = null;
    return;
  }

  if (category === "project") {
    dashboardState.projects = [];
    dashboardState.bootstrap = null;
    if (typeof clearScopedProjectLookupCache === "function") {
      clearScopedProjectLookupCache();
    }
    if (typeof clearProjectDetailCache === "function") {
      clearProjectDetailCache();
    }
    return;
  }

  if (category === "employee-directory") {
    dashboardState.employees = [];
    dashboardState.entriesByEmployee = {};
    dashboardState.bootstrap = null;
    if (typeof window.invalidateEmployeesViewEntryCache === "function") {
      window.invalidateEmployeesViewEntryCache("*");
    }
    return;
  }

};

async function populateEntryLookups(projectSelectId, overtimeCodeSelectId, selectedProjectCode = "", selectedOvertimeCode = "", paymentSelectId = "", reasonSelectId = "", selectedPaymentOption = "", selectedReasonCode = "") {
  const lookups = await fetchOvertimeEntryLookups();
  if (dashboardState.projects.length === 0) {
    try {
      dashboardState.projects = sortDashboardProjects(await fetchScopedProjects());
      populateDashboardProjectFilter(dashboardState.projects);
      renderDashboardResponsibleProjects();
    } catch (error) {
      console.warn("Unable to load scoped projects for entry modal:", error);
    }
  }
  document.getElementById(projectSelectId).innerHTML = buildProjectOptions(getDashboardModifiableEntryProjects(lookups.projects, selectedProjectCode), t("shared.selectProject"), selectedProjectCode);
  document.getElementById(overtimeCodeSelectId).innerHTML = buildOvertimeCodeOptions(lookups.overtimeCodes, t("shared.selectOvertimeCode"), selectedOvertimeCode);
  if (paymentSelectId) {
    document.getElementById(paymentSelectId).innerHTML = buildPaymentOptionOptions(lookups.paymentOptions, t("shared.selectPaymentOption"), selectedPaymentOption);
  }
  if (reasonSelectId) {
    document.getElementById(reasonSelectId).innerHTML = buildReasonCodeOptions(lookups.reasonCodes, t("shared.selectReasonCode"), selectedReasonCode);
  }
}

function setUpdateEntryModalType(entryType) {
  const normalizedEntryType = String(entryType || "overtime").toLowerCase() === "diverse" ? "diverse" : "overtime";
  document.getElementById("updateEntryType").value = normalizedEntryType;
  document.querySelectorAll(".update-overtime-field").forEach(element => {
    element.classList.toggle("d-none", normalizedEntryType === "diverse");
  });
  document.querySelectorAll(".update-diverse-field").forEach(element => {
    element.classList.toggle("d-none", normalizedEntryType !== "diverse");
  });
}

async function openAddEntryModal(employeeCodeOverride = "", triggerButton = null, employeeOverride = null) {
  const employeeCode = employeeCodeOverride || document.getElementById("employeeSelect").value;
  if (!employeeCode) {
    showToast(t("dashboard.selectEmployeeBeforeAdd"), "info");
    return;
  }

  return runButtonAction(triggerButton, async () => {
    const employee = employeeOverride || getDashboardEmployeeByCodeValue(employeeCode);
    document.getElementById("addEntryForm").dataset.employeeCode = employeeCode;
    document.getElementById("addEntryForm").dataset.refreshPeopleEmployee = employeeCodeOverride ? employeeCode : "";
    document.getElementById("addEntryDate").value = toLocalDateInputValue(new Date());
    ["addPunchInHours", "addPunchInMinutes", "addPunchOutHours", "addPunchOutMinutes"].forEach(id => {
      document.getElementById(id).value = "";
    });
    ["addWorkComment", "addDiverseReason", "addDiverseSummary", "addManagerMessage"].forEach(id => {
      document.getElementById(id).value = "";
    });
    setAddEntryModalType("overtime", employee);
    await populateEntryLookups("addProjectCode", "addOvertimeCode", "", "", "addPaymentOption", "addReasonCode");
    const addModal = new bootstrap.Modal(document.getElementById("addEntryModal"));
    addModal.show();
  }, {
    key: "entry-add-modal",
    disableWhileRunning: () => document.querySelectorAll("#addEntryButton, .people-add-entry-button"),
  });
}

function syncUpdateITHolidayField() {
  const visible = document.getElementById("updateEntryType").value !== "diverse"
    && document.getElementById("updateOvertimeCode").value === "263";
  document.getElementById("updateITHolidayField").classList.toggle("d-none", !visible);
}

document.getElementById("updateOvertimeCode").addEventListener("change", syncUpdateITHolidayField);

async function openUpdateModal(button, refreshPeopleEmployee = "") {
  const date = button.getAttribute("data-date");
  const originalPunchIn = button.getAttribute("data-punchin");
  const currentPunchOut = button.getAttribute("data-punchout");
  const exactPunchIn = button.getAttribute("data-exactpunchin") || originalPunchIn;
  const exactPunchOut = button.getAttribute("data-exactpunchout") || currentPunchOut;
  const projectCode = button.getAttribute("data-projectcode") || "";
  const overtimeCode = button.getAttribute("data-overtimecode") || "";
  const paymentOption = button.getAttribute("data-paymentoption") || "cash";
  const reasonCode = button.getAttribute("data-reasoncode") || "";
  const entryStatus = String(button.getAttribute("data-status") || "pending").toLowerCase();
  const entryType = String(button.getAttribute("data-entrytype") || "overtime").toLowerCase() === "diverse" ? "diverse" : "overtime";
  const workSchedule = String(button.getAttribute("data-workschedule") || "").toLowerCase();
  const diverseReason = button.getAttribute("data-diversereason") || "";
  const diverseSummary = button.getAttribute("data-diversesummary") || "";
  const workComment = button.getAttribute("data-workcomment") || "";
  const entryId = button.getAttribute("data-entryid") || "";
  const message = button.getAttribute("data-message") || "";

  try {
    await runButtonAction(button, async () => {
      document.getElementById("updateEntryForm").dataset.refreshPeopleEmployee = refreshPeopleEmployee;
      document.getElementById("updateEntryForm").dataset.employeeCode = button.getAttribute("data-employee-code") || "";
      document.getElementById("originalDate").value = date;
      document.getElementById("updateDate").value = date;
      document.getElementById("originalPunchIn").value = originalPunchIn;
      document.getElementById("originalPunchOut").value = currentPunchOut;
      document.getElementById("updateEntryId").value = entryId;
      document.getElementById("updateManagerMessage").value = message;
      document.getElementById("updateEntryForm").dataset.originalManagerMessage = message.trim();
      const notes = getEntryNotesFromTrigger(button);
      document.getElementById("updateSupervisorNoteContext").textContent = message ? getEntrySupervisorNoteLabel({
        messageAuthorName: notes.supervisorNoteAuthor, messageUpdatedAt: notes.supervisorNoteTimestamp,
      }) : "";
      document.getElementById("updateEmployeeCommentHistory").innerHTML =
        renderEmployeeCommentRows(workComment.trim() || diverseSummary.trim(), notes.additions) || createEmptyState(t("shared.noEmployeeComment"));
      document.getElementById("updateDiverseReason").value = diverseReason;
      document.getElementById("originalDiverseReason").value = diverseReason;
      document.getElementById("updateEntryForm").dataset.originalExactPunchIn = exactPunchIn || "";
      document.getElementById("updateEntryForm").dataset.originalExactPunchOut = exactPunchOut || "";
      document.getElementById("updateEntryForm").dataset.originalWorkSchedule = workSchedule;
      document.getElementById("updateWorkSchedule").value = ["regular", "compressed"].includes(workSchedule) ? workSchedule : "";
      const holidayValue = button.getAttribute("data-holidaynotscheduled") || "";
      document.getElementById("updateITHolidaySchedule").value = holidayValue;
      document.getElementById("updateEntryForm").dataset.originalHolidaySchedule = holidayValue;
      setUpdateEntryModalType(entryType);

      if (exactPunchIn) {
        const [hours, minutes] = exactPunchIn.split(":");
        document.getElementById("updatePunchInHours").value = hours;
        document.getElementById("updatePunchInMinutes").value = minutes;
      }

      if (exactPunchOut) {
        const [hours, minutes] = exactPunchOut.split(":");
        document.getElementById("updatePunchOutHours").value = hours;
        document.getElementById("updatePunchOutMinutes").value = minutes;
      } else {
        document.getElementById("updatePunchOutHours").value = "";
        document.getElementById("updatePunchOutMinutes").value = "";
      }

      if (entryType === "diverse") {
        document.getElementById("updateProjectCode").value = "";
        document.getElementById("originalProjectCode").value = "";
        document.getElementById("updateOvertimeCode").value = "";
        document.getElementById("originalOvertimeCode").value = "";
        document.getElementById("updatePaymentOption").value = "";
        document.getElementById("originalPaymentOption").value = "";
        document.getElementById("updateReasonCode").value = "";
        document.getElementById("originalReasonCode").value = "";
      } else {
        await populateEntryLookups("updateProjectCode", "updateOvertimeCode", projectCode, overtimeCode, "updatePaymentOption", "updateReasonCode", paymentOption, reasonCode);
        document.getElementById("updateProjectCode").value = projectCode;
        document.getElementById("originalProjectCode").value = projectCode;
        document.getElementById("updateOvertimeCode").value = overtimeCode;
        document.getElementById("originalOvertimeCode").value = overtimeCode;
        document.getElementById("updatePaymentOption").value = paymentOption;
        document.getElementById("originalPaymentOption").value = paymentOption;
        document.getElementById("updateReasonCode").value = reasonCode;
        document.getElementById("originalReasonCode").value = reasonCode;
      }

      document.getElementById("updateEntryStatus").value = ["approved", "rejected", "pending"].includes(entryStatus) ? entryStatus : "pending";
      syncUpdateITHolidayField();
      document.getElementById("originalEntryStatus").value = document.getElementById("updateEntryStatus").value;
      const updateModal = new bootstrap.Modal(document.getElementById("updateEntryModal"));
      updateModal.show();
    }, {
      key: "entry-update-modal",
      disableWhileRunning: () => document.querySelectorAll(".update-button, .people-calendar-edit"),
    });
    return true;
  } catch (error) {
    console.error("Error fetching entry lookups:", error);
    showToast(t("dashboard.entryOptionsError"), "error");
    return false;
  }
}

async function deleteEntry(button, employeeCodeOverride = "") {
  const employeeCode = String(employeeCodeOverride || document.getElementById("employeeSelect").value || "").trim();
  const date = button.getAttribute("data-date");
  const punchIn = button.getAttribute("data-punchin");
  const entryId = button.getAttribute("data-entryid") || "";
  const managerMessage = window.prompt(t("dashboard.deleteManagerMessagePrompt"), "");

  if (!window.confirm(t("dashboard.deleteConfirm"))) {
    return;
  }

  if (managerMessage === null) {
    return;
  }

  if (!String(managerMessage).trim()) {
    showToast(t("dashboard.managerMessageRequired"), "error");
    return;
  }

  try {
    await runButtonAction(button, async () => {
      const response = await fetch(apiUrl + `employee/${employeeCode}`, {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ entryId, date, punchIn, message: managerMessage.trim() }),
      });
      await parseResponse(response);
      dashboardState.entriesByEmployee[employeeCode] = undefined;
      showToast(t("dashboard.entryDeleted"), "success");
      await refreshAfterEntryMutation(employeeCode);
    }, { key: getDashboardEntryActionKey(button, employeeCode) });
  } catch (error) {
    console.error("Error deleting entry:", error);
    showToast(t("dashboard.entryDeleteError", { message: error.message }), "error");
  }
}

function requestEntryRejectionNote(button, employeeCode, employeeName) {
  const element = document.getElementById("entryRejectionModal");
  if (!employeeCode || element.dataset.active) return Promise.resolve(null);
  const form = document.getElementById("entryRejectionForm");
  const note = document.getElementById("entryRejectionNote");
  const submit = document.getElementById("entryRejectionSubmit");
  const timeRange = formatQueueTitle({
    punchIn: button.dataset.punchin, punchOut: button.dataset.punchout,
  });
  const name = employeeName || button.dataset.employeeName || getDashboardEmployeeByCodeValue(employeeCode)?.name || employeeCode;
  const context = document.getElementById("entryRejectionContext");
  context.textContent = [name, formatDateLabel(button.dataset.date), timeRange].filter(Boolean).join(" · ");
  const token = getSessionToken();
  note.value = "";
  submit.disabled = true;
  element.dataset.active = "true";
  const modal = bootstrap.Modal.getOrCreateInstance(element);
  return new Promise(resolve => {
    let message = null;
    let cancelled = false;
    const cancel = () => {
      cancelled = true;
      message = null;
      note.value = "";
      context.textContent = "";
      modal.hide();
    };
    window.cancelEntryRejection = cancel;
    const onInput = () => { submit.disabled = !note.value.trim(); };
    const onSubmit = event => {
      event.preventDefault();
      message = note.value.trim() || null;
      if (message) modal.hide();
    };
    note.addEventListener("input", onInput);
    form.addEventListener("submit", onSubmit);
    element.addEventListener("shown.bs.modal", () => {
      if (cancelled) modal.hide();
      else note.focus();
    }, { once: true });
    element.addEventListener("hidden.bs.modal", () => {
      delete element.dataset.active;
      if (window.cancelEntryRejection === cancel) delete window.cancelEntryRejection;
      note.removeEventListener("input", onInput);
      form.removeEventListener("submit", onSubmit);
      note.value = "";
      context.textContent = "";
      if (getSessionToken() !== token) { resolve(null); return; }
      if (button.isConnected) button.focus({ preventScroll: true });
      resolve(message);
    }, { once: true });
    modal.show();
  });
}

async function updateApprovalAction(button, newStatus) {
  const employeeCode = document.getElementById("employeeSelect").value;
  const date = button.getAttribute("data-date");
  const punchIn = button.getAttribute("data-punchin");
  const entryId = button.getAttribute("data-entryid") || "";
  const managerMessage = newStatus === "rejected" ? await requestEntryRejectionNote(button, employeeCode) : "";
  if (managerMessage === null) return;

  try {
    await runButtonAction(button, async () => {
      const response = await fetch(apiUrl + "employee/approval/" + employeeCode, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ entryId, date, punchIn, status: newStatus, message: managerMessage }),
      });
      await parseResponse(response);
      dashboardState.entriesByEmployee[employeeCode] = undefined;
      showToast(t("dashboard.entryUpdated"), "success");
      await refreshAfterEntryMutation(employeeCode);
    }, { key: getDashboardEntryActionKey(button, employeeCode) });
  } catch (error) {
    console.error("Approval update error:", error);
    showToast(t("dashboard.approvalError", { message: error.message }), "error");
  }
}

async function updateApprovalActionInApprovals(button, employeeCode, newStatus) {
  const date = button.getAttribute("data-date");
  const punchIn = button.getAttribute("data-punchin");
  const entryId = button.getAttribute("data-entryid") || "";
  const managerMessage = newStatus === "rejected" ? await requestEntryRejectionNote(button, employeeCode) : "";
  if (managerMessage === null) return;
  try {
    await runButtonAction(button, async () => {
      const response = await fetch(apiUrl + "employee/approval/" + employeeCode, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ entryId, date, punchIn, status: newStatus, message: managerMessage }),
      });
      await parseResponse(response);
      dashboardState.entriesByEmployee[employeeCode] = undefined;
      showToast(t("dashboard.entryUpdated"), "success");
      await refreshAfterEntryMutation(employeeCode);
    }, { key: getDashboardEntryActionKey(button, employeeCode) });
  } catch (error) {
    console.error("Approval update error in Approvals view:", error);
    showToast(t("dashboard.genericApprovalError"), "error");
  }
}

async function updateApprovalActionInDashboardQueue(button, employeeCode, newStatus) {
  const date = button.getAttribute("data-date");
  const punchIn = button.getAttribute("data-punchin");
  const entryId = button.getAttribute("data-entryid") || "";
  const managerMessage = newStatus === "rejected" ? await requestEntryRejectionNote(button, employeeCode) : "";
  if (managerMessage === null) return;
  try {
    await runButtonAction(button, async () => {
      const response = await fetch(apiUrl + "employee/approval/" + employeeCode, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ entryId, date, punchIn, status: newStatus, message: managerMessage }),
      });
      await parseResponse(response);
      dashboardState.entriesByEmployee[employeeCode] = undefined;
      showToast(t("dashboard.entryUpdated"), "success");
      await refreshAfterEntryMutation(employeeCode);
    }, { key: getDashboardEntryActionKey(button, employeeCode) });
  } catch (error) {
    console.error("Dashboard queue approval error:", error);
    showToast(t("dashboard.genericApprovalError"), "error");
  }
}

async function focusDashboardEmployee(employeeCode) {
  setDashboardSelectedEmployee(employeeCode);
  if (typeof showView === "function") {
    showView("dashboardView");
  }
  await fetchEmployeeData();
}

window.focusDashboardEmployee = focusDashboardEmployee;

async function openEmployeeFileFromDashboard(employeeCode, projectCode = "", entryId = "") {
  const normalizedEmployeeCode = String(employeeCode || "").trim();
  if (!normalizedEmployeeCode) {
    return;
  }

  setDashboardSelectedEmployee(normalizedEmployeeCode);

  if (typeof window.openPeopleProjectFilter === "function") {
    await window.openPeopleProjectFilter(normalizedEmployeeCode, String(projectCode || "").trim(), String(entryId || "").trim());
    return;
  }

  await focusDashboardEmployee(normalizedEmployeeCode);
}

window.openEmployeeFileFromDashboard = openEmployeeFileFromDashboard;

document.getElementById("employeeSelect").addEventListener("change", event => {
  localStorage.setItem("selectedEmployee", event.target.value);
  syncDashboardEmployeeSearchInput(event.target.value);
  fetchEmployeeData();
});
document.getElementById("dashboardEmployeeSearchInput").addEventListener("input", scheduleDashboardEmployeeSearchResolve);
document.getElementById("dashboardEmployeeSearchInput").addEventListener("change", () => {
  resolveDashboardEmployeeSearchInput({ forceSync: true });
});

document.getElementById("startDateFilter").addEventListener("input", fetchEmployeeData);
document.getElementById("endDateFilter").addEventListener("input", fetchEmployeeData);
document.getElementById("projectFilter").addEventListener("change", fetchEmployeeData);
document.getElementById("latestCheck").addEventListener("change", fetchEmployeeData);
document.getElementById("dashboardResetFiltersBtn").addEventListener("click", event => {
  document.getElementById("startDateFilter").value = "";
  document.getElementById("endDateFilter").value = "";
  document.getElementById("projectFilter").value = "";
  document.getElementById("latestCheck").checked = true;
  runButtonAction(event.currentTarget, fetchEmployeeData, { key: "dashboard-filter-refresh" });
});
document.getElementById("addEntryButton").addEventListener("click", event => {
  openAddEntryModal("", event.currentTarget).catch(error => {
    console.error("Error opening add entry modal:", error);
    showToast(t("dashboard.entryOptionsError"), "error");
  });
});

document.querySelectorAll('input[name="addEntryType"]').forEach(input => {
  input.addEventListener("change", event => {
    const addEntryForm = document.getElementById("addEntryForm");
    const employeeCode = addEntryForm.dataset.employeeCode || document.getElementById("employeeSelect").value;
    setAddEntryModalType(
      event.currentTarget.value,
      getDashboardEmployeeByCodeValue(employeeCode),
      addEntryForm.dataset.diverseAllowed === "true",
    );
  });
});

document.getElementById("saveAddEntryBtn").addEventListener("click", async event => {
  const saveButton = event.currentTarget;
  const addEntryForm = document.getElementById("addEntryForm");
  const employeeCode = addEntryForm.dataset.employeeCode || document.getElementById("employeeSelect").value;
  const entryType = getSelectedAddEntryType();
  const date = document.getElementById("addEntryDate").value;
  if (!employeeCode || !date) {
    showToast(t("dashboard.selectEmployeeAndDate"), "error");
    return;
  }

  const punchInHours = document.getElementById("addPunchInHours").value.trim();
  const punchInMinutes = document.getElementById("addPunchInMinutes").value.trim();
  const punchOutHours = document.getElementById("addPunchOutHours").value.trim();
  const punchOutMinutes = document.getElementById("addPunchOutMinutes").value.trim();
  const projectCode = document.getElementById("addProjectCode").value;
  const overtimeCode = document.getElementById("addOvertimeCode").value;
  const paymentOption = document.getElementById("addPaymentOption").value;
  const reasonCode = document.getElementById("addReasonCode").value;
  const workComment = document.getElementById("addWorkComment").value.trim();
  const diverseReason = document.getElementById("addDiverseReason").value.trim();
  const diverseSummary = document.getElementById("addDiverseSummary").value.trim();
  const managerMessage = document.getElementById("addManagerMessage").value.trim();

  const diverseAllowedForTarget = addEntryForm.dataset.diverseAllowed === "true";
  if (entryType === "diverse" && (!diverseAllowedForTarget || typeof isSuperAdminUser !== "function" || !isSuperAdminUser())) {
    showToast(t("dashboard.diversePrivilegeRequired"), "error");
    setAddEntryModalType("overtime", null, false);
    return;
  }

  if (!punchInHours || !punchInMinutes || !punchOutHours || !punchOutMinutes) {
    showToast(t("dashboard.fillAllTimeFields"), "error");
    return;
  }

  if (entryType === "overtime" && !projectCode) {
    showToast(t("dashboard.selectProject"), "error");
    return;
  }

  if (entryType === "overtime" && !paymentOption) {
    showToast(t("dashboard.selectPaymentOption"), "error");
    return;
  }

  if (entryType === "diverse" && !diverseReason) {
    showToast(t("self.diverseReasonRequired"), "error");
    return;
  }

  if (entryType === "diverse" && !diverseSummary) {
    showToast(t("self.diverseSummaryRequired"), "error");
    return;
  }

  const twoDigitRegex = /^[0-9]{1,2}$/;
  if (!twoDigitRegex.test(punchInHours) || !twoDigitRegex.test(punchInMinutes) || !twoDigitRegex.test(punchOutHours) || !twoDigitRegex.test(punchOutMinutes)) {
    showToast(t("dashboard.numericTimeValidation"), "error");
    return;
  }

  const punchInTime = `${punchInHours.padStart(2, "0")}:${punchInMinutes.padStart(2, "0")}:00`;
  const punchOutTime = `${punchOutHours.padStart(2, "0")}:${punchOutMinutes.padStart(2, "0")}:00`;
  if (new Date(`${date}T${punchOutTime}`) <= new Date(`${date}T${punchInTime}`)) {
    showToast(t("dashboard.punchOutAfterPunchIn"), "error");
    return;
  }

  try {
    await runButtonAction(saveButton, async () => {
      const entryPayload = {
        entryType,
        date,
        punchIn: punchInTime,
        punchOut: punchOutTime,
        status: "pending",
        message: managerMessage,
      };
      if (entryType === "diverse") {
        entryPayload.diverseReason = diverseReason;
        entryPayload.diverseSummary = diverseSummary;
      } else {
        entryPayload.projectCode = projectCode;
        entryPayload.overtimeCode = overtimeCode;
        entryPayload.paymentOption = paymentOption;
        entryPayload.reasonCode = reasonCode;
        entryPayload.workComment = workComment;
      }
      const response = await fetch(apiUrl + "employee/add/" + employeeCode, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(entryPayload),
      });
      await parseResponse(response);
      bootstrap.Modal.getInstance(document.getElementById("addEntryModal")).hide();
      const refreshPeopleEmployee = addEntryForm.dataset.refreshPeopleEmployee || "";
      addEntryForm.dataset.employeeCode = "";
      addEntryForm.dataset.refreshPeopleEmployee = "";
      dashboardState.entriesByEmployee[employeeCode] = undefined;
      showToast(t("dashboard.entryAdded"), "success");
      await refreshAfterEntryMutation(employeeCode, refreshPeopleEmployee);
    }, { key: `entry-add:${employeeCode}:${entryType}:${date}:${punchInTime}` });
  } catch (error) {
    console.error("Error adding entry:", error);
    showToast(t("dashboard.entryAddError", { message: error.message }), "error");
  }
});

document.getElementById("saveUpdateBtn").addEventListener("click", async event => {
  const saveButton = event.currentTarget;
  const employeeCode = document.getElementById("updateEntryForm").dataset.employeeCode || document.getElementById("employeeSelect").value;
  const originalDate = document.getElementById("originalDate").value;
  const updateDateInput = document.getElementById("updateDate");
  const newDate = updateDateInput.value;
  const originalPunchIn = document.getElementById("originalPunchIn").value;
  const originalPunchOut = document.getElementById("originalPunchOut").value || null;
  const originalExactPunchIn = document.getElementById("updateEntryForm").dataset.originalExactPunchIn || originalPunchIn;
  const originalExactPunchOut = document.getElementById("updateEntryForm").dataset.originalExactPunchOut || originalPunchOut || "";
  const entryId = document.getElementById("updateEntryId").value;
  const punchInHours = document.getElementById("updatePunchInHours").value.trim();
  const punchInMinutes = document.getElementById("updatePunchInMinutes").value.trim();
  const punchOutHours = document.getElementById("updatePunchOutHours").value.trim();
  const punchOutMinutes = document.getElementById("updatePunchOutMinutes").value.trim();
  const projectCode = document.getElementById("updateProjectCode").value;
  const originalProjectCode = document.getElementById("originalProjectCode").value;
  const overtimeCode = document.getElementById("updateOvertimeCode").value;
  const originalOvertimeCode = document.getElementById("originalOvertimeCode").value;
  const paymentOption = document.getElementById("updatePaymentOption").value;
  const originalPaymentOption = document.getElementById("originalPaymentOption").value;
  const reasonCode = document.getElementById("updateReasonCode").value;
  const originalReasonCode = document.getElementById("originalReasonCode").value;
  const entryType = document.getElementById("updateEntryType").value || "overtime";
  const workScheduleInput = document.getElementById("updateWorkSchedule");
  const workSchedule = workScheduleInput.value;
  const originalWorkSchedule = document.getElementById("updateEntryForm").dataset.originalWorkSchedule || "unconfirmed";
  const holidayValue = document.getElementById("updateITHolidaySchedule").value;
  const originalHolidayValue = document.getElementById("updateEntryForm").dataset.originalHolidaySchedule || "";
  const holidayNotScheduledWorkday = holidayValue === "" ? null : holidayValue === "true";
  const diverseReason = document.getElementById("updateDiverseReason").value.trim();
  const originalDiverseReason = document.getElementById("originalDiverseReason").value;
  const entryStatus = document.getElementById("updateEntryStatus").value;
  const originalEntryStatus = document.getElementById("originalEntryStatus").value || "pending";
  const managerMessage = document.getElementById("updateManagerMessage").value.trim();
  const noteChanged = managerMessage !== (document.getElementById("updateEntryForm").dataset.originalManagerMessage || "");
  const timeFromInputs = (hours, minutes, original) => {
    if (!hours && !minutes) return "";
    const hhmm = `${hours.padStart(2, "0")}:${minutes.padStart(2, "0")}`;
    return original && original.slice(0, 5) === hhmm ? original : `${hhmm}:00`;
  };
  const newPunchInBackend = timeFromInputs(punchInHours, punchInMinutes, originalExactPunchIn);
  const punchOutBackend = timeFromInputs(punchOutHours, punchOutMinutes, originalExactPunchOut);
  const overtimeFieldsUnchanged = projectCode === originalProjectCode && overtimeCode === originalOvertimeCode && paymentOption === originalPaymentOption && reasonCode === originalReasonCode && holidayValue === originalHolidayValue;
  const typeSpecificFieldsUnchanged = entryType === "diverse" ? diverseReason === originalDiverseReason.trim() : overtimeFieldsUnchanged;
  const fieldsUnchanged = newDate === originalDate && newPunchInBackend === originalExactPunchIn && punchOutBackend === originalExactPunchOut &&
    (workSchedule === originalWorkSchedule || (!workSchedule && originalWorkSchedule === "unconfirmed")) && typeSpecificFieldsUnchanged && entryStatus === originalEntryStatus;
  if (fieldsUnchanged && !noteChanged) {
    showToast(t("dashboard.noChanges"), "info");
    return;
  }

  if (!fieldsUnchanged) {
    if (!updateDateInput.checkValidity()) {
      updateDateInput.reportValidity();
      return;
    }

    if (!workScheduleInput.checkValidity()) {
      workScheduleInput.reportValidity();
      return;
    }

    if (!punchInHours || !punchInMinutes || !punchOutHours || !punchOutMinutes) {
      showToast(t("dashboard.fillAllTimeFields"), "error");
      return;
    }

    const twoDigitRegex = /^[0-9]{1,2}$/;
    if (!twoDigitRegex.test(punchInHours) || !twoDigitRegex.test(punchInMinutes) || !twoDigitRegex.test(punchOutHours) || !twoDigitRegex.test(punchOutMinutes)) {
      showToast(t("dashboard.numericTimeValidation"), "error");
      return;
    }

    if (entryType === "diverse" && !diverseReason) {
      showToast(t("self.diverseReasonRequired"), "error");
      return;
    }

    if (entryType !== "diverse" && (!projectCode || !paymentOption)) {
      showToast(t("dashboard.projectAndCodeRequired"), "error");
      return;
    }

    if (!managerMessage) {
      showToast(t("dashboard.managerMessageRequired"), "error");
      return;
    }

    if (!["approved", "rejected", "pending"].includes(entryStatus)) {
      showToast(t("dashboard.invalidStatus"), "error");
      return;
    }

    if (new Date(`${newDate}T${punchOutBackend}`) <= new Date(`${newDate}T${newPunchInBackend}`)) {
      showToast(t("dashboard.punchOutAfterPunchIn"), "error");
      return;
    }
  }

  try {
    await runButtonAction(saveButton, async () => {
      const requestPath = fieldsUnchanged ? "employee/message/" + employeeCode : "employee/" + employeeCode;
      const body = fieldsUnchanged ? { entryId, date: originalDate, punchIn: originalPunchIn, message: managerMessage } : {
        entryId, entryType, workSchedule, date: originalDate, newDate, originalPunchIn,
        newPunchIn: newPunchInBackend, punchOut: punchOutBackend, status: entryStatus, message: managerMessage, messageChanged: noteChanged,
        ...(entryType === "diverse" ? { diverseReason } : {
          projectCode, overtimeCode, paymentOption, reasonCode,
          ...(holidayValue !== originalHolidayValue ? { holidayNotScheduledWorkday } : {}),
        }),
      };
      const response = await fetch(apiUrl + requestPath, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      await parseResponse(response);
      const refreshPeopleEmployee = document.getElementById("updateEntryForm").dataset.refreshPeopleEmployee || "";
      bootstrap.Modal.getInstance(document.getElementById("updateEntryModal")).hide();
      document.getElementById("updateEntryForm").dataset.refreshPeopleEmployee = "";
      document.getElementById("updateEntryForm").dataset.employeeCode = "";
      dashboardState.entriesByEmployee[employeeCode] = undefined;
      showToast(t("dashboard.entryUpdated"), "success");
      await refreshAfterEntryMutation(employeeCode, refreshPeopleEmployee);
    }, { key: `entry:${employeeCode}:${entryId || `${originalDate}:${originalPunchIn}`}` });
  } catch (error) {
    console.error("Error updating entry:", error);
    showToast(t("dashboard.entryUpdateError", { message: error.message }), "error");
  }
});

document.getElementById("punchClockEntries").addEventListener("click", event => {
  const noteButton = event.target.closest(".dashboard-note-edit-button");
  if (noteButton) {
    openDashboardNoteEditor(noteButton);
    return;
  }

  const updateButton = event.target.closest(".update-button");
  if (updateButton) {
    openUpdateModal(updateButton);
    return;
  }

  const deleteButton = event.target.closest(".delete-button");
  if (deleteButton) {
    deleteEntry(deleteButton);
    return;
  }

  const approveButton = event.target.closest(".approve-btn");
  if (approveButton) {
    updateApprovalAction(approveButton, "approved");
    return;
  }

  const rejectButton = event.target.closest(".reject-btn");
  if (rejectButton) {
    updateApprovalAction(rejectButton, "rejected");
  }
});

document.getElementById("dashboardApprovalQueue").addEventListener("click", event => {
  const approveButton = event.target.closest(".dashboard-approve-button");
  if (approveButton) {
    updateApprovalActionInDashboardQueue(approveButton, approveButton.getAttribute("data-employee-code"), "approved");
    return;
  }

  const rejectButton = event.target.closest(".dashboard-reject-button");
  if (rejectButton) {
    updateApprovalActionInDashboardQueue(rejectButton, rejectButton.getAttribute("data-employee-code"), "rejected");
    return;
  }

  const jumpButton = event.target.closest(".dashboard-jump-button");
  if (jumpButton) {
    const employeeCode = jumpButton.getAttribute("data-employee-code");
    const projectCode = jumpButton.getAttribute("data-project-code");
    runButtonAction(jumpButton, () => openEmployeeFileFromDashboard(employeeCode, projectCode), {
      key: "open-employee",
    }).catch(error => {
      console.error("Unable to open employee file:", error);
      showToast(t("employees.loadError"), "error");
    });
  }
});

document.getElementById("dashboardActiveList").addEventListener("click", event => {
  const jumpButton = event.target.closest(".dashboard-jump-button");
  if (jumpButton) {
    const employeeCode = jumpButton.getAttribute("data-employee-code");
    const projectCode = jumpButton.getAttribute("data-project-code");
    runButtonAction(jumpButton, () => openEmployeeFileFromDashboard(employeeCode, projectCode), {
      key: "open-employee",
    }).catch(error => {
      console.error("Unable to open employee file:", error);
      showToast(t("employees.loadError"), "error");
    });
  }
});

document.getElementById("dashboardSaveNoteBtn").addEventListener("click", event => {
  saveDashboardNoteFromModal(event.currentTarget);
});
