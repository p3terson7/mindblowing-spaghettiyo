let allHistoryEntries = [];
let filteredHistoryEntriesByCategory = createEmptyHistoryCategories();
let historyFilterTimerId = null;
const historyPageState = { requested: false, stale: true, page: 1, sequence: 0, key: "", pending: null };
function setReviewHistoryOpen(open) {
  document.getElementById("historySection")?.classList.toggle("d-none", !open);
  document.getElementById("historyWorkspace")?.classList.toggle("d-none", !open);
  document.getElementById("loadHistoryBtn")?.setAttribute("aria-expanded", String(open));
}
window.closeReviewHistory = () => setReviewHistoryOpen(false);
window.resetReviewHistory = function () {
  historyPageState.sequence++;
  Object.assign(historyPageState, { requested: false, stale: true, page: 1, key: "", pending: null });
  allHistoryEntries = [];
  setReviewHistoryOpen(false);
  Object.values(HISTORY_TAB_CONFIG).forEach(config => document.getElementById(config.containerId)?.replaceChildren());
};
window.invalidateReviewHistory = function () {
  historyPageState.stale = true;
  historyPageState.sequence++;
};
window.refreshReviewHistoryIfVisible = function () {
  if (document.getElementById("adminView")?.classList.contains("active") && !document.getElementById("historyWorkspace")?.classList.contains("d-none")) return fetchHistory(historyPageState.page);
};

const HISTORY_FILTER_DEBOUNCE_MS = 150;
const HISTORY_TAB_CONFIG = {
  "all-history-tab": { category: "all", containerId: "allHistoryContainer", skeletonCount: 4 },
  "add-history-tab": { category: "add", containerId: "addHistoryContainer", skeletonCount: 3 },
  "edit-history-tab": { category: "update", containerId: "editHistoryContainer", skeletonCount: 3 },
  "approve-history-tab": { category: "approval", containerId: "approveHistoryContainer", skeletonCount: 3 },
  "delete-history-tab": { category: "delete", containerId: "deleteHistoryContainer", skeletonCount: 3 },
};

async function fetchHistory(page = 1) {
  historyPageState.requested = true;
  const config = getActiveHistoryTabConfig();
  const query = new URLSearchParams({ page: String(page), category: config.category,
    search: document.getElementById("historySearchInput").value,
    startDate: document.getElementById("historyStartDate").value,
    endDate: document.getElementById("historyEndDate").value });
  const key = query.toString();
  if (!historyPageState.stale && key === historyPageState.key) return historyPageState.pending || true;
  if (historyPageState.pending && key === historyPageState.key && !historyPageState.stale) return historyPageState.pending;
  const sequence = ++historyPageState.sequence;
  historyPageState.key = key;
  historyPageState.stale = false;
  const work = (async () => {
  try {
    setActiveHistoryLoadingState();
    const payload = await fetch(apiUrl + "history?" + key).then(parseResponse);
    if (sequence !== historyPageState.sequence) return false;
    allHistoryEntries = Array.isArray(payload.items) ? payload.items : [];
    historyPageState.page = payload.page;
    renderHistoryTabs(allHistoryEntries, config);
    const counts = payload.counts || {};
    [ ["all-history-tab", "history.all", counts.all], ["add-history-tab", "history.added", counts.add], ["edit-history-tab", "history.updated", counts.update], ["approve-history-tab", "history.approvedRejected", counts.approval], ["delete-history-tab", "history.deleted", counts.delete] ].forEach(([id, label, count]) => { document.getElementById(id).textContent = t(label, { count: count || 0 }); });
    const pager = document.getElementById("historyPagination");
    if (pager) pager.innerHTML = `<button type="button" class="btn btn-outline-secondary btn-sm" data-history-page="${payload.page - 1}" ${payload.page <= 1 ? "disabled" : ""} aria-label="Previous page">‹</button><span>${payload.page} / ${payload.totalPages} · ${payload.total}</span><button type="button" class="btn btn-outline-secondary btn-sm" data-history-page="${payload.page + 1}" ${payload.page >= payload.totalPages ? "disabled" : ""} aria-label="Next page">›</button>`;
    return true;
  } catch (error) {
    if (sequence !== historyPageState.sequence) return false;
    historyPageState.stale = true;
    console.error("Error fetching history:", error);
    showToast(t("history.fetchError"), "error");
    return false;
  }
  })();
  historyPageState.pending = work;
  try { return await work; } finally { if (sequence === historyPageState.sequence) historyPageState.pending = null; }
}

function formatHistoryTimestamp(timestamp) {
  return formatDateTimeStamp(timestamp);
}

function filterHistoryEntries(entries, searchTerm, startDate, endDate) {
  const tokens = window.Saphir.textSearch.tokenize(String(searchTerm || "").toLowerCase());

  return (entries || []).filter(entry => {
    if (!isDateWithinRange(String(entry.timestamp || "").split(" ")[0] || "", startDate, endDate)) {
      return false;
    }

    if (tokens.length === 0) {
      return true;
    }

    const combinedText = getHistorySearchText(entry);
    return window.Saphir.textSearch.matchesAll(combinedText, tokens);
  });
}

function getActionBadgeHtml(action) {
  const normalizedAction = String(action || "event").toLowerCase();
  const tone = normalizedAction === "add"
    ? "add"
    : normalizedAction === "update"
      ? "update"
      : normalizedAction === "approved"
        ? "approved"
        : normalizedAction === "rejected"
          ? "rejected"
          : normalizedAction === "delete" || normalizedAction === "archive"
            ? "delete"
            : "update";
  return `<span class="action-badge ${tone}">${escapeHtml(translateHistoryAction(action || "event"))}</span>`;
}

function updateHistoryTabLabels(allEntries, addedEntries, updatedEntries, approvalEntries, deletedEntries) {
  document.getElementById("all-history-tab").textContent = t("history.all", { count: allEntries.length });
  document.getElementById("add-history-tab").textContent = t("history.added", { count: addedEntries.length });
  document.getElementById("edit-history-tab").textContent = t("history.updated", { count: updatedEntries.length });
  document.getElementById("approve-history-tab").textContent = t("history.approvedRejected", { count: approvalEntries.length });
  document.getElementById("delete-history-tab").textContent = t("history.deleted", { count: deletedEntries.length });
}

function createEmptyHistoryCategories() {
  return {
    all: [],
    add: [],
    update: [],
    approval: [],
    delete: [],
  };
}

function groupHistoryEntries(entries) {
  const categories = createEmptyHistoryCategories();
  categories.all = Array.isArray(entries) ? entries : [];

  categories.all.forEach(entry => {
    const action = String(entry.action || "").toLowerCase();
    if (action === "add") {
      categories.add.push(entry);
    } else if (action === "update" || action === "restore") {
      categories.update.push(entry);
    } else if (action === "approved" || action === "rejected") {
      categories.approval.push(entry);
    } else if (action === "delete" || action === "archive") {
      categories.delete.push(entry);
    }
  });

  return categories;
}

function getHistoryTabConfig(tab) {
  return tab ? HISTORY_TAB_CONFIG[tab.id] || null : null;
}

function getActiveHistoryTabConfig() {
  const activeTab = document.querySelector("#historyTabs [data-bs-toggle='tab'].active");
  return getHistoryTabConfig(activeTab) || HISTORY_TAB_CONFIG["all-history-tab"];
}

function clearInactiveHistoryContainers(activeCategory) {
  Object.values(HISTORY_TAB_CONFIG).forEach(config => {
    if (config.category !== activeCategory) {
      document.getElementById(config.containerId).replaceChildren();
    }
  });
}

function isHistoryLoading() {
  return Object.values(HISTORY_TAB_CONFIG).some(config =>
    document.getElementById(config.containerId).querySelector(".loading-shell")
  );
}

function setActiveHistoryLoadingState() {
  const activeConfig = getActiveHistoryTabConfig();
  clearInactiveHistoryContainers(activeConfig.category);
  setLoadingState(activeConfig.containerId, "activity", activeConfig.skeletonCount);
}

function renderProjectHistory(entry) {
  const projectLabel = entry.projectName ? `${entry.projectName} (${entry.projectCode})` : entry.projectCode;
  const fieldLabels = {
    projectCode: "projects.projectCode", projectName: "history.projectName", sector: "projects.sector",
    admins: "projects.admins", backupAdmins: "projects.backupAdmins", colorKey: "projects.color",
    markerKey: "projects.marker", archived: "history.projectStatus",
  };
  function formatValue(field, value) {
    if (value === "" || value == null) return t("history.projectEmptyValue");
    if (field === "archived") return t(value ? "projects.archived" : "history.projectActive");
    if (field === "colorKey" || field === "markerKey") {
      return t(`projects.${field === "colorKey" ? "color" : "marker"}.${value}`);
    }
    return String(value);
  }
  const changes = (Array.isArray(entry.projectChanges) ? entry.projectChanges : [])
    .filter(change => change && Object.hasOwn(fieldLabels, change.field));
  return `
    <div class="timeline-card-subject">${escapeHtml(t("history.concernedProject", { name: projectLabel }))}</div>
    ${changes.length ? `<ul class="timeline-card-message mb-0">${changes.map(({ field, before, after }) =>
      `<li>${escapeHtml(t(fieldLabels[field]))}: ${escapeHtml(formatValue(field, before))} → <strong>${escapeHtml(formatValue(field, after))}</strong></li>`
    ).join("")}</ul>` : ""}
  `;
}

function renderHistoryList(container, entries) {
  const sortedEntries = (entries || []).slice().sort((left, right) => new Date(right.timestamp) - new Date(left.timestamp));
  if (sortedEntries.length === 0) {
    container.innerHTML = createEmptyState(t("history.none"));
    return;
  }

  container.innerHTML = `<div class="activity-feed">${sortedEntries.map(entry => `
    <article class="timeline-card">
      <div class="review-card-header">
        <div>
          <strong>${escapeHtml(getHistoryAuthorName(entry))}</strong>
          <div class="worklog-secondary">${escapeHtml(formatHistoryTimestamp(entry.timestamp))} | ${escapeHtml(formatRelativeTime(entry.timestamp))}</div>
        </div>
        ${getActionBadgeHtml(entry.action)}
      </div>
      ${entry.projectCode ? renderProjectHistory(entry) : `
        ${renderHistorySubjectLine(entry)}
        <div class="timeline-card-message">${renderAuditMessage(entry.message || t("shared.noMessage"))}</div>
      `}
    </article>
  `).join("")}</div>`;
}

function renderHistoryCategory(config, clearInactive = true) {
  if (!config) {
    return;
  }

  renderHistoryList(
    document.getElementById(config.containerId),
    filteredHistoryEntriesByCategory[config.category]
  );

  if (clearInactive) {
    clearInactiveHistoryContainers(config.category);
  }
}

function renderHistoryTabs(historyEntries, targetConfig, clearInactive = true) {
  filteredHistoryEntriesByCategory = groupHistoryEntries(historyEntries);

  updateHistoryTabLabels(
    filteredHistoryEntriesByCategory.all,
    filteredHistoryEntriesByCategory.add,
    filteredHistoryEntriesByCategory.update,
    filteredHistoryEntriesByCategory.approval,
    filteredHistoryEntriesByCategory.delete
  );
  renderHistoryCategory(targetConfig || getActiveHistoryTabConfig(), clearInactive);
}

function applyHistoryFilters(targetConfig, clearInactive = true) {
  if (historyPageState.requested) {
    historyPageState.stale = true;
    if (!document.getElementById("historyWorkspace")?.classList.contains("d-none")) return fetchHistory(1);
    return;
  }
  if (historyFilterTimerId !== null) {
    window.clearTimeout(historyFilterTimerId);
    historyFilterTimerId = null;
  }

  const searchTerm = document.getElementById("historySearchInput").value;
  const startDate = document.getElementById("historyStartDate").value;
  const endDate = document.getElementById("historyEndDate").value;
  const filtered = filterHistoryEntries(allHistoryEntries, searchTerm, startDate, endDate);
  renderHistoryTabs(filtered, targetConfig, clearInactive);
}

function scheduleHistoryFilterUpdate() {
  if (historyFilterTimerId !== null) {
    window.clearTimeout(historyFilterTimerId);
  }

  historyFilterTimerId = window.setTimeout(() => {
    historyFilterTimerId = null;
    applyHistoryFilters();
  }, HISTORY_FILTER_DEBOUNCE_MS);
}

document.getElementById("historySearchInput").addEventListener("input", scheduleHistoryFilterUpdate);
document.getElementById("historyStartDate").addEventListener("input", scheduleHistoryFilterUpdate);
document.getElementById("historyEndDate").addEventListener("input", scheduleHistoryFilterUpdate);
document.getElementById("historyResetFiltersBtn").addEventListener("click", () => {
  document.getElementById("historySearchInput").value = "";
  document.getElementById("historyStartDate").value = "";
  document.getElementById("historyEndDate").value = "";
  applyHistoryFilters();
});

document.getElementById("historyTabs").addEventListener("show.bs.tab", event => {
  const targetConfig = getHistoryTabConfig(event.target);
  if (!targetConfig) {
    return;
  }
  if (historyPageState.requested) return;

  if (isHistoryLoading()) {
    setLoadingState(targetConfig.containerId, "activity", targetConfig.skeletonCount);
    return;
  }

  if (historyFilterTimerId !== null) {
    applyHistoryFilters(targetConfig, false);
    return;
  }

  renderHistoryCategory(targetConfig, false);
});

document.getElementById("historyTabs").addEventListener("shown.bs.tab", event => {
  const targetConfig = getHistoryTabConfig(event.target);
  if (targetConfig) {
    if (historyPageState.requested) { fetchHistory(1); return; }
    clearInactiveHistoryContainers(targetConfig.category);
  }
});

document.getElementById("refreshHistoryBtn").addEventListener("click", async event => {
  await runButtonAction(event.currentTarget, async () => {
    setReviewHistoryOpen(true);
    historyPageState.stale = true;
    await fetchHistory();
  }, { key: "review-refresh" });
});
updateHistoryTabLabels([], [], [], [], []);
document.getElementById("loadHistoryBtn")?.addEventListener("click", async () => {
  const workspace = document.getElementById("historyWorkspace");
  const opening = workspace.classList.contains("d-none");
  setReviewHistoryOpen(opening);
  if (opening) {
    const heading = document.getElementById("reviewHistoryHeading");
    heading?.scrollIntoView({ block: "center" });
    heading?.focus({ preventScroll: true });
    await fetchHistory(historyPageState.page);
  }
});
document.getElementById("closeHistoryBtn")?.addEventListener("click", () => {
  setReviewHistoryOpen(false);
  document.getElementById("loadHistoryBtn")?.focus();
});
document.getElementById("historyPagination")?.addEventListener("click", event => {
  const button = event.target.closest("[data-history-page]");
  if (button && !button.disabled) fetchHistory(Number(button.dataset.historyPage));
});
