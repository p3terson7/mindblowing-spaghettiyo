﻿$entryStateModuleManifest = Join-Path -Path $PSScriptRoot -ChildPath "../modules/Saphir.EntryState.psd1"
if ($null -eq (Get-Module -Name "Saphir.EntryState")) {
    Import-Module -Name $entryStateModuleManifest -ErrorAction Stop | Out-Null
}
Remove-Variable -Name entryStateModuleManifest -ErrorAction SilentlyContinue

$businessRulesModuleManifest = Join-Path -Path $PSScriptRoot -ChildPath "../modules/Saphir.BusinessRules.psd1"
if ($null -eq (Get-Module -Name "Saphir.BusinessRules")) {
    Import-Module -Name $businessRulesModuleManifest -ErrorAction Stop | Out-Null
}
Remove-Variable -Name businessRulesModuleManifest -ErrorAction SilentlyContinue

if (-not $script:ReadModelCache) {
    $script:ReadModelCache = @{}
}

if (-not $script:ReadModelCacheVersion) {
    $script:ReadModelCacheVersion = $null
}

if (-not $script:EmployeeEntryFileCache) {
    $script:EmployeeEntryFileCache = @{}
}

if (-not $script:ReadModelSyncState) {
    $script:ReadModelSyncState = $null
}

if ($null -eq $script:ReadModelFactoryDepth) {
    $script:ReadModelFactoryDepth = 0
}
. (Join-Path $PSScriptRoot "ReadModelCacheService.ps1")
. (Join-Path $PSScriptRoot "EmployeeContributionService.ps1")
. (Join-Path $PSScriptRoot "EmployeeFileReadService.ps1")
. (Join-Path $PSScriptRoot "ProjectEntryReadService.ps1")

function Get-ReadModelSyncStateKey {
    param($State)

    if ($null -eq $State) {
        return "0"
    }

    if ($State.PSObject.Properties.Name -contains "changeId" -and -not [string]::IsNullOrWhiteSpace([string]$State.changeId)) {
        return [string]$State.changeId
    }

    return ("{0}|{1}|{2}|{3}" -f [string]$State.version, [string]$State.updatedAtUtc, [string]$State.category, [string]$State.resource)
}

function Test-ReadModelGuidValue {
    param($Value)

    $parsedGuid = [Guid]::Empty
    return (-not [string]::IsNullOrWhiteSpace([string]$Value) -and
        [Guid]::TryParse([string]$Value, [ref]$parsedGuid) -and
        $parsedGuid -ne [Guid]::Empty)
}

function Test-ReadModelEmployeeCode {
    param($Value)

    return (-not [string]::IsNullOrWhiteSpace([string]$Value) -and
        ([string]$Value).Trim() -match "^\d+$")
}

function Test-ReadModelSyncStateRevisionSchema {
    param($State)

    if ($null -eq $State) {
        return $false
    }

    $propertyNames = @($State.PSObject.Properties.Name)
    if (-not ($propertyNames -contains "changeId") -or
        -not ($propertyNames -contains "employeeDataEpoch") -or
        -not ($propertyNames -contains "employeeDataRevisions") -or
        -not (Test-ReadModelGuidValue -Value $State.changeId) -or
        -not (Test-ReadModelGuidValue -Value $State.employeeDataEpoch)) {
        return $false
    }

    $revisions = $State.employeeDataRevisions
    if ($null -eq $revisions -or
        -not (($revisions -is [System.Collections.IDictionary]) -or
        ($revisions.PSObject.TypeNames -contains "System.Management.Automation.PSCustomObject"))) {
        return $false
    }

    $revisionMap = ConvertTo-ReadModelEmployeeRevisionMap -Value $revisions
    foreach ($employeeCode in @($revisionMap.Keys)) {
        if (-not (Test-ReadModelEmployeeCode -Value $employeeCode) -or
            -not (Test-ReadModelGuidValue -Value $revisionMap[$employeeCode])) {
            return $false
        }
    }

    return $true
}

function ConvertTo-ReadModelEmployeeRevisionMap {
    param($Value)

    $result = @{}
    if ($Value -is [System.Collections.IDictionary]) {
        foreach ($key in @($Value.Keys)) {
            $result[[string]$key] = [string]$Value[$key]
        }
        return $result
    }

    if ($null -ne $Value -and ($Value.PSObject.TypeNames -contains "System.Management.Automation.PSCustomObject")) {
        foreach ($property in @($Value.PSObject.Properties)) {
            $result[[string]$property.Name] = [string]$property.Value
        }
    }

    return $result
}

function Test-ReadModelCurrentStateSupportsTargeting {
    param($State)

    if (-not (Test-ReadModelSyncStateRevisionSchema -State $State)) {
        return $false
    }

    $category = ([string]$State.category).Trim().ToLowerInvariant()
    if (@("history", "project", "auth", "sessions", "compensation", "budget-periods", "bug-reports") -contains $category) {
        return $true
    }

    if (@("employee", "employee-directory") -notcontains $category) {
        return $false
    }

    $resource = ([string]$State.resource).Trim()
    $changeId = [string]$State.changeId
    $revisionMap = ConvertTo-ReadModelEmployeeRevisionMap -Value $State.employeeDataRevisions
    if ($resource -eq "*") {
        foreach ($revision in @($revisionMap.Values)) {
            if ([string]$revision -eq $changeId) {
                return $true
            }
        }
        return $false
    }

    return ((Test-ReadModelEmployeeCode -Value $resource) -and
        $revisionMap.ContainsKey($resource) -and
        [string]$revisionMap[$resource] -eq $changeId)
}

function Clear-EmployeeEntryCacheForCode {
    param([Parameter(Mandatory = $true)][string]$EmployeeCode)

    $normalizedCode = $EmployeeCode.Trim()
    if ([string]::IsNullOrWhiteSpace($normalizedCode) -or
        $normalizedCode -eq "*" -or
        -not (Test-ReadModelEmployeeCode -Value $normalizedCode) -or
        [System.IO.Path]::GetFileName($normalizedCode) -ne $normalizedCode) {
        return $false
    }

    $dataFile = Join-Path -Path $sharedFolder -ChildPath ("{0}_data.json" -f $normalizedCode)
    $script:ReadModelSourceStamps.Remove($dataFile) | Out-Null
    Remove-DependentReadModels -ChangedSources @("employee:$normalizedCode")
    Clear-CachedFileContent -Path $dataFile
    if ($script:EmployeeEntryFileCache.ContainsKey($dataFile)) {
        $script:EmployeeEntryFileCache.Remove($dataFile) | Out-Null
    }
    return $true
}

function Clear-AllEmployeeEntryCaches {
    $employeeDataPaths = @{}
    foreach ($path in @($script:EmployeeEntryFileCache.Keys)) {
        $employeeDataPaths[[string]$path] = $true
    }

    foreach ($cacheName in @("TextFileCache", "BinaryFileCache", "FileMetadataCache")) {
        $cacheVariable = Get-Variable -Name $cacheName -Scope Script -ErrorAction SilentlyContinue
        if ($null -eq $cacheVariable -or $null -eq $cacheVariable.Value) {
            continue
        }

        foreach ($path in @($cacheVariable.Value.Keys)) {
            if ([System.IO.Path]::GetFileName([string]$path) -like "*_data.json") {
                $employeeDataPaths[[string]$path] = $true
            }
        }
    }

    foreach ($path in @($employeeDataPaths.Keys)) {
        Clear-CachedFileContent -Path ([string]$path)
    }
    $script:EmployeeEntryFileCache = @{}
    $script:ReadModelSourceStamps = @{}
}

function Clear-ReadModelFileCache {
    param([string]$Path)

    if (-not [string]::IsNullOrWhiteSpace([string]$Path)) {
        Clear-CachedFileContent -Path ([string]$Path)
    }
}

function Clear-AllReadModelCoreFileCaches {
    foreach ($corePath in @(
        $projectsFile,
        $mappingFile,
        $usersFile,
        $sessionsFile,
        $historyFile,
        $overtimeCodesFile,
        $paymentOptionsFile,
        $reasonCodesFile,
        $compensationGridFile,
        $budgetPeriodsFile,
        $bugReportsFile
    )) {
        Clear-ReadModelFileCache -Path ([string]$corePath)
    }

    $script:ProjectsCache = $null
    $script:EmployeeNameMapCache = $null
    $script:JsonOptionArrayCache = @{}
    if (Get-Command -Name Clear-AuthRuntimeCaches -ErrorAction SilentlyContinue) {
        Clear-AuthRuntimeCaches
    }
}

function Clear-ReadModelCoreCachesForChange {
    param(
        [string]$Category,
        [bool]$CanUseTargetedInvalidation
    )

    if (-not $CanUseTargetedInvalidation) {
        Clear-AllReadModelCoreFileCaches
        return
    }

    switch (([string]$Category).Trim().ToLowerInvariant()) {
        "history" {
            Clear-ReadModelFileCache -Path $historyFile
        }
        "employee" {
            # Entry mutations normally append audit history before publishing
            # their single employee revision. Some employee changes do not add
            # history, but clearing one small core cache is safer than retaining
            # an audit projection after a coalesced mutation.
            Clear-ReadModelFileCache -Path $historyFile
        }
        "project" {
            Clear-ReadModelFileCache -Path $projectsFile
            Clear-ReadModelFileCache -Path $historyFile
            $script:ProjectsCache = $null
            if (Get-Command -Name Clear-ProjectAccessRuntimeCaches -ErrorAction SilentlyContinue) {
                Clear-ProjectAccessRuntimeCaches
            }
            elseif (Get-Command -Name Clear-AuthRuntimeCaches -ErrorAction SilentlyContinue) {
                Clear-AuthRuntimeCaches
            }
        }
        "auth" {
            Clear-ReadModelFileCache -Path $usersFile
            Clear-ReadModelFileCache -Path $sessionsFile
            Clear-ReadModelFileCache -Path $historyFile
            if (Get-Command -Name Clear-AuthRuntimeCaches -ErrorAction SilentlyContinue) {
                Clear-AuthRuntimeCaches
            }
        }
        "sessions" {
            Clear-ReadModelFileCache -Path $sessionsFile
            if (Get-Command -Name Clear-AuthRuntimeCaches -ErrorAction SilentlyContinue) { Clear-AuthRuntimeCaches }
        }
        "employee-directory" {
            Clear-ReadModelFileCache -Path $usersFile
            Clear-ReadModelFileCache -Path $sessionsFile
            Clear-ReadModelFileCache -Path $mappingFile
            Clear-ReadModelFileCache -Path $historyFile
            $script:EmployeeNameMapCache = $null
            if (Get-Command -Name Clear-AuthRuntimeCaches -ErrorAction SilentlyContinue) {
                Clear-AuthRuntimeCaches
            }
        }
        "compensation" {
            # Amounts are persisted in employee files, never derived on reads.
            # The grid-save workflow publishes employee revisions when needed.
            Clear-ReadModelFileCache -Path $compensationGridFile
            Clear-ReadModelFileCache -Path $historyFile
            if (Get-Command -Name Clear-CompensationGridRuntimeCache -ErrorAction SilentlyContinue) {
                Clear-CompensationGridRuntimeCache
            }
        }
        "budget-periods" {
            # Budget calendars change only comparison boundaries. Keep employee
            # entry caches warm and invalidate the shared calendar plus the
            # audit history written by the same settings update.
            Clear-ReadModelFileCache -Path $budgetPeriodsFile
            Clear-ReadModelFileCache -Path $historyFile
            if (Get-Command -Name Clear-BudgetPeriodRuntimeCache -ErrorAction SilentlyContinue) {
                Clear-BudgetPeriodRuntimeCache
            }
        }
        "bug-reports" {
            # Bug reports are independent from overtime entries. Refresh only
            # their sidecar and the audit history produced by the same action.
            Clear-ReadModelFileCache -Path $bugReportsFile
            Clear-ReadModelFileCache -Path $historyFile
            if (Get-Command -Name Clear-BugReportRuntimeCache -ErrorAction SilentlyContinue) {
                Clear-BugReportRuntimeCache
            }
        }
        default {
            Clear-AllReadModelCoreFileCaches
        }
    }
}

function Sync-ReadModelCaches {
    $state = Get-SyncState
    $readFailed = [bool]$script:SyncStateReadFailed
    if ($readFailed -ne [bool]$script:ReadModelSyncReadFailed) {
        Remove-DependentReadModels
        Clear-AllEmployeeEntryCaches
        Clear-AllReadModelCoreFileCaches
        $script:ReadModelSyncReadFailed = $readFailed
    }
    Invoke-ReadModelSourceReconciliation
    $stateKey = Get-ReadModelSyncStateKey -State $state
    $sameIdentityConflict = $false
    if ($script:ReadModelCacheVersion -eq $stateKey) {
        # Reuse a stable observation (including a legacy/malformed state that
        # already caused a conservative fresh rebuild). Conflicting content
        # under the SAME identity is a protocol violation, never a cache hit.
        if ([object]::ReferenceEquals($script:ReadModelSyncState, $state)) { return }
        $fingerprint = Get-ReadModelStateFingerprint -State $state
        if ($fingerprint -ceq $script:ReadModelSyncStateFingerprint) {
            $script:ReadModelSyncState = $state
            return
        }
        $sameIdentityConflict = $true
    }

    $previousState = $script:ReadModelSyncState
    $changedSources = New-Object Collections.ArrayList
    $previousVersion = -1
    $currentVersion = -1
    $hasPreviousVersion = $null -ne $previousState -and
        ($previousState.PSObject.Properties.Name -contains "version") -and
        [int]::TryParse([string]$previousState.version, [ref]$previousVersion)
    $hasCurrentVersion = $null -ne $state -and
        ($state.PSObject.Properties.Name -contains "version") -and
        [int]::TryParse([string]$state.version, [ref]$currentVersion)
    $isSequentialChange = $hasPreviousVersion -and
        $hasCurrentVersion -and
        $currentVersion -eq ($previousVersion + 1)

    $canTargetEmployeeCaches = (-not $sameIdentityConflict) -and $hasPreviousVersion -and $hasCurrentVersion -and
        ($currentVersion -gt $previousVersion) -and (Test-ReadModelSyncStateRevisionSchema -State $previousState) -and
        (Test-ReadModelSyncStateRevisionSchema -State $state) -and
        (Test-ReadModelCurrentStateSupportsTargeting -State $state) -and
        ([string]$previousState.employeeDataEpoch -eq [string]$state.employeeDataEpoch)

    if (-not $canTargetEmployeeCaches) {
        [void]$changedSources.Add("*")
        Clear-AllEmployeeEntryCaches
    }
    else {
        $previousRevisions = ConvertTo-ReadModelEmployeeRevisionMap -Value $previousState.employeeDataRevisions
        $currentRevisions = ConvertTo-ReadModelEmployeeRevisionMap -Value $state.employeeDataRevisions
        $revisionCodes = @{}
        foreach ($employeeCode in @($previousRevisions.Keys)) {
            $revisionCodes[[string]$employeeCode] = $true
        }
        foreach ($employeeCode in @($currentRevisions.Keys)) {
            $revisionCodes[[string]$employeeCode] = $true
        }

        foreach ($employeeCode in @($revisionCodes.Keys)) {
            $previousRevision = if ($previousRevisions.ContainsKey($employeeCode)) { [string]$previousRevisions[$employeeCode] } else { "" }
            $currentRevision = if ($currentRevisions.ContainsKey($employeeCode)) { [string]$currentRevisions[$employeeCode] } else { "" }
            if ($previousRevision -ne $currentRevision) {
                [void]$changedSources.Add("employee:$employeeCode")
                if (-not (Clear-EmployeeEntryCacheForCode -EmployeeCode ([string]$employeeCode))) {
                    Clear-AllEmployeeEntryCaches
                    break
                }
            }
        }
    }

    $changedCategories = @(Get-ReadModelChangedCategories -PreviousState $previousState -CurrentState $state -Sequential:$isSequentialChange)
    if (-not $hasPreviousVersion -or -not $hasCurrentVersion -or $currentVersion -le $previousVersion -or -not $canTargetEmployeeCaches) {
        $changedCategories = @("*")
    }
    if ($changedCategories -contains "*" -and $state.PSObject.Properties.Name -contains "sourceRevisions") {
        # An advertised but inconsistent vector is not a trustworthy employee
        # authority either. Legacy gaps without this vector keep their previous
        # cumulative employee-map fallback; malformed NEW protocol is stricter.
        Clear-AllEmployeeEntryCaches
    }
    foreach ($category in $changedCategories) {
        switch ($category.Trim().ToLowerInvariant()) {
            "employee" { [void]$changedSources.Add("history") }
            "employee-directory" { foreach ($source in @("directory", "auth", "history")) { [void]$changedSources.Add($source) } }
            "auth" { foreach ($source in @("auth", "directory", "compensation", "history")) { [void]$changedSources.Add($source) } }
            "sessions" { [void]$changedSources.Add("sessions") }
            "project" { foreach ($source in @("projects", "history")) { [void]$changedSources.Add($source) } }
            "compensation" { foreach ($source in @("compensation", "history")) { [void]$changedSources.Add($source) } }
            "budget-periods" { foreach ($source in @("budget", "history")) { [void]$changedSources.Add($source) } }
            "bug-reports" { foreach ($source in @("bugs", "history")) { [void]$changedSources.Add($source) } }
            "history" { [void]$changedSources.Add("history") }
            default { [void]$changedSources.Add("*") }
        }
    }
    Remove-DependentReadModels -ChangedSources @($changedSources.ToArray())
    foreach ($category in $changedCategories) {
        Clear-ReadModelCoreCachesForChange -Category $category -CanUseTargetedInvalidation:($category -ne "*")
    }
    $script:ReadModelSyncState = $state
    $script:ReadModelSyncStateFingerprint = Get-ReadModelStateFingerprint -State $state
    $script:ReadModelCacheVersion = $stateKey
}

function Convert-SecondsToTimeText {
    param([double]$Seconds)

    $safeSeconds = [math]::Max(0, [int][math]::Round([double]$Seconds))
    $hours = [math]::Floor($safeSeconds / 3600)
    $minutes = [math]::Floor(($safeSeconds % 3600) / 60)
    $remainingSeconds = $safeSeconds % 60
    return ("{0:00}:{1:00}:{2:00}" -f $hours, $minutes, $remainingSeconds)
}

function Get-OvertimeSecondsFromText {
    param([string]$Value)

    if ([string]::IsNullOrWhiteSpace($Value) -or [string]$Value -eq "N/A") {
        return 0
    }

    try {
        return [int][math]::Round(([TimeSpan]::Parse([string]$Value)).TotalSeconds)
    }
    catch {
        return 0
    }
}

function Get-EntryDateOrNull {
    param($Entry)

    try {
        return [DateTime]::ParseExact([string]$Entry.date, "yyyy-MM-dd", $null)
    }
    catch {
        return $null
    }
}

function Get-EntryDateTimeOrMin {
    param($Entry)

    try {
        return [DateTime]::ParseExact(("{0} {1}" -f [string]$Entry.date, [string]$Entry.punchIn), "yyyy-MM-dd HH:mm:ss", $null)
    }
    catch {
        return [DateTime]::MinValue
    }
}

function Test-EntryOpen {
    param($Entry)

    return (Saphir.EntryState\Test-EntryOpen -Entry $Entry)
}

function Test-EntryPendingApproval {
    param($Entry)

    # A missing end time belongs to the attention queue, not the approval
    # queue. A closed entry can still carry a duration warning.
    return (-not [string]::IsNullOrWhiteSpace([string]$Entry.punchOut) -and
        ([string]$Entry.status).Trim() -in @("pending", "") -and
        -not (Test-EntryForgottenClockOut -Entry $Entry))
}

function New-EmployeeEntryProjection {
    param(
        [Parameter(Mandatory = $true)][string]$EmployeeCode,
        [Parameter(Mandatory = $true)][string]$EmployeeName,
        [Parameter(Mandatory = $true)]$Entry,
        [string]$EmployeeRole = "employee"
    )

    $entryType = Saphir.BusinessRules\ConvertTo-SaphirEntryType -Value $(if ($Entry.PSObject.Properties.Name -contains "entryType") { [string]$Entry.entryType } else { "" })
    $workSchedule = Saphir.BusinessRules\ConvertTo-SaphirWorkSchedule -Value $(if ($Entry.PSObject.Properties.Name -contains "workSchedule") { [string]$Entry.workSchedule } else { "" })
    $reviewIssues = @(Get-EntryReviewIssues -Entry $Entry)

    $projection = [PSCustomObject]@{
        entryId       = Get-EntryIdentifierValue -Entry $Entry
        entryType     = $entryType
        workSchedule  = $workSchedule
        workScheduleSource = if ($Entry.PSObject.Properties.Name -contains "workScheduleSource") { [string]$Entry.workScheduleSource } else { "" }
        name          = [string]$Entry.name
        date          = [string]$Entry.date
        punchIn       = [string]$Entry.punchIn
        exactPunchIn  = Get-EntryExactPunchInText -Entry $Entry
        punchOut      = if ($null -ne $Entry.punchOut) { [string]$Entry.punchOut } else { $null }
        exactPunchOut = Get-EntryExactPunchOutText -Entry $Entry
        overtime      = if ($null -ne $Entry.overtime) { [string]$Entry.overtime } else { $null }
        reviewIssues  = $reviewIssues
        hasReviewIssues = ($reviewIssues.Count -gt 0)
        status        = if ($null -ne $Entry.status) { [string]$Entry.status } else { "pending" }
        message       = if ($null -ne $Entry.message) { [string]$Entry.message } else { "" }
        messageAuthorName = if ($Entry.PSObject.Properties.Name -contains "messageAuthorName") { [string]$Entry.messageAuthorName } else { "" }
        messageAuthorUsername = if ($Entry.PSObject.Properties.Name -contains "messageAuthorUsername") { [string]$Entry.messageAuthorUsername } else { "" }
        messageUpdatedAt = if ($Entry.PSObject.Properties.Name -contains "messageUpdatedAt") { ConvertTo-EntryNoteTimestamp $Entry.messageUpdatedAt } else { "" }
        projectCode   = if ($null -ne $Entry.projectCode) { [string]$Entry.projectCode } else { "" }
        overtimeCode  = if ($null -ne $Entry.overtimeCode) { [string]$Entry.overtimeCode } else { "" }
        paymentOption = if ($null -ne $Entry.paymentOption -and -not [string]::IsNullOrWhiteSpace([string]$Entry.paymentOption)) { [string]$Entry.paymentOption } elseif ($entryType -eq "diverse") { "" } else { "cash" }
        reasonCode    = if ($null -ne $Entry.reasonCode) { [string]$Entry.reasonCode } else { "" }
        workComment   = if ($Entry.PSObject.Properties.Name -contains "workComment") { [string]$Entry.workComment } else { "" }
        diverseReason = if ($Entry.PSObject.Properties.Name -contains "diverseReason") { [string]$Entry.diverseReason } else { "" }
        diverseSummary = if ($Entry.PSObject.Properties.Name -contains "diverseSummary") { [string]$Entry.diverseSummary } else { "" }
        forgottenClockOut = Test-EntryForgottenClockOut -Entry $Entry
        needsClockOutReview = Test-EntryForgottenClockOut -Entry $Entry
        forgottenClockOutAttemptedDate = if ($Entry.PSObject.Properties.Name -contains "forgottenClockOutAttemptedDate") { [string]$Entry.forgottenClockOutAttemptedDate } else { "" }
        forgottenClockOutAttemptedTime = if ($Entry.PSObject.Properties.Name -contains "forgottenClockOutAttemptedTime") { [string]$Entry.forgottenClockOutAttemptedTime } else { "" }
        forgottenClockOutDetectedAtUtc = if ($Entry.PSObject.Properties.Name -contains "forgottenClockOutDetectedAtUtc") { [string]$Entry.forgottenClockOutDetectedAtUtc } else { "" }
        employeeCode  = $EmployeeCode
        employeeName  = $EmployeeName
        employeeRole  = Get-NormalizedRoleName -Role $EmployeeRole
    }
    if ($Entry.PSObject.Properties.Name -contains "employeeCommentAdditions") {
        $projection | Add-Member -NotePropertyName employeeCommentAdditions -NotePropertyValue @(Get-EntryEmployeeCommentAdditions $Entry)
    }
    if ($Entry.PSObject.Properties.Name -contains "holidayNotScheduledWorkday" -and $Entry.holidayNotScheduledWorkday -is [bool]) {
        $projection | Add-Member -NotePropertyName holidayNotScheduledWorkday -NotePropertyValue ([bool]$Entry.holidayNotScheduledWorkday)
    }
    return $projection
}

function New-EntryMonetaryReadModel {
    <#
        Exposes only the management-facing monetary result. The private
        compensation snapshot also contains salary, hourly-rate and HR
        classification data; those fields must never be copied into normal
        entry read models.
    #>
    param([Parameter(Mandatory = $true)]$Entry)

    $entryType = Saphir.BusinessRules\ConvertTo-SaphirEntryType -Value $(if ($Entry.PSObject.Properties.Name -contains "entryType") { [string]$Entry.entryType } else { "" })
    $status = if ($Entry.PSObject.Properties.Name -contains "status") { ([string]$Entry.status).Trim().ToLowerInvariant() } else { "pending" }
    if ($entryType -ne "overtime" -or $status -ne "approved") {
        return $null
    }

    $snapshot = if ($Entry.PSObject.Properties.Name -contains "compensationSnapshot") { $Entry.compensationSnapshot } else { $null }
    if ($null -eq $snapshot) {
        return [PSCustomObject][ordered]@{
            status                      = "unavailable"
            currency                    = "CAD"
            estimateOnly                = $true
            costBasis                   = "salary-only"
            includesEmployerCosts       = $false
            paymentOption               = if (([string]$Entry.paymentOption).Trim().ToLowerInvariant() -eq "leave") { "leave" } else { "cash" }
            totalAmountCents            = $null
            cashAmountCents             = $null
            compensatoryLeaveValueCents = $null
            unavailableReason           = "snapshot-missing"
            calculationVersion          = ""
        }
    }

    $snapshotStatus = if ($snapshot.PSObject.Properties.Name -contains "snapshotStatus") { ([string]$snapshot.snapshotStatus).Trim().ToLowerInvariant() } else { "unavailable" }
    $isFinal = ($snapshotStatus -eq "final")
    return [PSCustomObject][ordered]@{
        status                      = if ($isFinal) { "final" } else { "unavailable" }
        currency                    = if ($snapshot.PSObject.Properties.Name -contains "currency" -and -not [string]::IsNullOrWhiteSpace([string]$snapshot.currency)) { [string]$snapshot.currency } else { "CAD" }
        estimateOnly                = if ($snapshot.PSObject.Properties.Name -contains "estimateOnly") { [bool]$snapshot.estimateOnly } else { $true }
        costBasis                   = if ($snapshot.PSObject.Properties.Name -contains "costBasis") { [string]$snapshot.costBasis } else { "salary-only" }
        includesEmployerCosts       = if ($snapshot.PSObject.Properties.Name -contains "includesEmployerCosts") { [bool]$snapshot.includesEmployerCosts } else { $false }
        paymentOption               = if ($snapshot.PSObject.Properties.Name -contains "paymentOption" -and ([string]$snapshot.paymentOption).Trim().ToLowerInvariant() -eq "leave") { "leave" } else { "cash" }
        totalAmountCents            = if ($isFinal -and $snapshot.PSObject.Properties.Name -contains "totalAmountCents") { [long]$snapshot.totalAmountCents } else { $null }
        cashAmountCents             = if ($isFinal -and $snapshot.PSObject.Properties.Name -contains "cashAmountCents") { [long]$snapshot.cashAmountCents } else { $null }
        compensatoryLeaveValueCents = if ($isFinal -and $snapshot.PSObject.Properties.Name -contains "compensatoryLeaveValueCents") { [long]$snapshot.compensatoryLeaveValueCents } else { $null }
        unavailableReason           = if ($isFinal) { $null } elseif ($snapshot.PSObject.Properties.Name -contains "unavailableReason") { [string]$snapshot.unavailableReason } else { "snapshot-unavailable" }
        calculationVersion          = if ($snapshot.PSObject.Properties.Name -contains "calculationVersion") { [string]$snapshot.calculationVersion } else { "" }
    }
}

function New-MonetaryAccumulator {
    return @{
        currency                    = "CAD"
        estimateOnly                = $true
        costBasis                   = "salary-only"
        includesEmployerCosts       = $false
        approvedEntryCount          = 0
        calculatedEntryCount        = 0
        unavailableEntryCount       = 0
        totalAmountCents            = [long]0
        cashAmountCents             = [long]0
        compensatoryLeaveValueCents = [long]0
        unavailableReasons          = @{}
    }
}

function Add-EntryMonetaryToAccumulator {
    param(
        [Parameter(Mandatory = $true)]$Accumulator,
        [AllowNull()]$Monetary
    )

    $Accumulator.approvedEntryCount++
    if ($null -eq $Monetary -or [string]$Monetary.status -ne "final" -or $null -eq $Monetary.totalAmountCents) {
        $Accumulator.unavailableEntryCount++
        $reason = if ($null -ne $Monetary -and $Monetary.unavailableReason) { [string]$Monetary.unavailableReason } else { "snapshot-missing" }
        if (-not $Accumulator.ContainsKey("unavailableReasons")) { $Accumulator.unavailableReasons = @{} }
        $Accumulator.unavailableReasons[$reason] = [int]$Accumulator.unavailableReasons[$reason] + 1
        return
    }

    $Accumulator.calculatedEntryCount++
    $Accumulator.totalAmountCents += [long]$Monetary.totalAmountCents
    $Accumulator.cashAmountCents += [long]$Monetary.cashAmountCents
    $Accumulator.compensatoryLeaveValueCents += [long]$Monetary.compensatoryLeaveValueCents
}

function ConvertTo-MonetaryAggregateReadModel {
    param([AllowNull()]$Accumulator)

    $source = if ($null -ne $Accumulator) { $Accumulator } else { New-MonetaryAccumulator }
    $approvedCount = [int]$source.approvedEntryCount
    $calculatedCount = [int]$source.calculatedEntryCount
    return [PSCustomObject][ordered]@{
        currency                    = [string]$source.currency
        estimateOnly                = [bool]$source.estimateOnly
        costBasis                   = [string]$source.costBasis
        includesEmployerCosts       = [bool]$source.includesEmployerCosts
        approvedEntryCount          = $approvedCount
        calculatedEntryCount        = $calculatedCount
        unavailableEntryCount       = [int]$source.unavailableEntryCount
        coveragePercent             = if ($approvedCount -gt 0) { [math]::Round(($calculatedCount / [double]$approvedCount) * 100, 1) } else { 100 }
        totalAmountCents            = [long]$source.totalAmountCents
        cashAmountCents             = [long]$source.cashAmountCents
        compensatoryLeaveValueCents = [long]$source.compensatoryLeaveValueCents
        unavailableReasons          = [PSCustomObject]$(if ($source.ContainsKey("unavailableReasons")) { $source.unavailableReasons } else { @{} })
    }
}

function Add-EntryPermissionProjection {
    param(
        [Parameter(Mandatory = $true)]$Entry,
        $CurrentUser,
        [string]$EmployeeRole = "employee"
    )

    $canModify = Test-CurrentUserCanManageEntry -CurrentUser $CurrentUser -Entry $Entry
    $canApproveEmployeeRole = Test-CurrentUserCanApproveEmployeeRole -CurrentUser $CurrentUser -EmployeeRole $EmployeeRole
    $canApprove = ($canModify -and $canApproveEmployeeRole)
    $permissionReason = "editable"

    if (-not $canModify) {
        $permissionReason = "readOnlyProject"
    }
    elseif (-not $canApproveEmployeeRole) {
        $permissionReason = "superAdminApproval"
    }

    $Entry | Add-Member -NotePropertyName canModify -NotePropertyValue ([bool]$canModify) -Force
    $Entry | Add-Member -NotePropertyName canApprove -NotePropertyValue ([bool]$canApprove) -Force
    $Entry | Add-Member -NotePropertyName permissionReason -NotePropertyValue $permissionReason -Force
    return $Entry
}

function Add-EntryPermissionProjectionFromAccessModel {
    param(
        [Parameter(Mandatory = $true)]$Entry,
        [Parameter(Mandatory = $true)]$ModifyProjectCodeSet,
        [bool]$IsSuperAdmin = $false,
        [bool]$CanApproveEmployeeRole = $true,
        [bool]$IsOwnEntry = $false
    )

    $entryType = if ($Entry.PSObject.Properties.Name -contains "entryType") { ([string]$Entry.entryType).Trim().ToLowerInvariant() } else { "overtime" }
    $projectCode = if ($Entry.PSObject.Properties.Name -contains "projectCode") { [string]$Entry.projectCode } else { "" }
    $canModify = $false

    if ($IsSuperAdmin) {
        $canModify = $true
    }
    elseif ($entryType -ne "diverse" -and -not [string]::IsNullOrWhiteSpace($projectCode)) {
        $canModify = $ModifyProjectCodeSet.ContainsKey($projectCode)
    }

    $canApprove = ($canModify -and $CanApproveEmployeeRole -and -not $IsOwnEntry)
    $permissionReason = "editable"

    if (-not $canModify) {
        $permissionReason = "readOnlyProject"
    }
    elseif ($IsOwnEntry) {
        $permissionReason = "ownEntry"
    }
    elseif (-not $CanApproveEmployeeRole) {
        $permissionReason = "superAdminApproval"
    }

    $Entry | Add-Member -NotePropertyName canModify -NotePropertyValue ([bool]$canModify) -Force
    $Entry | Add-Member -NotePropertyName canApprove -NotePropertyValue ([bool]$canApprove) -Force
    $Entry | Add-Member -NotePropertyName permissionReason -NotePropertyValue $permissionReason -Force
    return $Entry
}

function New-EmployeeEntryProjectionForCurrentUser {
    param(
        [Parameter(Mandatory = $true)][string]$EmployeeCode,
        [Parameter(Mandatory = $true)][string]$EmployeeName,
        [Parameter(Mandatory = $true)]$Entry,
        $CurrentUser,
        [string]$EmployeeRole = "employee"
    )

    $projection = New-EmployeeEntryProjection -EmployeeCode $EmployeeCode -EmployeeName $EmployeeName -Entry $Entry -EmployeeRole $EmployeeRole
    $projection = Add-EntryPermissionProjection -Entry $projection -CurrentUser $CurrentUser -EmployeeRole $EmployeeRole
    if (Test-CurrentUserManager -CurrentUser $CurrentUser) {
        $monetary = New-EntryMonetaryReadModel -Entry $Entry
        if ($null -ne $monetary) {
            $projection | Add-Member -NotePropertyName monetary -NotePropertyValue $monetary -Force
        }
    }
    return $projection
}

function New-EmployeeEntryProjectionForAccessModel {
    param(
        [Parameter(Mandatory = $true)][string]$EmployeeCode,
        [Parameter(Mandatory = $true)][string]$EmployeeName,
        [Parameter(Mandatory = $true)]$Entry,
        [Parameter(Mandatory = $true)]$ModifyProjectCodeSet,
        [string]$EmployeeRole = "employee",
        [bool]$IsSuperAdmin = $false,
        [bool]$CanApproveEmployeeRole = $true,
        [bool]$IncludeMonetary = $true,
        [bool]$IsOwnEntry = $false
    )

    $projection = New-EmployeeEntryProjection -EmployeeCode $EmployeeCode -EmployeeName $EmployeeName -Entry $Entry -EmployeeRole $EmployeeRole
    $projection = Add-EntryPermissionProjectionFromAccessModel -Entry $projection -ModifyProjectCodeSet $ModifyProjectCodeSet -IsSuperAdmin:$IsSuperAdmin -CanApproveEmployeeRole:$CanApproveEmployeeRole -IsOwnEntry:$IsOwnEntry
    $monetary = if ($IncludeMonetary) { New-EntryMonetaryReadModel -Entry $Entry } else { $null }
    if ($null -ne $monetary) {
        $projection | Add-Member -NotePropertyName monetary -NotePropertyValue $monetary -Force
    }
    return $projection
}

function Get-CachedEmployeeEntriesForFile {
    param([Parameter(Mandatory = $true)][string]$DataFile, [switch]$IncludeMonetary)

    # Invoke-ReadModelCache reconciles once before entering a model factory.
    # Avoid repeating the same sync-state lookup for every employee in a
    # multi-file snapshot while retaining safe direct-call behavior.
    if ($script:ReadModelFactoryDepth -le 0) {
        Sync-ReadModelCaches
    }
    $metadata = Get-FileMetadataSnapshot -Path $DataFile
    if ($null -eq $metadata) {
        if ($script:EmployeeEntryFileCache.ContainsKey($DataFile)) {
            $script:EmployeeEntryFileCache.Remove($DataFile) | Out-Null
        }
        return @()
    }

    $cacheEntry = $script:EmployeeEntryFileCache[$DataFile]
    if ($cacheEntry -and $cacheEntry.LastWriteTicks -eq $metadata.LastWriteTicks -and $cacheEntry.Length -eq $metadata.Length) {
        return $cacheEntry.Entries
    }

    $entriesList = New-Object System.Collections.ArrayList
    foreach ($entry in @(Read-JsonArrayFile -Path $DataFile)) {
        $normalizedEntry = Convert-ToNormalizedEntryObject -Entry $entry
        # This cache is internal. Preserve the private snapshot here so the
        # manager projections can expose only its permitted monetary fields.
        # Public employee responses must still pass through a safe projection.
        if ($null -ne $entry -and $entry.PSObject.Properties.Name -contains "compensationSnapshot") {
            $normalizedEntry | Add-Member -NotePropertyName compensationSnapshot -NotePropertyValue $entry.compensationSnapshot -Force
        }
        [void]$entriesList.Add($normalizedEntry)
    }
    $entries = @($entriesList.ToArray())
    $script:EmployeeEntryFileCache[$DataFile] = [PSCustomObject]@{
        LastWriteTicks = $metadata.LastWriteTicks
        Length         = $metadata.Length
        Entries        = $entries
    }

    # IncludeMonetary remains accepted for existing callers. Both modes read
    # exactly the same persisted snapshot; no salary/settings lookup occurs.
    return $entries
}

function Get-EmployeeDataSnapshot {
    param([switch]$IncludeMonetary, [switch]$SkipProjection)
    $cacheKey = if ($IncludeMonetary) { "employee-data-snapshot|monetary" } else { "employee-data-snapshot" }
    if ($SkipProjection) { $cacheKey += "|raw" }
    return (Invoke-ReadModelCache -Key $cacheKey -Dependencies @("directory", "auth") -Factory {
        if ($script:SaphirPerformanceEnabled) { Add-SaphirPerformanceOperation -Kind "cache.snapshot.assembled" }
        $employeesList = New-Object System.Collections.ArrayList
        $entriesByEmployee = @{}
        $flattenedEntriesList = New-Object System.Collections.ArrayList
        $users = @(Get-Users | Where-Object { (Test-EmployeeUserRecord -UserRecord $_ -EmployeeCode "") -and -not [bool]$_.disabled } | Sort-Object username)

        $filePaths = @($users | ForEach-Object { Get-EmployeeDataFilePath -EmployeeCode (Get-UserEmployeeCodeValue $_) })
        Prime-EmployeeFileMetadata -Paths $filePaths
        Prefetch-EmployeeFileText -Paths $filePaths

        foreach ($user in $users) {
            $contribution = Get-EmployeeReadContribution -User $user -IncludeMonetary:$IncludeMonetary -SkipProjection:$SkipProjection
            [void]$employeesList.Add($contribution.employee)
            $entriesByEmployee[[string]$contribution.employee.code] = @($contribution.entries)
            foreach ($entry in @($contribution.projectedEntries)) { [void]$flattenedEntriesList.Add($entry) }
        }

        return [PSCustomObject]@{
            employees        = @($employeesList.ToArray())
            entriesByEmployee = $entriesByEmployee
            flattenedEntries = @($flattenedEntriesList.ToArray())
        }
    })
}

function Get-ScopedEmployeeDataSnapshot {
    param($CurrentUser, [switch]$IncludeMonetary)

    if (-not (Test-CurrentUserManager -CurrentUser $CurrentUser)) {
        return [PSCustomObject]@{
            employees         = @()
            entriesByEmployee = @{}
            flattenedEntries  = @()
        }
    }

    $accessModel = Get-ProjectAccessModelForCurrentUser -CurrentUser $CurrentUser
    $modifyAccessModel = Get-ProjectModificationAccessModelForCurrentUser -CurrentUser $CurrentUser
    $isSuperAdmin = Test-CurrentUserSuperAdmin -CurrentUser $CurrentUser
    if (-not $isSuperAdmin -and $accessModel.ProjectCodes.Count -eq 0) {
        return [PSCustomObject]@{
            employees         = @()
            entriesByEmployee = @{}
            flattenedEntries  = @()
        }
    }

    $scopeKey = if ($isSuperAdmin) { "global" } else { (@($accessModel.ProjectCodes) -join ",") }
    $modifyScopeKey = if ($isSuperAdmin) { "global" } else { (@($modifyAccessModel.ProjectCodes) -join ",") }
    $userScopeKey = Get-ProjectAccessCacheUserKey -CurrentUser $CurrentUser
    $cacheKey = "scoped-employee-data-snapshot|{0}|{1}|{2}" -f $scopeKey, $modifyScopeKey, $userScopeKey
    if ($IncludeMonetary) { $cacheKey += "|monetary" }

    return (Invoke-ReadModelCache -Key $cacheKey -Dependencies @("directory", "auth", "projects") -Factory {
        $snapshot = Get-EmployeeDataSnapshot -IncludeMonetary:$IncludeMonetary -SkipProjection
        $employeesList = New-Object System.Collections.ArrayList
        $entriesByEmployee = @{}
        $flattenedEntriesList = New-Object System.Collections.ArrayList

        foreach ($employee in @($snapshot.employees)) {
            $employeeCode = [string]$employee.code
            $entries = if ($snapshot.entriesByEmployee.ContainsKey($employeeCode)) { @($snapshot.entriesByEmployee[$employeeCode]) } else { @() }
            $source = [PSCustomObject]@{ employee = $employee; entries = $entries }
            $contribution = Get-ScopedEmployeeReadContribution -Contribution $source -ScopeIdentity $cacheKey -AccessModel $accessModel -ModifyAccessModel $modifyAccessModel -CurrentUser $CurrentUser -IsSuperAdmin:$isSuperAdmin -IncludeMonetary:$IncludeMonetary
            if ($contribution.entries.Count -eq 0) { continue }
            [void]$employeesList.Add($contribution.employee)
            $entriesByEmployee[$employeeCode] = @($contribution.entries)
            foreach ($entry in @($contribution.entries)) { [void]$flattenedEntriesList.Add($entry) }
        }

        return [PSCustomObject]@{
            employees         = @($employeesList.ToArray())
            entriesByEmployee = $entriesByEmployee
            flattenedEntries  = @($flattenedEntriesList.ToArray())
        }
    })
}

function Get-FilteredEmployeeEntriesSnapshot {
    param(
        [string]$StartDate,
        [string]$EndDate
    )

    $cacheKey = "filtered-employee-entries|{0}|{1}" -f [string]$StartDate, [string]$EndDate
    return (Invoke-ReadModelCache -Key $cacheKey -Dependencies @("directory", "auth") -Factory {
        $snapshot = Get-EmployeeDataSnapshot
        $entries = @($snapshot.flattenedEntries)
        $startDt = $null
        $endDt = $null

        if ($StartDate) {
            try {
                $startDt = [DateTime]::ParseExact($StartDate, "yyyy-MM-dd", $null)
            }
            catch { }
        }

        if ($EndDate) {
            try {
                $endDt = [DateTime]::ParseExact($EndDate, "yyyy-MM-dd", $null)
            }
            catch { }
        }

        if (-not $startDt -and -not $endDt) {
            return $entries
        }

        $filteredList = New-Object System.Collections.ArrayList
        foreach ($entry in $entries) {
            $entryDate = Get-EntryDateOrNull -Entry $entry
            if ($null -eq $entryDate) {
                continue
            }

            if ($startDt -and $entryDate -lt $startDt) {
                continue
            }

            if ($endDt -and $entryDate -gt $endDt) {
                continue
            }

            [void]$filteredList.Add($entry)
        }

        return @($filteredList.ToArray())
    })
}

function New-HistoryEntryReadModel {
    param(
        [Parameter(Mandatory = $true)]$Entry,
        $EmployeeNameMap
    )

    $projection = [PSCustomObject]@{}
    foreach ($property in @($Entry.PSObject.Properties)) {
        $projection | Add-Member -NotePropertyName ([string]$property.Name) -NotePropertyValue $property.Value
    }
    if ($Entry.projectCode) { return $projection }

    $subject = ""
    foreach ($propertyName in @("targetEmployeeName", "targetEmployee", "subjectEmployee", "employee")) {
        if ($Entry.PSObject.Properties.Name -contains $propertyName) {
            $candidate = ([string]$Entry.PSObject.Properties[$propertyName].Value).Trim()
            if (-not [string]::IsNullOrWhiteSpace($candidate)) {
                $subject = $candidate
                break
            }
        }
    }

    $employeeCode = ""
    $employeeName = ""
    if (-not [string]::IsNullOrWhiteSpace($subject) -and $null -ne $EmployeeNameMap) {
        if ($EmployeeNameMap.PSObject.Properties.Name -contains $subject) {
            $employeeCode = $subject
            $employeeName = ([string]$EmployeeNameMap.PSObject.Properties[$subject].Value).Trim()
        }
        else {
            foreach ($property in @($EmployeeNameMap.PSObject.Properties)) {
                if ([string]::Equals(([string]$property.Value).Trim(), $subject, [StringComparison]::OrdinalIgnoreCase)) {
                    $employeeCode = [string]$property.Name
                    $employeeName = ([string]$property.Value).Trim()
                    break
                }
            }
        }
    }

    if ([string]::IsNullOrWhiteSpace($employeeName)) {
        $employeeName = $subject
    }
    if ([string]::IsNullOrWhiteSpace($employeeCode) -and $subject -match "^\d+$") {
        $employeeCode = $subject
    }

    $projection | Add-Member -NotePropertyName "targetEmployeeName" -NotePropertyValue $employeeName -Force
    $projection | Add-Member -NotePropertyName "targetEmployeeCode" -NotePropertyValue $employeeCode -Force
    return $projection
}

function Get-HistoryEntriesSnapshot {
    return (Invoke-ReadModelCache -Key "history-entries" -Dependencies @("history", "directory") -Factory {
        if (-not (Test-SaphirFileExists -Path $historyFile)) {
            return @()
        }

        $employeeNameMap = if (Get-Command -Name Get-EmployeeNameMap -ErrorAction SilentlyContinue) {
            Get-EmployeeNameMap
        }
        else {
            [PSCustomObject]@{}
        }
        $entries = New-Object System.Collections.ArrayList
        foreach ($entry in @(Read-JsonArrayFile -Path $historyFile)) {
            if ($null -ne $entry) {
                [void]$entries.Add((New-HistoryEntryReadModel -Entry $entry -EmployeeNameMap $employeeNameMap))
            }
        }
        return @($entries.ToArray())
    })
}

function Get-SortedHistoryEntriesSnapshot {
    return (Invoke-ReadModelCache -Key "history-entries-sorted" -Dependencies @("history", "directory") -Factory {
        return @(Get-HistoryEntriesSnapshot | Sort-Object {
            try {
                [DateTime]::Parse(($_.timestamp -replace " ", "T"))
            }
            catch {
                [DateTime]::MinValue
            }
        } -Descending)
    })
}

function Get-RawSortedHistorySnapshot {
    return (Invoke-ReadModelCache -Key "history-raw-sorted" -Dependencies @("history") -Factory {
        return @(Read-JsonArrayFile -Path $historyFile | Where-Object { $null -ne $_ } | Sort-Object {
            try { [DateTime]::Parse(($_.timestamp -replace " ", "T")) } catch { [DateTime]::MinValue }
        } -Descending)
    })
}

function Get-HistoryPage {
    param([int]$Page = 1, [string]$Category = "all", [string]$Search = "", [string]$StartDate = "", [string]$EndDate = "")
    if ($Page -lt 1 -or $Page -gt 100000 -or $Category -notin @("all", "add", "update", "approval", "delete") -or $Search.Length -gt 200) { throw [ArgumentException]::new("Invalid history page or filter.") }
    foreach ($date in @($StartDate, $EndDate)) {
        if ($date) { $parsed = [DateTime]::MinValue; if (-not [DateTime]::TryParseExact($date, "yyyy-MM-dd", [Globalization.CultureInfo]::InvariantCulture, [Globalization.DateTimeStyles]::None, [ref]$parsed)) { throw [ArgumentException]::new("Invalid history date.") } }
    }
    # Reconcile before reading the raw cache. Never load employee entry files.
    $raw = @(Get-RawSortedHistorySnapshot)
    $names = if (Get-Command Get-EmployeeNameMap -ErrorAction SilentlyContinue) { Get-EmployeeNameMap } else { [PSCustomObject]@{} }
    $counts = @{ all = 0; add = 0; update = 0; approval = 0; delete = 0 }
    $filtered = New-Object Collections.ArrayList
    $tokens = @($Search.Trim() -split '\s+' | Where-Object { $_ })
    $actionLabels = @{ add = "Added Ajoutée"; update = "Updated Modifiée"; approved = "Approved Approuvée"; rejected = "Rejected Rejetée"; delete = "Deleted Supprimée"; archive = "Archived Archivé"; restore = "Restored Réactivé"; event = "Event Événement" }
    foreach ($entry in $raw) {
        $date = ([string]$entry.timestamp -split '[ T]')[0]
        if (($StartDate -and $date -lt $StartDate) -or ($EndDate -and $date -gt $EndDate)) { continue }
        if ($tokens.Count) {
            $projection = New-HistoryEntryReadModel -Entry $entry -EmployeeNameMap $names
            $text = ($projection.PSObject.Properties.Value -join " ") + " " + $actionLabels[([string]$entry.action).ToLowerInvariant()]
            if ($entry.projectCode) {
                $text += " Project Projet"
                foreach ($change in @($entry.projectChanges)) { $text += " $($change.before) $($change.after)" }
            }
            $displayDate = [DateTime]::MinValue
            if ([DateTime]::TryParse([string]$entry.timestamp, [ref]$displayDate)) {
                foreach ($culture in @("fr-CA", "en-CA")) { $text += " " + $displayDate.ToString("D", [Globalization.CultureInfo]::GetCultureInfo($culture)) }
            }
            $matches = $true
            foreach ($token in $tokens) { if ([Globalization.CultureInfo]::InvariantCulture.CompareInfo.IndexOf($text, $token, ([Globalization.CompareOptions]::IgnoreCase -bor [Globalization.CompareOptions]::IgnoreNonSpace)) -lt 0) { $matches = $false; break } }
            if (-not $matches) { continue }
        }
        $action = ([string]$entry.action).ToLowerInvariant()
        $group = switch ($action) {
            { $_ -in @("approved", "rejected") } { "approval" }
            "archive" { "delete" }
            "restore" { "update" }
            default { $action }
        }
        $counts.all++
        if ($counts.ContainsKey($group) -and $group -ne "all") { $counts[$group]++ }
        if ($Category -eq "all" -or $group -eq $Category) { [void]$filtered.Add($entry) }
    }
    $pages = [Math]::Max(1, [int][Math]::Ceiling($filtered.Count / 25.0))
    $resolved = [Math]::Min($Page, $pages)
    $items = @($filtered | Select-Object -Skip (($resolved - 1) * 25) -First 25 | ForEach-Object { New-HistoryEntryReadModel -Entry $_ -EmployeeNameMap $names })
    return [PSCustomObject]@{ items = $items; page = $resolved; pageSize = 25; total = $filtered.Count; totalPages = $pages; counts = [PSCustomObject]$counts }
}

function Get-RecentHistoryEntriesSnapshot {
    param([int]$Limit = 7)

    $entries = @(Get-RawSortedHistorySnapshot)

    if ($Limit -le 0) {
        $selected = $entries
    } else {
        $selected = @($entries | Select-Object -First $Limit)
    }
    $names = if (Get-Command Get-EmployeeNameMap -ErrorAction SilentlyContinue) { Get-EmployeeNameMap } else { [PSCustomObject]@{} }
    return @($selected | ForEach-Object { New-HistoryEntryReadModel -Entry $_ -EmployeeNameMap $names })
}

function Get-DashboardBootstrapModel {
    param(
        [string]$SelectedEmployeeCode,
        $CurrentUser
    )

    $accessModel = Get-ProjectAccessModelForCurrentUser -CurrentUser $CurrentUser
    $modifyAccessModel = Get-ProjectModificationAccessModelForCurrentUser -CurrentUser $CurrentUser
    $scopeKey = if (Test-CurrentUserSuperAdmin -CurrentUser $CurrentUser) { "global" } else { (@($accessModel.ProjectCodes) -join ",") }
    $modifyScopeKey = if (Test-CurrentUserSuperAdmin -CurrentUser $CurrentUser) { "global" } else { (@($modifyAccessModel.ProjectCodes) -join ",") }
    $userScopeKey = Get-ProjectAccessCacheUserKey -CurrentUser $CurrentUser
    $cacheKey = "dashboard-bootstrap|{0}|{1}|{2}|{3}" -f [string]$SelectedEmployeeCode, $scopeKey, $modifyScopeKey, $userScopeKey
    $cacheKey += "|" + (Get-Date -Format "yyyy-MM")
    $dashboard = Invoke-ReadModelCache -Key $cacheKey -Dependencies @("directory", "auth", "projects") -Factory {
        $snapshot = Get-ScopedEmployeeDataSnapshot -CurrentUser $CurrentUser
        $flattenedEntries = @($snapshot.flattenedEntries)
        $now = Get-Date
        $totalSeconds = 0
        $actionableCount = 0
        $pending = New-Object Collections.ArrayList
        $active = New-Object Collections.ArrayList

        foreach ($entry in $flattenedEntries) {
            if (Test-EntryPendingApproval -Entry $entry) {
                [void]$pending.Add($entry)
                if ($entry.canApprove) { $actionableCount++ }
            }
            elseif (-not $entry.punchOut -and (Test-EntryOpen $entry)) {
                [void]$active.Add($entry)
            }

            $entryType = if ($entry.PSObject.Properties.Name -contains "entryType") { ([string]$entry.entryType).Trim().ToLowerInvariant() } else { "overtime" }
            if ($entryType -eq "diverse") {
                continue
            }

            $entryDate = Get-EntryDateOrNull -Entry $entry
            if ($null -eq $entryDate) {
                continue
            }

            if ($entryDate.Month -eq $now.Month -and $entryDate.Year -eq $now.Year) {
                $totalSeconds += Get-OvertimeSecondsFromText -Value ([string]$entry.overtime)
            }
        }

        $pendingEntries = @($pending | Sort-Object { Get-EntryDateTimeOrMin -Entry $_ } -Descending | Select-Object -First 6)
        $activeEntries = @($active | Sort-Object { Get-EntryDateTimeOrMin -Entry $_ } -Descending | Select-Object -First 6)
        $preferredEntry = $pendingEntries | Select-Object -First 1
        $defaultEmployeeCode = if ($preferredEntry) { [string]$preferredEntry.employeeCode } elseif ($snapshot.employees.Count -gt 0) { [string]$snapshot.employees[0].code } else { "" }
        $resolvedEmployeeCode = if ([string]::IsNullOrWhiteSpace([string]$SelectedEmployeeCode)) { $defaultEmployeeCode } else { [string]$SelectedEmployeeCode }
        if ($resolvedEmployeeCode -and -not $snapshot.entriesByEmployee.ContainsKey($resolvedEmployeeCode)) {
            $resolvedEmployeeCode = $defaultEmployeeCode
        }
        $selectedEmployeeEntries = if ($resolvedEmployeeCode -and $snapshot.entriesByEmployee.ContainsKey($resolvedEmployeeCode)) { @($snapshot.entriesByEmployee[$resolvedEmployeeCode]) } else { @() }

        return [PSCustomObject]@{
            employees             = $snapshot.employees
            totalOvertime         = Convert-SecondsToTimeText -Seconds $totalSeconds
            pendingApprovals      = $pending.Count
            actionableCount       = $actionableCount
            activeEmployees       = $active.Count
            trackedEmployees      = $snapshot.employees.Count
            projects              = @(Get-ProjectsForCurrentUser -CurrentUser $CurrentUser -Scope "all")
            pendingQueue          = $pendingEntries
            activeSessions        = $activeEntries
            recentHistory         = @()
            defaultEmployeeCode   = $defaultEmployeeCode
            selectedEmployeeCode  = $resolvedEmployeeCode
            selectedEmployeeEntries = $selectedEmployeeEntries
        }
    }
    # recentHistory stays empty for older clients; audit history is loaded
    # exclusively by Review on request, never as part of the dashboard.
    return $dashboard
}

function Get-ApprovalsEntriesModel {
    param($CurrentUser, [bool]$IncludeMonetary = $true)

    $accessModel = Get-ProjectAccessModelForCurrentUser -CurrentUser $CurrentUser
    $modifyAccessModel = Get-ProjectModificationAccessModelForCurrentUser -CurrentUser $CurrentUser
    $scopeKey = if (Test-CurrentUserSuperAdmin -CurrentUser $CurrentUser) { "global" } else { (@($accessModel.ProjectCodes) -join ",") }
    $modifyScopeKey = if (Test-CurrentUserSuperAdmin -CurrentUser $CurrentUser) { "global" } else { (@($modifyAccessModel.ProjectCodes) -join ",") }
    $userScopeKey = Get-ProjectAccessCacheUserKey -CurrentUser $CurrentUser
    return (Invoke-ReadModelCache -Key "approvals-entries|$scopeKey|$modifyScopeKey|$userScopeKey|$IncludeMonetary" -Dependencies @("directory", "auth", "projects", "compensation") -Factory {
        return @((Get-ScopedEmployeeDataSnapshot -CurrentUser $CurrentUser -IncludeMonetary:$IncludeMonetary).flattenedEntries | Sort-Object { Get-EntryDateTimeOrMin -Entry $_ } -Descending)
    })
}

function Get-ProjectEntryType {
    param($Entry)

    if ($null -eq $Entry -or -not ($Entry.PSObject.Properties.Name -contains "entryType") -or [string]::IsNullOrWhiteSpace([string]$Entry.entryType)) {
        return "overtime"
    }

    return ([string]$Entry.entryType).Trim().ToLowerInvariant()
}

function Get-ProjectEntryStatus {
    param($Entry)

    if ($null -eq $Entry -or -not ($Entry.PSObject.Properties.Name -contains "status") -or [string]::IsNullOrWhiteSpace([string]$Entry.status)) {
        return "pending"
    }

    return ([string]$Entry.status).Trim().ToLowerInvariant()
}

function Test-ProjectEntryClosed {
    param($Entry)

    if ($null -ne $Entry -and $Entry.PSObject.Properties.Name -contains "rawEntry") { $Entry = $Entry.rawEntry }
    if ($null -eq $Entry -or
        -not ($Entry.PSObject.Properties.Name -contains "punchOut") -or
        [string]::IsNullOrWhiteSpace([string]$Entry.punchOut)) {
        return $false
    }

    return (-not (Test-EntryForgottenClockOut -Entry $Entry))
}

function Get-ProjectEntryStatusBucketName {
    param($Entry)

    if (-not (Test-ProjectEntryClosed -Entry $Entry)) {
        return "open"
    }

    $status = Get-ProjectEntryStatus -Entry $Entry
    if (@("approved", "pending", "rejected") -contains $status) {
        return $status
    }

    return "other"
}

function New-ProjectStatisticsBasis {
    return [PSCustomObject]@{
        id               = "approvedClosedOvertime"
        entryType        = "overtime"
        status           = "approved"
        requiresPunchOut = $true
    }
}

function New-ProjectStatusAccumulatorSet {
    $result = @{}
    foreach ($bucketName in @("approved", "pending", "rejected", "open", "other")) {
        $result[$bucketName] = [PSCustomObject]@{
            count   = 0
            seconds = [long]0
        }
    }
    return $result
}

function ConvertTo-ProjectStatusBucketModel {
    param($Buckets)

    $result = [ordered]@{}
    foreach ($bucketName in @("approved", "pending", "rejected", "open", "other")) {
        $bucket = if ($null -ne $Buckets -and $Buckets.ContainsKey($bucketName)) { $Buckets[$bucketName] } else { $null }
        $seconds = if ($null -ne $bucket) { [long]$bucket.seconds } else { [long]0 }
        $result[$bucketName] = [PSCustomObject]@{
            count    = if ($null -ne $bucket) { [int]$bucket.count } else { 0 }
            seconds  = $seconds
            overtime = Convert-SecondsToTimeText -Seconds $seconds
        }
    }
    return [PSCustomObject]$result
}

function ConvertTo-ProjectDateOrNull {
    param([AllowNull()][string]$Value)

    if ([string]::IsNullOrWhiteSpace([string]$Value)) {
        return $null
    }

    $parsed = [DateTime]::MinValue
    $isValid = [DateTime]::TryParseExact(
        ([string]$Value).Trim(),
        "yyyy-MM-dd",
        [System.Globalization.CultureInfo]::InvariantCulture,
        [System.Globalization.DateTimeStyles]::None,
        [ref]$parsed
    )
    if (-not $isValid) {
        return $null
    }
    return $parsed.Date
}

function New-ProjectPeriodModel {
    param(
        [AllowNull()][string]$StartDate,
        [AllowNull()][string]$EndDate
    )

    $start = ConvertTo-ProjectDateOrNull -Value $StartDate
    $end = ConvertTo-ProjectDateOrNull -Value $EndDate
    return [PSCustomObject]@{
        startDate = if ($null -ne $start) { $start.ToString("yyyy-MM-dd", [System.Globalization.CultureInfo]::InvariantCulture) } else { "" }
        endDate   = if ($null -ne $end) { $end.ToString("yyyy-MM-dd", [System.Globalization.CultureInfo]::InvariantCulture) } else { "" }
    }
}

function New-ProjectEntryDetailProjection {
    param(
        [Parameter(Mandatory = $true)]$Entry,
        [Parameter(Mandatory = $true)][string]$StatusBucket,
        [Parameter(Mandatory = $true)][long]$DurationSeconds
    )

    $employeeCode = if ($Entry.PSObject.Properties.Name -contains "employeeCode") { [string]$Entry.employeeCode } else { "" }
    $employeeName = if ($Entry.PSObject.Properties.Name -contains "employeeName") { [string]$Entry.employeeName } elseif ($Entry.PSObject.Properties.Name -contains "name") { [string]$Entry.name } else { "" }
    $projection = [PSCustomObject]@{
        entryId          = if ($Entry.PSObject.Properties.Name -contains "entryId") { [string]$Entry.entryId } else { "" }
        employeeCode     = $employeeCode
        employeeName     = $employeeName
        employeeArchived = if ($Entry.PSObject.Properties.Name -contains "employeeArchived") { [bool]$Entry.employeeArchived } else { $false }
        entryType        = Get-ProjectEntryType -Entry $Entry
        workSchedule     = Saphir.BusinessRules\ConvertTo-SaphirWorkSchedule -Value $(if ($Entry.PSObject.Properties.Name -contains "workSchedule") { [string]$Entry.workSchedule } else { "" })
        workScheduleSource = if ($Entry.PSObject.Properties.Name -contains "workScheduleSource") { [string]$Entry.workScheduleSource } else { "" }
        date             = if ($Entry.PSObject.Properties.Name -contains "date") { [string]$Entry.date } else { "" }
        punchIn          = if ($Entry.PSObject.Properties.Name -contains "punchIn") { [string]$Entry.punchIn } else { "" }
        exactPunchIn     = if ($Entry.PSObject.Properties.Name -contains "exactPunchIn") { [string]$Entry.exactPunchIn } else { "" }
        punchOut         = if ($Entry.PSObject.Properties.Name -contains "punchOut") { [string]$Entry.punchOut } else { "" }
        exactPunchOut    = if ($Entry.PSObject.Properties.Name -contains "exactPunchOut") { [string]$Entry.exactPunchOut } else { "" }
        overtime         = Convert-SecondsToTimeText -Seconds $DurationSeconds
        durationSeconds  = $DurationSeconds
        status           = Get-ProjectEntryStatus -Entry $Entry
        statusBucket     = $StatusBucket
        isOpen           = ($StatusBucket -eq "open")
        workComment      = if ($Entry.PSObject.Properties.Name -contains "workComment") { [string]$Entry.workComment } else { "" }
        diverseSummary   = if ($Entry.PSObject.Properties.Name -contains "diverseSummary") { [string]$Entry.diverseSummary } else { "" }
        message          = if ($Entry.PSObject.Properties.Name -contains "message") { [string]$Entry.message } else { "" }
        messageAuthorName = if ($Entry.PSObject.Properties.Name -contains "messageAuthorName") { [string]$Entry.messageAuthorName } else { "" }
        messageAuthorUsername = if ($Entry.PSObject.Properties.Name -contains "messageAuthorUsername") { [string]$Entry.messageAuthorUsername } else { "" }
        messageUpdatedAt = if ($Entry.PSObject.Properties.Name -contains "messageUpdatedAt") { ConvertTo-EntryNoteTimestamp $Entry.messageUpdatedAt } else { "" }
        paymentOption    = if ($Entry.PSObject.Properties.Name -contains "paymentOption") { [string]$Entry.paymentOption } else { "" }
        overtimeCode     = if ($Entry.PSObject.Properties.Name -contains "overtimeCode") { [string]$Entry.overtimeCode } else { "" }
        reasonCode       = if ($Entry.PSObject.Properties.Name -contains "reasonCode") { [string]$Entry.reasonCode } else { "" }
        canModify        = if ($Entry.PSObject.Properties.Name -contains "canModify") { [bool]$Entry.canModify } else { $false }
        canApprove       = if ($Entry.PSObject.Properties.Name -contains "canApprove") { [bool]$Entry.canApprove } else { $false }
        permissionReason = if ($Entry.PSObject.Properties.Name -contains "permissionReason") { [string]$Entry.permissionReason } else { "readOnlyProject" }
    }
    if ($Entry.PSObject.Properties.Name -contains "employeeCommentAdditions") {
        $projection | Add-Member -NotePropertyName employeeCommentAdditions -NotePropertyValue @(Get-EntryEmployeeCommentAdditions $Entry)
    }
    if ($Entry.PSObject.Properties.Name -contains "monetary" -and $null -ne $Entry.monetary) {
        $projection | Add-Member -NotePropertyName monetary -NotePropertyValue $Entry.monetary -Force
    }
    return $projection
}

function Get-ProjectStatisticsOverview {
    param(
        [string]$StartDate,
        [string]$EndDate,
        [bool]$IncludeBreakdown = $true,
        [string]$FilterProjectCode = "",
        [bool]$IncludeEntryDetails = $true,
        $CurrentUser
    )

    $accessModel = Get-ProjectAccessModelForCurrentUser -CurrentUser $CurrentUser
    $modifyAccessModel = Get-ProjectModificationAccessModelForCurrentUser -CurrentUser $CurrentUser
    $isSuperAdmin = Test-CurrentUserSuperAdmin -CurrentUser $CurrentUser
    $scopeKey = if ($isSuperAdmin) { "global" } else { (@($accessModel.ProjectCodes) -join ",") }
    $modifyScopeKey = if ($isSuperAdmin) { "global" } else { (@($modifyAccessModel.ProjectCodes) -join ",") }
    $userScopeKey = Get-ProjectAccessCacheUserKey -CurrentUser $CurrentUser
    $detailKey = if ($IncludeBreakdown) { "detail" } else { "summary" }
    $cacheKey = "project-statistics-overview|{0}|{1}|{2}|{3}|{4}|{5}|{6}|{7}" -f [string]$StartDate, [string]$EndDate, $scopeKey, $modifyScopeKey, $userScopeKey, $detailKey, $FilterProjectCode, $IncludeEntryDetails
    return (Invoke-ReadModelCache -Key $cacheKey -Dependencies @("directory", "auth", "projects", "compensation") -Factory {
        $stats = @{}
        $entries = @(Get-ProjectStatisticsEntriesForPeriod -StartDate $StartDate -EndDate $EndDate -CurrentUser $CurrentUser)
        $visibleProjectCodeSet = $accessModel.ProjectCodeSet
        $canApproveByEmployee = @{}

        foreach ($entry in $entries) {
            if ((Get-ProjectEntryType -Entry $entry) -ne "overtime") {
                continue
            }
            if ([string]::IsNullOrWhiteSpace([string]$entry.projectCode)) {
                continue
            }

            $projectCode = [string]$entry.projectCode
            if (-not [string]::IsNullOrWhiteSpace($FilterProjectCode) -and $projectCode -ne $FilterProjectCode) { continue }
            if (-not $visibleProjectCodeSet.ContainsKey($projectCode)) {
                continue
            }

            $seconds = [long](Get-OvertimeSecondsFromText -Value ([string]$entry.overtime))
            $statusBucket = Get-ProjectEntryStatusBucketName -Entry $entry

            if (-not $stats.ContainsKey($projectCode)) {
                $stats[$projectCode] = [PSCustomObject]@{
                    totalSeconds   = [long]0
                    trackedSeconds = [long]0
                    entryCount     = 0
                    approvedEntryCount = 0
                    minSeconds     = $null
                    maxSeconds     = $null
                    statusBuckets  = (New-ProjectStatusAccumulatorSet)
                    monetary       = (New-MonetaryAccumulator)
                    approvedMonths = @{}
                    breakdown      = if ($IncludeBreakdown) { @{} } else { $null }
                }
            }

            $stats[$projectCode].trackedSeconds += $seconds
            $stats[$projectCode].entryCount++
            $stats[$projectCode].statusBuckets[$statusBucket].count++
            $stats[$projectCode].statusBuckets[$statusBucket].seconds += $seconds
            if ($statusBucket -eq "approved") {
                $stats[$projectCode].totalSeconds += $seconds
                $stats[$projectCode].approvedEntryCount++
                $entryMonetary = Get-ProjectEntryMonetary -Entry $entry
                Add-EntryMonetaryToAccumulator -Accumulator $stats[$projectCode].monetary -Monetary $entryMonetary
                if ([string]$entry.date -match '^\d{4}-\d{2}') {
                    $month = ([string]$entry.date).Substring(0, 7)
                    $stats[$projectCode].approvedMonths[$month] = [long]$stats[$projectCode].approvedMonths[$month] + $seconds
                }
                if ($null -eq $stats[$projectCode].minSeconds -or $seconds -lt $stats[$projectCode].minSeconds) {
                    $stats[$projectCode].minSeconds = $seconds
                }
                if ($null -eq $stats[$projectCode].maxSeconds -or $seconds -gt $stats[$projectCode].maxSeconds) {
                    $stats[$projectCode].maxSeconds = $seconds
                }
            }

            if (-not $IncludeBreakdown) {
                continue
            }

            $employeeName = if ($entry.employeeName) { [string]$entry.employeeName } else { [string]$entry.name }
            $employeeCode = if ($entry.employeeCode) { [string]$entry.employeeCode } else { [string]$employeeName }
            if (-not $stats[$projectCode].breakdown.ContainsKey($employeeCode)) {
                $stats[$projectCode].breakdown[$employeeCode] = @{
                    employeeCode = $employeeCode
                    employeeName = $employeeName
                    employeeArchived = if ($entry.PSObject.Properties.Name -contains "employeeArchived") { [bool]$entry.employeeArchived } else { $false }
                    totalSeconds = [long]0
                    trackedSeconds = [long]0
                    entryCount   = 0
                    approvedEntryCount = 0
                    pendingCount = 0
                    pendingSeconds = [long]0
                    openCount = 0
                    monetary  = (New-MonetaryAccumulator)
                    lastActivityDate = ""
                    lastActivityAt = ""
                    entries      = (New-Object System.Collections.ArrayList)
                }
            }

            $employeeBucket = $stats[$projectCode].breakdown[$employeeCode]
            $employeeBucket.trackedSeconds += $seconds
            $employeeBucket.entryCount++
            if ($statusBucket -eq "approved") {
                $employeeBucket.totalSeconds += $seconds
                $employeeBucket.approvedEntryCount++
                Add-EntryMonetaryToAccumulator -Accumulator $employeeBucket.monetary -Monetary $entryMonetary
            }
            elseif ($statusBucket -eq "pending") {
                $employeeBucket.pendingCount++
                $employeeBucket.pendingSeconds += $seconds
            }
            elseif ($statusBucket -eq "open") {
                $employeeBucket.openCount++
            }

            $entryDateTime = Get-EntryDateTimeOrMin -Entry $entry
            if ($entryDateTime -ne [DateTime]::MinValue) {
                $entryActivityAt = $entryDateTime.ToString("yyyy-MM-ddTHH:mm:ss", [System.Globalization.CultureInfo]::InvariantCulture)
                if ([string]::IsNullOrWhiteSpace([string]$employeeBucket.lastActivityAt) -or $entryActivityAt -gt [string]$employeeBucket.lastActivityAt) {
                    $employeeBucket.lastActivityAt = $entryActivityAt
                    $employeeBucket.lastActivityDate = $entryDateTime.ToString("yyyy-MM-dd", [System.Globalization.CultureInfo]::InvariantCulture)
                }
            }

            # Rich fields and permissions are needed only for an explicitly
            # requested breakdown, after project/date/visibility filtering.
            if ($IncludeEntryDetails) {
                $detailEntry = ConvertTo-ProjectEntryAccessProjection -Entry $entry -CurrentUser $CurrentUser -ModifyAccessModel $modifyAccessModel -IsSuperAdmin:$isSuperAdmin -CanApproveByEmployee $canApproveByEmployee
                [void]$employeeBucket.entries.Add((New-ProjectEntryDetailProjection -Entry $detailEntry -StatusBucket $statusBucket -DurationSeconds $seconds))
            }
            else {
                # Internal references let the workspace select its recent 20
                # before projecting permissions, notes and public money fields.
                [void]$employeeBucket.entries.Add($entry)
            }
        }

        return $stats
    })
}

function Get-ProjectSummaryList {
    param(
        [string]$StartDate,
        [string]$EndDate,
        $CurrentUser
    )

    $accessModel = Get-ProjectAccessModelForCurrentUser -CurrentUser $CurrentUser
    $modifyAccessModel = Get-ProjectModificationAccessModelForCurrentUser -CurrentUser $CurrentUser
    $isSuperAdmin = Test-CurrentUserSuperAdmin -CurrentUser $CurrentUser
    $scopeKey = if ($isSuperAdmin) { "global" } else { (@($accessModel.ProjectCodes) -join ",") }
    $modifyScopeKey = if ($isSuperAdmin) { "global" } else { (@($modifyAccessModel.ProjectCodes) -join ",") }
    $userScopeKey = Get-ProjectAccessCacheUserKey -CurrentUser $CurrentUser
    $cacheKey = "project-summary-list|{0}|{1}|{2}|{3}|{4}" -f [string]$StartDate, [string]$EndDate, $scopeKey, $modifyScopeKey, $userScopeKey
    return (Invoke-ReadModelCache -Key $cacheKey -Dependencies @("directory", "auth", "projects", "compensation") -Factory {
        $projects = @($accessModel.Projects)
        $projectMap = @{}
        foreach ($project in $projects) {
            $projectMap[[string]$project.projectCode] = $project
        }

        $stats = Get-ProjectStatisticsOverview -StartDate $StartDate -EndDate $EndDate -IncludeBreakdown:$false -CurrentUser $CurrentUser
        $departmentApprovedSeconds = [long]0
        foreach ($statProjectCode in @($stats.Keys)) {
            $departmentApprovedSeconds += [long]$stats[$statProjectCode].totalSeconds
        }
        $orderedCodes = New-Object System.Collections.ArrayList
        $employeeNameMap = Get-EmployeeNameMap
        $basis = New-ProjectStatisticsBasis
        $period = New-ProjectPeriodModel -StartDate $StartDate -EndDate $EndDate

        foreach ($project in ($projects | Sort-Object projectCode)) {
            if (-not $orderedCodes.Contains([string]$project.projectCode)) {
                [void]$orderedCodes.Add([string]$project.projectCode)
            }
        }

        foreach ($projectCode in ($stats.Keys | Sort-Object)) {
            if (-not $orderedCodes.Contains([string]$projectCode)) {
                [void]$orderedCodes.Add([string]$projectCode)
            }
        }

        $summariesList = New-Object System.Collections.ArrayList
        foreach ($projectCode in $orderedCodes) {
            $project = if ($projectMap.ContainsKey([string]$projectCode)) { $projectMap[[string]$projectCode] } else { $null }
            $projectStats = if ($stats.ContainsKey($projectCode)) { $stats[$projectCode] } else { $null }
            $totalSeconds = if ($projectStats) { [long]$projectStats.totalSeconds } else { [long]0 }
            $trackedSeconds = if ($projectStats) { [long]$projectStats.trackedSeconds } else { [long]0 }
            $entryCount = if ($projectStats) { [int]$projectStats.entryCount } else { 0 }
            $approvedEntryCount = if ($projectStats) { [int]$projectStats.approvedEntryCount } else { 0 }
            $averageSeconds = if ($approvedEntryCount -gt 0) { [long][math]::Round($totalSeconds / $approvedEntryCount) } else { [long]0 }
            $minSeconds = if ($projectStats -and $null -ne $projectStats.minSeconds) { [long]$projectStats.minSeconds } else { [long]0 }
            $maxSeconds = if ($projectStats -and $null -ne $projectStats.maxSeconds) { [long]$projectStats.maxSeconds } else { [long]0 }
            $adminCodes = if ($project) { @(Get-ProjectAdminCodes -Project $project) } else { @() }
            $backupAdminCodes = if ($project) { @(Get-ProjectBackupAdminCodes -Project $project) } else { @() }
            $statusBuckets = ConvertTo-ProjectStatusBucketModel -Buckets $(if ($projectStats) { $projectStats.statusBuckets } else { $null })
            $sharePercent = if ($departmentApprovedSeconds -gt 0) { [math]::Round(($totalSeconds / [double]$departmentApprovedSeconds) * 100, 2) } else { 0 }
            $monetary = ConvertTo-MonetaryAggregateReadModel -Accumulator $(if ($projectStats) { $projectStats.monetary } else { $null })

            [void]$summariesList.Add([PSCustomObject]@{
                projectCode     = [string]$projectCode
                projectName     = if ($project) { [string]$project.projectName } else { [string]$projectCode }
                sector          = if ($project) { [string]$project.sector } else { "" }
                admins          = $adminCodes
                backupAdmins    = $backupAdminCodes
                adminDisplay    = @(New-ProjectAdminDisplayList -Codes $adminCodes -EmployeeNameMap $employeeNameMap)
                backupAdminDisplay = @(New-ProjectAdminDisplayList -Codes $backupAdminCodes -EmployeeNameMap $employeeNameMap)
                archived        = if ($project) { Test-ProjectArchived -Project $project } else { $false }
                colorKey        = Resolve-ProjectColorKey -ColorKey $(if ($project -and $project.PSObject.Properties.Name -contains "colorKey") { [string]$project.colorKey } else { "" }) -ProjectCode ([string]$projectCode)
                markerKey       = Resolve-ProjectMarkerKey -MarkerKey $(if ($project -and $project.PSObject.Properties.Name -contains "markerKey") { [string]$project.markerKey } else { "" }) -ProjectCode ([string]$projectCode)
                basis           = $basis
                period          = $period
                totalSeconds    = $totalSeconds
                totalOvertime   = Convert-SecondsToTimeText -Seconds $totalSeconds
                trackedSeconds  = $trackedSeconds
                trackedOvertime = Convert-SecondsToTimeText -Seconds $trackedSeconds
                entryCount      = $entryCount
                allEntryCount   = $entryCount
                approvedEntryCount = $approvedEntryCount
                averageSeconds  = $averageSeconds
                averageOvertime = Convert-SecondsToTimeText -Seconds $averageSeconds
                minSeconds      = $minSeconds
                minOvertime     = Convert-SecondsToTimeText -Seconds $minSeconds
                maxSeconds      = $maxSeconds
                maxOvertime     = Convert-SecondsToTimeText -Seconds $maxSeconds
                statusBuckets   = $statusBuckets
                monetary       = $monetary
                departmentShare = [PSCustomObject]@{
                    scope                     = "visibleProjects"
                    projectApprovedSeconds    = $totalSeconds
                    departmentApprovedSeconds = $departmentApprovedSeconds
                    percent                   = $sharePercent
                }
            })
        }

        return @($summariesList.ToArray())
    })
}

function New-ProjectAdminDisplayList {
    param(
        $Codes,
        $EmployeeNameMap = $null
    )

    $employeeNameMap = if ($null -ne $EmployeeNameMap) { $EmployeeNameMap } else { Get-EmployeeNameMap }
    $displayList = New-Object System.Collections.ArrayList
    foreach ($code in @(ConvertTo-CodeArray -Value $Codes)) {
        $displayName = if ($employeeNameMap -and ($employeeNameMap.PSObject.Properties.Name -contains [string]$code)) { [string]$employeeNameMap.$code } else { [string]$code }
        [void]$displayList.Add([PSCustomObject]@{
            code = [string]$code
            name = $displayName
        })
    }

    return @($displayList.ToArray())
}

function Get-ProjectPreviousEquivalentPeriod {
    param(
        [AllowNull()][string]$StartDate,
        [AllowNull()][string]$EndDate
    )

    $start = ConvertTo-ProjectDateOrNull -Value $StartDate
    $end = ConvertTo-ProjectDateOrNull -Value $EndDate
    if ($null -eq $start -or $null -eq $end -or $start -gt $end) {
        return [PSCustomObject]@{
            available = $false
            startDate = ""
            endDate   = ""
        }
    }

    $dayCount = [int](($end - $start).TotalDays) + 1
    $previousEnd = $start.AddDays(-1)
    $previousStart = $previousEnd.AddDays(-($dayCount - 1))
    return [PSCustomObject]@{
        available = $true
        startDate = $previousStart.ToString("yyyy-MM-dd", [System.Globalization.CultureInfo]::InvariantCulture)
        endDate   = $previousEnd.ToString("yyyy-MM-dd", [System.Globalization.CultureInfo]::InvariantCulture)
    }
}

function New-ProjectComparisonModel {
    param(
        [Parameter(Mandatory = $true)][long]$CurrentSeconds,
        [AllowNull()][string]$StartDate,
        [AllowNull()][string]$EndDate,
        [Parameter(Mandatory = $true)][string]$ProjectCode,
        $CurrentUser
    )

    $currentPeriod = New-ProjectPeriodModel -StartDate $StartDate -EndDate $EndDate
    $previousPeriod = Get-ProjectPreviousEquivalentPeriod -StartDate $StartDate -EndDate $EndDate
    $previousSeconds = [long]0
    if ([bool]$previousPeriod.available) {
        $previousStats = Get-ProjectStatisticsOverview -StartDate $previousPeriod.startDate -EndDate $previousPeriod.endDate -IncludeBreakdown:$false -FilterProjectCode $ProjectCode -CurrentUser $CurrentUser
        if ($previousStats.ContainsKey($ProjectCode)) {
            $previousSeconds = [long]$previousStats[$ProjectCode].totalSeconds
        }
    }

    $deltaSeconds = $CurrentSeconds - $previousSeconds
    $direction = if (-not [bool]$previousPeriod.available) { "unavailable" } elseif ($deltaSeconds -gt 0) { "up" } elseif ($deltaSeconds -lt 0) { "down" } else { "same" }
    $percentChange = if ([bool]$previousPeriod.available -and $previousSeconds -gt 0) {
        [math]::Round(($deltaSeconds / [double]$previousSeconds) * 100, 1)
    }
    else {
        $null
    }

    return [PSCustomObject]@{
        available = [bool]$previousPeriod.available
        current   = [PSCustomObject]@{
            startDate = [string]$currentPeriod.startDate
            endDate   = [string]$currentPeriod.endDate
            seconds   = $CurrentSeconds
            overtime  = Convert-SecondsToTimeText -Seconds $CurrentSeconds
        }
        previous  = [PSCustomObject]@{
            startDate = [string]$previousPeriod.startDate
            endDate   = [string]$previousPeriod.endDate
            seconds   = $previousSeconds
            overtime  = Convert-SecondsToTimeText -Seconds $previousSeconds
        }
        deltaSeconds = $deltaSeconds
        percentChange = $percentChange
        direction    = $direction
    }
}

function Get-ProjectDetailModel {
    param(
        [Parameter(Mandatory = $true)][string]$ProjectCode,
        [string]$StartDate,
        [string]$EndDate,
        $CurrentUser
    )

    $userScopeKey = Get-ProjectAccessCacheUserKey -CurrentUser $CurrentUser
    $key = "project-detail|$ProjectCode|$StartDate|$EndDate|$userScopeKey"
    return (Invoke-ReadModelCache -Key $key -Dependencies @("directory", "auth", "projects", "compensation") -Factory {
        New-ProjectDetailModel -ProjectCode $ProjectCode -StartDate $StartDate -EndDate $EndDate -CurrentUser $CurrentUser
    })
}

function New-ProjectDetailModel {
    param(
        [Parameter(Mandatory = $true)][string]$ProjectCode,
        [string]$StartDate,
        [string]$EndDate,
        $CurrentUser
    )

    $summaries = @(Get-ProjectSummaryList -StartDate $StartDate -EndDate $EndDate -CurrentUser $CurrentUser)
    $projectSummary = $summaries | Where-Object { [string]$_.projectCode -eq [string]$ProjectCode } | Select-Object -First 1
    if ($null -eq $projectSummary) {
        return $null
    }

    $stats = Get-ProjectStatisticsOverview -StartDate $StartDate -EndDate $EndDate -FilterProjectCode $ProjectCode -IncludeEntryDetails:$false -CurrentUser $CurrentUser
    $projectStats = if ($stats.ContainsKey($ProjectCode)) { $stats[$ProjectCode] } else { $null }
    $contributorsList = New-Object System.Collections.ArrayList
    $recentEntriesList = New-Object System.Collections.ArrayList

    if ($projectStats) {
        foreach ($employeeCode in @($projectStats.breakdown.Keys)) {
            $employeeStats = $projectStats.breakdown[$employeeCode]
            $approvedSeconds = [long]$employeeStats.totalSeconds
            $approvedEntryCount = [int]$employeeStats.approvedEntryCount
            $averageApprovedSeconds = if ($approvedEntryCount -gt 0) { [long][math]::Round($approvedSeconds / $approvedEntryCount) } else { [long]0 }
            $sharePercent = if ([long]$projectStats.totalSeconds -gt 0) { [math]::Round(($approvedSeconds / [double]$projectStats.totalSeconds) * 100, 2) } else { 0 }
            foreach ($entry in @($employeeStats.entries)) {
                [void]$recentEntriesList.Add($entry)
            }

            [void]$contributorsList.Add([PSCustomObject]@{
                employeeCode = [string]$employeeStats.employeeCode
                employee     = [string]$employeeStats.employeeName
                employeeArchived = [bool]$employeeStats.employeeArchived
                approvedSeconds = $approvedSeconds
                overtime     = Convert-SecondsToTimeText -Seconds $approvedSeconds
                approvedEntryCount = $approvedEntryCount
                entryCount   = [int]$employeeStats.entryCount
                pendingCount = [int]$employeeStats.pendingCount
                pendingSeconds = [long]$employeeStats.pendingSeconds
                pendingOvertime = Convert-SecondsToTimeText -Seconds ([long]$employeeStats.pendingSeconds)
                openCount    = [int]$employeeStats.openCount
                sharePercent = $sharePercent
                averageApprovedSeconds = $averageApprovedSeconds
                averageOvertime = Convert-SecondsToTimeText -Seconds $averageApprovedSeconds
                monetary     = ConvertTo-MonetaryAggregateReadModel -Accumulator $employeeStats.monetary
                lastActivityDate = [string]$employeeStats.lastActivityDate
                lastActivityAt = [string]$employeeStats.lastActivityAt
            })
        }
    }

    $contributors = @($contributorsList.ToArray() | Sort-Object `
        @{ Expression = { [long]$_.approvedSeconds }; Descending = $true }, `
        @{ Expression = { [string]$_.employee }; Descending = $false }, `
        @{ Expression = { [string]$_.employeeCode }; Descending = $false })
    $recentSources = @($recentEntriesList.ToArray() | Sort-Object `
        @{ Expression = { Get-EntryDateTimeOrMin -Entry $_ }; Descending = $true }, `
        @{ Expression = { [string]$_.entryId }; Descending = $false } | Select-Object -First 20)
    $modifyAccessModel = Get-ProjectModificationAccessModelForCurrentUser -CurrentUser $CurrentUser
    $isSuperAdmin = Test-CurrentUserSuperAdmin -CurrentUser $CurrentUser
    $canApproveByEmployee = @{}
    $recentEntries = @(foreach ($entry in $recentSources) {
        $publicEntry = ConvertTo-ProjectEntryAccessProjection -Entry $entry -CurrentUser $CurrentUser -ModifyAccessModel $modifyAccessModel -IsSuperAdmin:$isSuperAdmin -CanApproveByEmployee $canApproveByEmployee
        New-ProjectEntryDetailProjection -Entry $publicEntry -StatusBucket (Get-ProjectEntryStatusBucketName -Entry $entry) -DurationSeconds ([long](Get-OvertimeSecondsFromText -Value ([string]$entry.overtime)))
    })
    $comparison = New-ProjectComparisonModel -CurrentSeconds ([long]$projectSummary.totalSeconds) -StartDate $StartDate -EndDate $EndDate -ProjectCode $ProjectCode -CurrentUser $CurrentUser
    $trendModel = Get-ProjectTrendModel -StartDate $StartDate -EndDate $EndDate -CurrentUser $CurrentUser
    $approvedTrend = if ($trendModel.ContainsKey($ProjectCode)) { @($trendModel[$ProjectCode]) } else { @() }

    return [PSCustomObject]@{
        projectCode         = [string]$projectSummary.projectCode
        projectName         = [string]$projectSummary.projectName
        sector              = if ($projectSummary.PSObject.Properties.Name -contains "sector") { [string]$projectSummary.sector } else { "" }
        admins              = if ($projectSummary.PSObject.Properties.Name -contains "admins") { @($projectSummary.admins) } else { @() }
        backupAdmins        = if ($projectSummary.PSObject.Properties.Name -contains "backupAdmins") { @($projectSummary.backupAdmins) } else { @() }
        adminDisplay        = if ($projectSummary.PSObject.Properties.Name -contains "adminDisplay") { @($projectSummary.adminDisplay) } else { @() }
        backupAdminDisplay  = if ($projectSummary.PSObject.Properties.Name -contains "backupAdminDisplay") { @($projectSummary.backupAdminDisplay) } else { @() }
        archived            = if ($projectSummary.PSObject.Properties.Name -contains "archived") { [bool]$projectSummary.archived } else { $false }
        colorKey            = Resolve-ProjectColorKey -ColorKey $(if ($projectSummary.PSObject.Properties.Name -contains "colorKey") { [string]$projectSummary.colorKey } else { "" }) -ProjectCode ([string]$projectSummary.projectCode)
        markerKey           = Resolve-ProjectMarkerKey -MarkerKey $(if ($projectSummary.PSObject.Properties.Name -contains "markerKey") { [string]$projectSummary.markerKey } else { "" }) -ProjectCode ([string]$projectSummary.projectCode)
        basis               = $projectSummary.basis
        period              = $projectSummary.period
        totalSeconds        = [long]$projectSummary.totalSeconds
        totalOvertime       = [string]$projectSummary.totalOvertime
        trackedSeconds      = [long]$projectSummary.trackedSeconds
        trackedOvertime     = [string]$projectSummary.trackedOvertime
        entryCount          = [int]$projectSummary.entryCount
        allEntryCount       = [int]$projectSummary.allEntryCount
        approvedEntryCount  = [int]$projectSummary.approvedEntryCount
        averageSeconds      = [long]$projectSummary.averageSeconds
        averageOvertime     = [string]$projectSummary.averageOvertime
        minSeconds          = [long]$projectSummary.minSeconds
        minOvertime         = [string]$projectSummary.minOvertime
        maxSeconds          = [long]$projectSummary.maxSeconds
        maxOvertime         = [string]$projectSummary.maxOvertime
        statusBuckets       = $projectSummary.statusBuckets
        monetary           = $projectSummary.monetary
        departmentShare     = $projectSummary.departmentShare
        comparison          = $comparison
        contributors        = $contributors
        breakdownByEmployee = $contributors
        recentEntries       = $recentEntries
        approvedTrend       = $approvedTrend
        coverage            = [PSCustomObject]@{
            includesArchivedEmployees = $true
        }
    }
}

function Get-ProjectTrendModel {
    param(
        [string]$StartDate,
        [string]$EndDate,
        $CurrentUser
    )

    $accessModel = Get-ProjectAccessModelForCurrentUser -CurrentUser $CurrentUser
    $userScopeKey = Get-ProjectAccessCacheUserKey -CurrentUser $CurrentUser
    $scopeKey = if (Test-CurrentUserSuperAdmin -CurrentUser $CurrentUser) { "global" } else { (@($accessModel.ProjectCodes) -join ",") }
    $cacheKey = "project-trends|approved-closed|{0}|{1}|{2}|{3}" -f [string]$StartDate, [string]$EndDate, $scopeKey, $userScopeKey
    return (Invoke-ReadModelCache -Key $cacheKey -Dependencies @("directory", "auth", "projects", "compensation") -Factory {
        $trendStats = @{}
        # The portfolio already aggregates this exact period. Reuse its month
        # buckets instead of traversing and classifying every entry a second time.
        $statistics = Get-ProjectStatisticsOverview -StartDate $StartDate -EndDate $EndDate -IncludeBreakdown:$false -CurrentUser $CurrentUser
        foreach ($projectCode in @($statistics.Keys)) {
            if ($statistics[$projectCode].approvedMonths.Count -gt 0) {
                $trendStats[$projectCode] = $statistics[$projectCode].approvedMonths
            }
        }

        $result = @{}
        foreach ($projectCode in $trendStats.Keys) {
            $monthsList = New-Object System.Collections.ArrayList
            foreach ($month in ($trendStats[$projectCode].Keys | Sort-Object)) {
                $seconds = [long]$trendStats[$projectCode][$month]
                [void]$monthsList.Add([PSCustomObject]@{
                    month    = $month
                    overtime = [math]::Round(($seconds / 3600), 2)
                    seconds  = $seconds
                    duration = Convert-SecondsToTimeText -Seconds $seconds
                })
            }

            $result[$projectCode] = @($monthsList.ToArray())
        }

        return $result
    })
}

function Get-ProjectsBootstrapModel {
    param(
        [string]$StartDate,
        [string]$EndDate,
        [string]$SelectedProjectCode,
        [AllowNull()][string]$Scope = "all",
        [bool]$IncludeDetail = $true,
        $CurrentUser
    )

    $normalizedScope = ConvertTo-ProjectArchiveScope -Scope $Scope
    $allSummary = @(Get-ProjectSummaryList -StartDate $StartDate -EndDate $EndDate -CurrentUser $CurrentUser)
    $summary = @(Select-ProjectsByArchiveScope -Projects $allSummary -Scope $normalizedScope)
    $allTrends = Get-ProjectTrendModel -StartDate $StartDate -EndDate $EndDate -CurrentUser $CurrentUser
    $visibleProjectCodes = @{}
    foreach ($project in $summary) {
        $visibleProjectCodes[[string]$project.projectCode] = $true
    }
    $trends = @{}
    foreach ($projectCode in @($allTrends.Keys)) {
        if ($visibleProjectCodes.ContainsKey([string]$projectCode)) {
            $trends[[string]$projectCode] = $allTrends[$projectCode]
        }
    }

    $resolvedProjectCode = [string]$SelectedProjectCode
    if ([string]::IsNullOrWhiteSpace($resolvedProjectCode) -or -not ($summary | Where-Object { [string]$_.projectCode -eq $resolvedProjectCode })) {
        if ($summary.Count -gt 0) {
            $resolvedProjectCode = [string]$summary[0].projectCode
        }
        else {
            $resolvedProjectCode = ""
        }
    }

    return [PSCustomObject]@{
        summary             = $summary
        trends              = $trends
        scope               = $normalizedScope
        selectedProjectCode = $resolvedProjectCode
        detailIncluded      = [bool]$IncludeDetail
        selectedProject     = if ($IncludeDetail -and $resolvedProjectCode) { Get-ProjectDetailModel -ProjectCode $resolvedProjectCode -StartDate $StartDate -EndDate $EndDate -CurrentUser $CurrentUser } else { $null }
    }
}

function Get-SelfBootstrapModel {
    param([Parameter(Mandatory = $true)][string]$EmployeeCode)

    $dataFile = Join-Path -Path $sharedFolder -ChildPath ("{0}_data.json" -f $EmployeeCode)
    $user = Get-EmployeeUserByCode -EmployeeCode $EmployeeCode
    $employeeName = if ($null -ne $user -and $user.displayName) { [string]$user.displayName } else { [string](Get-EmployeeName $EmployeeCode) }
    $employeeRole = if ($null -ne $user) { Get-EffectiveUserRole -UserRecord $user } else { "employee" }
    $entries = @(
        Get-CachedEmployeeEntriesForFile -DataFile $dataFile |
            ForEach-Object { New-EmployeeEntryProjection -EmployeeCode $EmployeeCode -EmployeeName $employeeName -Entry $_ -EmployeeRole $employeeRole }
    )
    $timeEntryTypes = @(Get-EmployeeTimeEntryTypesByCode -EmployeeCode $EmployeeCode)

    return [PSCustomObject]@{
        entries        = $entries
        projects       = @(Get-ActiveProjects)
        overtimeCodes  = @(Get-OvertimeCodes)
        paymentOptions = @(Get-PaymentOptions)
        reasonCodes    = @(Get-ReasonCodes)
        timeEntryTypes = $timeEntryTypes
        gc179Profile   = Get-Gc179ProfileFromUserRecord -UserRecord $user
    }
}
