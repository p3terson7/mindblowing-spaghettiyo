﻿$overtimeCompensationModuleManifest = Join-Path -Path $PSScriptRoot -ChildPath "../modules/Saphir.OvertimeCompensation.psd1"
Import-Module -Name $overtimeCompensationModuleManifest -Force -ErrorAction Stop | Out-Null
Remove-Variable -Name overtimeCompensationModuleManifest -ErrorAction SilentlyContinue
Import-Module -Name (Join-Path $PSScriptRoot "../modules/Saphir.EntryDuration.psd1") -ErrorAction Stop | Out-Null

function ConvertTo-Gc179MonthParts {
    param([Parameter(Mandatory = $true)][string]$MonthKey)

    $normalized = ([string]$MonthKey).Trim()
    if ($normalized -notmatch "^\d{4}-\d{2}$") {
        throw "Month must use YYYY-MM format."
    }

    $year = [int]$normalized.Substring(0, 4)
    $month = [int]$normalized.Substring(5, 2)
    if ($month -lt 1 -or $month -gt 12) {
        throw "Month must be between 01 and 12."
    }

    return [PSCustomObject]@{
        MonthKey = $normalized
        Year     = $year
        Month    = $month
    }
}

function Get-Gc179HeaderValues {
    param(
        [Parameter(Mandatory = $true)][string]$EmployeeCode,
        [Parameter(Mandatory = $true)]$MonthParts
    )

    $user = Get-EmployeeUserByCode -EmployeeCode $EmployeeCode
    $displayName = if ($null -ne $user -and $user.PSObject.Properties.Name -contains "displayName") {
        [string]$user.displayName
    }
    else {
        [string](Get-EmployeeName $EmployeeCode)
    }

    $profile = if ($null -ne $user) {
        Get-Gc179ProfileFromUserRecord -UserRecord $user
    }
    else {
        ConvertTo-Gc179ProfileObject -Value $null -DisplayName $displayName
    }

    $group = ConvertTo-Gc179GroupText -Value ([string]$profile.group)
    if ([string]::IsNullOrWhiteSpace($group)) {
        $group = "STS"
    }

    $subGroup = ConvertTo-Gc179SubGroupText -Value ([string]$profile.subGroup)
    if ([string]::IsNullOrWhiteSpace($subGroup)) {
        $subGroup = "00"
    }

    $level = ConvertTo-Gc179LevelText -Value ([string]$profile.level)

    return [PSCustomObject]@{
        Month     = ([int]$MonthParts.Month).ToString("00", [System.Globalization.CultureInfo]::InvariantCulture)
        Year      = [string]$MonthParts.Year
        Department = "GRC-RCMP"
        # Official GC179 organizational branch code; this is form data, not the application name.
        Branch    = "CDIV-PTSO-GEEM"
        Paylist   = "0337"
        Group     = $group
        SubGroup  = $subGroup
        Surname   = [string]$profile.surname
        Given     = [string]$profile.givenName
        Initials  = [string]$profile.initials
        PRI       = ConvertTo-Gc179PriText -Value ([string]$profile.pri)
        Level     = $level
        WorkWeek  = if ($profile.compressedWorkWeek) { "2" } else { "1" }
    }
}

function ConvertTo-Gc179FdfLiteral {
    param([AllowNull()][string]$Value)

    $text = if ($null -eq $Value) { "" } else { [string]$Value }
    $text = $text.Replace("\", "\\")
    $text = $text.Replace("(", "\(")
    $text = $text.Replace(")", "\)")
    $text = $text.Replace("`r`n", "\r")
    $text = $text.Replace("`r", "\r")
    $text = $text.Replace("`n", "\r")
    return $text
}

function ConvertTo-Gc179FdfStringToken {
    param([AllowNull()][string]$Value)

    $text = if ($null -eq $Value) { "" } else { [string]$Value }
    if ($text -notmatch "[^\x00-\x7F]") {
        return "($(ConvertTo-Gc179FdfLiteral -Value $text))"
    }

    $bytes = [System.Text.Encoding]::BigEndianUnicode.GetBytes($text)
    $hex = "FEFF" + ([System.BitConverter]::ToString($bytes)).Replace("-", "")
    return "<$hex>"
}

function ConvertTo-Gc179FileNameToken {
    param(
        [AllowNull()][string]$Value,
        [bool]$FirstTokenOnly = $false,
        [string]$Fallback = "UNKNOWN"
    )

    $text = if ($null -eq $Value) { "" } else { ([string]$Value).Trim() }
    if ($FirstTokenOnly -and -not [string]::IsNullOrWhiteSpace($text)) {
        $parts = @($text -split "[\s_-]+" | Where-Object { -not [string]::IsNullOrWhiteSpace($_) })
        if ($parts.Count -gt 0) {
            $text = [string]$parts[0]
        }
    }

    try {
        $normalized = $text.Normalize([System.Text.NormalizationForm]::FormD)
        $builder = New-Object System.Text.StringBuilder
        foreach ($character in $normalized.ToCharArray()) {
            $category = [System.Globalization.CharUnicodeInfo]::GetUnicodeCategory($character)
            if ($category -ne [System.Globalization.UnicodeCategory]::NonSpacingMark) {
                [void]$builder.Append($character)
            }
        }
        $text = $builder.ToString()
    }
    catch {
        # Keep the original value if Unicode normalization is unavailable.
    }

    $safe = [System.Text.RegularExpressions.Regex]::Replace($text.ToUpperInvariant(), "[^0-9A-Z]+", "_").Trim("_")
    if ([string]::IsNullOrWhiteSpace($safe)) {
        return $Fallback
    }

    return $safe
}

function Get-Gc179ExportBaseFileName {
    param(
        [Parameter(Mandatory = $true)][string]$EmployeeCode,
        [Parameter(Mandatory = $true)]$HeaderValues,
        [Parameter(Mandatory = $true)]$MonthParts,
        [int]$PartNumber = 1,
        [int]$PartCount = 1,
        [bool]$IncludesTimePayment = $false
    )

    $hrmis = ConvertTo-Gc179FileNameToken -Value $EmployeeCode -Fallback "HRMIS"
    $surname = ConvertTo-Gc179FileNameToken -Value ([string]$HeaderValues.Surname) -Fallback "NOM"
    $givenName = ConvertTo-Gc179FileNameToken -Value ([string]$HeaderValues.Given) -FirstTokenOnly $true -Fallback "X"
    $givenInitial = if ([string]::IsNullOrWhiteSpace($givenName)) { "X" } else { $givenName.Substring(0, 1) }
    $monthKey = [string]$MonthParts.MonthKey
    $baseName = "{0}_{1}_{2}_GC179_{3}" -f $hrmis, $surname, $givenInitial, $monthKey

    if ($PartCount -gt 1) {
        $baseName = "{0}_{1}sur{2}" -f $baseName, $PartNumber, $PartCount
    }

    if ($IncludesTimePayment) {
        $baseName = "{0}_TEMPS" -f $baseName
    }

    return $baseName
}

function Add-Gc179FdfTextField {
    param(
        [Parameter(Mandatory = $true)]$Builder,
        [Parameter(Mandatory = $true)][string]$Name,
        [AllowNull()][string]$Value
    )

    [void]$Builder.AppendLine("<<")
    [void]$Builder.AppendLine("/T ($Name)")
    [void]$Builder.AppendLine("/V $(ConvertTo-Gc179FdfStringToken -Value $Value)")
    [void]$Builder.AppendLine(">>")
}

function Add-Gc179FdfNameField {
    param(
        [Parameter(Mandatory = $true)]$Builder,
        [Parameter(Mandatory = $true)][string]$Name,
        [Parameter(Mandatory = $true)][string]$ValueName
    )

    $safeValueName = ([string]$ValueName).Trim()
    if ($safeValueName -notmatch "^[0-9A-Za-z_.-]+$") {
        $safeValueName = "Off"
    }

    [void]$Builder.AppendLine("<<")
    [void]$Builder.AppendLine("/T ($Name)")
    [void]$Builder.AppendLine("/V /$safeValueName")
    [void]$Builder.AppendLine(">>")
}

function Get-Gc179PaymentFieldName {
    param([Parameter(Mandatory = $true)][int]$RowIndex)

    if ($RowIndex -eq 0) {
        return "Payment"
    }

    return ("Payment{0}" -f $RowIndex)
}

function Get-Gc179PaymentValueName {
    param([AllowNull()][string]$PaymentOption)

    $normalized = ([string]$PaymentOption).Trim().ToLowerInvariant()
    if ($normalized -eq "cash" -or $normalized -eq "en espece" -or $normalized -eq "en espèce") {
        return "1"
    }

    if ($normalized -eq "leave" -or $normalized -eq "conge" -or $normalized -eq "congé") {
        return "2"
    }

    return "1"
}

function ConvertTo-Gc179TimeText {
    param([AllowNull()][string]$TimeText)

    $normalized = Convert-ToNormalizedTimeText -TimeText ([string]$TimeText)
    if ([string]::IsNullOrWhiteSpace($normalized)) {
        return ""
    }

    $time = [datetime]::ParseExact($normalized, "HH:mm:ss", [System.Globalization.CultureInfo]::InvariantCulture)
    return (Saphir.EntryDuration\ConvertTo-SaphirNearestQuarterHourTime -Time $time).Substring(0, 5)
}

function ConvertTo-Gc179DayText {
    param([Parameter(Mandatory = $true)][DateTime]$Date)

    return $Date.ToString("dd", [System.Globalization.CultureInfo]::InvariantCulture)
}

function ConvertTo-Gc179WeekdayText {
    param([Parameter(Mandatory = $true)][DateTime]$Date)

    switch ($Date.DayOfWeek) {
        "Monday" { return "Mon" }
        "Tuesday" { return "Tue" }
        "Wednesday" { return "Wed" }
        "Thursday" { return "Thu" }
        "Friday" { return "Fri" }
        "Saturday" { return "Sat" }
        "Sunday" { return "Sun" }
        default { return "" }
    }
}

function ConvertTo-Gc179DurationText {
    param($Entry)

    if ($null -eq $Entry) {
        return ""
    }

    if ($Entry.PSObject.Properties.Name -contains "overtime" -and -not [string]::IsNullOrWhiteSpace([string]$Entry.overtime)) {
        $parts = @(([string]$Entry.overtime).Split(":"))
        if ($parts.Count -ge 2) {
            $hours = 0
            $minutes = 0
            if ([int]::TryParse([string]$parts[0], [ref]$hours) -and [int]::TryParse([string]$parts[1], [ref]$minutes)) {
                $totalMinutes = (($hours * 60) + $minutes)
                if ($parts.Count -ge 3) {
                    $seconds = 0
                    if ([int]::TryParse([string]$parts[2], [ref]$seconds) -and $seconds -ge 30) {
                        $totalMinutes++
                    }
                }

                if ($totalMinutes -le 0) {
                    return ""
                }

                return (($totalMinutes / 60.0).ToString("0.00", [System.Globalization.CultureInfo]::InvariantCulture))
            }
        }
    }

    try {
        $punchIn = Convert-ToNormalizedTimeText -TimeText ([string]$Entry.punchIn)
        $punchOut = Convert-ToNormalizedTimeText -TimeText ([string]$Entry.punchOut)
        if ([string]::IsNullOrWhiteSpace($punchIn) -or [string]::IsNullOrWhiteSpace($punchOut)) {
            return ""
        }

        $start = [DateTime]::ParseExact(("{0} {1}" -f [string]$Entry.date, $punchIn), "yyyy-MM-dd HH:mm:ss", [System.Globalization.CultureInfo]::InvariantCulture)
        $end = [DateTime]::ParseExact(("{0} {1}" -f [string]$Entry.date, $punchOut), "yyyy-MM-dd HH:mm:ss", [System.Globalization.CultureInfo]::InvariantCulture)
        if ($end -le $start) {
            $end = $end.AddDays(1)
        }

        $totalMinutes = [int][math]::Round(($end - $start).TotalMinutes)
        if ($totalMinutes -le 0) {
            return ""
        }

        return (($totalMinutes / 60.0).ToString("0.00", [System.Globalization.CultureInfo]::InvariantCulture))
    }
    catch {
        return ""
    }
}

function Get-Gc179DurationFieldDefinitions {
    return @(
        [PSCustomObject]@{ Category = "regular"; Field1 = "RegTime"; Field15 = "RegTimeHalf"; Field175 = "RegTime3Quarter"; Field2 = "RegTimeDouble" },
        [PSCustomObject]@{ Category = "first-day-rest"; Field1 = "FirstDayRest"; Field15 = "FirstDayTimeHalf"; Field175 = "FirstDay3Quarter"; Field2 = "FirstDayTimeDbl" },
        [PSCustomObject]@{ Category = "subsequent-day-rest"; Field1 = "SubseqDayRest"; Field15 = "SubseqTimeHalf"; Field175 = "SubseqTime3Quarter"; Field2 = "SubseqTimeDbl" },
        [PSCustomObject]@{ Category = "holiday"; Field1 = "Holiday"; Field15 = "HolidayTimeHalf"; Field175 = "HolidayTime3quarter"; Field2 = "HolidayTimeDbl" }
    )
}

function Get-Gc179EntryDurationCategory {
    param([AllowNull()][string]$OvertimeCode)

    return (Saphir.OvertimeCompensation\Get-SaphirOvertimeCategory -OvertimeCode $OvertimeCode)
}

function Get-Gc179DurationFieldName {
    param(
        [Parameter(Mandatory = $true)][string]$Category,
        [Parameter(Mandatory = $true)][ValidateSet("1.0", "1.5", "1.75", "2.0")][string]$Rate
    )

    $definition = @(Get-Gc179DurationFieldDefinitions | Where-Object { $_.Category -eq $Category } | Select-Object -First 1)
    if ($definition.Count -eq 0) {
        throw "Unsupported GC179 duration category: $Category"
    }

    switch ($Rate) {
        "1.0" { return [string]$definition[0].Field1 }
        "1.5" { return [string]$definition[0].Field15 }
        "1.75" { return [string]$definition[0].Field175 }
        default { return [string]$definition[0].Field2 }
    }
}

function ConvertTo-Gc179HoursText {
    param([Parameter(Mandatory = $true)][double]$Hours)

    return $Hours.ToString("0.##", [System.Globalization.CultureInfo]::InvariantCulture)
}

function Get-Gc179CalculatedDurationFields {
    param(
        [Parameter(Mandatory = $true)]$Entry,
        [Parameter(Mandatory = $true)][bool]$CompressedWorkWeek,
        [double]$PreviouslyCreditedHours = 0,
        [bool]$HolidayAdjacentToSecondRest = $false,
        [AllowNull()][string]$Group = "",
        [bool]$HolidayAdjacentToWorkedRest = $false,
        [AllowNull()][Nullable[bool]]$HolidayNotScheduledWorkday = $null,
        [bool]$ContinueAtDoubleTime = $false
    )

    $durationHours = 0.0
    if (-not [double]::TryParse(
        (ConvertTo-Gc179DurationText -Entry $Entry),
        [System.Globalization.NumberStyles]::Float,
        [System.Globalization.CultureInfo]::InvariantCulture,
        [ref]$durationHours
    ) -or $durationHours -le 0) {
        return @{}
    }

    $fields = @{}
    $workSchedule = if ($CompressedWorkWeek) { "compressed" } else { "regular" }
    $segments = @(Saphir.OvertimeCompensation\Get-SaphirOvertimeRateSegments `
        -OvertimeCode ([string]$Entry.overtimeCode) `
        -WorkSchedule $workSchedule `
        -Hours ([decimal]$durationHours) `
        -PreviouslyCreditedHours ([decimal]$PreviouslyCreditedHours) `
        -HolidayAdjacentToSecondRest $HolidayAdjacentToSecondRest `
        -Group $Group -HolidayAdjacentToWorkedRest $HolidayAdjacentToWorkedRest `
        -HolidayNotScheduledWorkday $HolidayNotScheduledWorkday -ContinueAtDoubleTime $ContinueAtDoubleTime)

    foreach ($segment in $segments) {
        $rate = ([decimal]$segment.multiplier).ToString("0.##", [System.Globalization.CultureInfo]::InvariantCulture)
        if ($rate -eq "1") { $rate = "1.0" }
        elseif ($rate -eq "2") { $rate = "2.0" }
        $fieldName = Get-Gc179DurationFieldName -Category ([string]$segment.category) -Rate $rate
        $fields[$fieldName] = ConvertTo-Gc179HoursText -Hours ([double]$segment.hours)
    }
    return $fields
}

function Add-Gc179DurationFields {
    param(
        [Parameter(Mandatory = $true)]$Builder,
        [Parameter(Mandatory = $true)][int]$RowIndex,
        [Parameter(Mandatory = $true)]$DurationFields
    )

    $fieldNames = @(Get-Gc179DurationFieldDefinitions | ForEach-Object {
        @($_.Field1, $_.Field15, $_.Field175, $_.Field2)
    })
    foreach ($fieldName in $fieldNames) {
        $value = if ($DurationFields.ContainsKey([string]$fieldName)) { [string]$DurationFields[[string]$fieldName] } else { "" }
        Add-Gc179FdfTextField -Builder $Builder -Name ("{0}.{1}" -f $fieldName, $RowIndex) -Value $value
    }
}

function Get-Gc179EntryWorkSchedule {
    param($Entry)

    $value = if ($null -ne $Entry -and $Entry.PSObject.Properties.Name -contains "workSchedule") { ([string]$Entry.workSchedule).Trim().ToLowerInvariant() } else { "" }
    if ($value -in @("regular", "compressed")) { return $value }
    return "unconfirmed"
}

function Test-Gc179DiverseEntry {
    param($Entry)

    return ($null -ne $Entry -and $Entry.PSObject.Properties.Name -contains "entryType" -and
        ([string]$Entry.entryType).Trim().ToLowerInvariant() -eq "diverse")
}

function Get-Gc179ExportDurationFields {
    param([Parameter(Mandatory = $true)]$Entry)

    # Diverse time is exported for manual entitlement allocation, even if a
    # legacy record happens to contain imported rate components.
    if (Test-Gc179DiverseEntry -Entry $Entry) { return @{} }

    # A re-export must preserve the explicit entitlement columns from the form
    # when their total still matches the entry (including split-rate rows).
    $fields = @{}
    $validNames = @("RegTime", "RegTimeHalf", "RegTime3Quarter", "RegTimeDouble",
        "FirstDayRest", "FirstDayTimeHalf", "FirstDay3Quarter", "FirstDayTimeDbl",
        "SubseqDayRest", "SubseqTimeHalf", "SubseqTime3Quarter", "SubseqTimeDbl",
        "Holiday", "HolidayTimeHalf", "HolidayTime3quarter", "HolidayTimeDbl",
        "CallBack", "StandbyWD", "StandbyWE", "ShiftWD_Ev", "ShiftWD_Night",
        "ShiftSatDay", "ShiftSatEven", "ShiftSatNight", "ShiftSunDay", "ShiftSunEven", "ShiftSunNight")
    $totalHours = 0.0
    foreach ($component in @($Entry.gc179RateComponents)) {
        if ($null -eq $component) { continue }
        $field = [string]$component.field
        $hours = 0.0
        if ($field -notin $validNames -or $fields.ContainsKey($field) -or
            -not [double]::TryParse([string]$component.hours, [System.Globalization.NumberStyles]::Float, [System.Globalization.CultureInfo]::InvariantCulture, [ref]$hours) -or
            [double]::IsNaN($hours) -or [double]::IsInfinity($hours) -or $hours -le 0) { return @{} }
        $fields[$field] = $hours.ToString("0.##", [System.Globalization.CultureInfo]::InvariantCulture)
        $totalHours += $hours
    }
    $durationHours = 0.0
    if (-not [double]::TryParse((ConvertTo-Gc179DurationText -Entry $Entry), [System.Globalization.NumberStyles]::Float, [System.Globalization.CultureInfo]::InvariantCulture, [ref]$durationHours) -or
        [math]::Abs($durationHours - $totalHours) -gt (1.0 / 60)) { return @{} }
    return $fields
}

function Assert-Gc179EntrySchedule {
    param([Parameter(Mandatory = $true)]$Entry)

    # No rate is calculated for diverse time, so an unknown schedule must not
    # prevent the employee from completing the GC179 manually.
    if (Test-Gc179DiverseEntry -Entry $Entry) { return }

    if ((Get-Gc179EntryWorkSchedule -Entry $Entry) -eq "unconfirmed" -and (Get-Gc179ExportDurationFields -Entry $Entry).Count -eq 0) {
        throw ("L'horaire de l'entrée du {0} à {1} est à confirmer. Un superviseur doit ouvrir Modifier et choisir Horaire régulier ou Temps comprimé avant l'export GC179." -f $Entry.date, $Entry.punchIn)
    }
}

function Test-Gc179WorkedDateEntry {
    param($Entry)

    if ($null -eq $Entry) {
        return $false
    }

    $entryDate = [string]$Entry.date
    if ([string]::IsNullOrWhiteSpace($entryDate) -or $entryDate -notmatch "^\d{4}-\d{2}-\d{2}$") {
        return $false
    }

    $status = ([string]$Entry.status).Trim().ToLowerInvariant()
    if ([string]::IsNullOrWhiteSpace($status)) {
        $status = "pending"
    }
    if ($status -eq "rejected") {
        return $false
    }

    $entryType = "overtime"
    if ($Entry.PSObject.Properties.Name -contains "entryType" -and -not [string]::IsNullOrWhiteSpace([string]$Entry.entryType)) {
        $entryType = ([string]$Entry.entryType).Trim().ToLowerInvariant()
    }
    if ($entryType -eq "diverse") {
        return $false
    }

    return (
        -not [string]::IsNullOrWhiteSpace([string]$Entry.punchIn) -and
        -not [string]::IsNullOrWhiteSpace([string]$Entry.punchOut) -and
        -not [string]::IsNullOrWhiteSpace((ConvertTo-Gc179DurationText -Entry $Entry))
    )
}

function Get-Gc179WorkedDateSet {
    param([Parameter(Mandatory = $true)][string]$EmployeeCode)

    $dataFile = Ensure-EmployeeDataFile -EmployeeCode $EmployeeCode
    $entries = @(Get-CachedEmployeeEntriesForFile -DataFile $dataFile)
    $workedDateSet = @{}

    foreach ($entry in $entries) {
        if (Test-Gc179WorkedDateEntry -Entry $entry) {
            $dateKey = [string]$entry.date
            if (-not $workedDateSet.ContainsKey($dateKey) -or -not ($workedDateSet[$dateKey] -is [System.Collections.IDictionary])) {
                $workedDateSet[$dateKey] = @{}
            }
            $workedDateSet[$dateKey][([string]$entry.overtimeCode).Trim()] = $true
        }
    }

    return $workedDateSet
}

function Test-Gc179WorkedDateCode {
    param(
        [Parameter(Mandatory = $true)]$WorkedDateSet,
        [Parameter(Mandatory = $true)][string]$DateKey,
        [Parameter(Mandatory = $true)][string]$OvertimeCode
    )

    if (-not $WorkedDateSet -or -not $WorkedDateSet.ContainsKey($DateKey)) {
        return $false
    }
    $dateValue = $WorkedDateSet[$DateKey]
    return ($dateValue -is [System.Collections.IDictionary] -and $dateValue.Contains($OvertimeCode))
}

function Test-Gc179HolidayAdjacentToSecondRest {
    param(
        [Parameter(Mandatory = $true)]$EntryDate,
        [Parameter(Mandatory = $true)]$WorkedDateSet
    )

    foreach ($adjacentDate in @($EntryDate.AddDays(-1), $EntryDate.AddDays(1))) {
        $dateKey = $adjacentDate.ToString("yyyy-MM-dd", [System.Globalization.CultureInfo]::InvariantCulture)
        if (Test-Gc179WorkedDateCode -WorkedDateSet $WorkedDateSet -DateKey $dateKey -OvertimeCode "262") {
            return $true
        }
    }
    return $false
}

function Test-Gc179ExportableEntry {
    param(
        $Entry,
        [Parameter(Mandatory = $true)][string]$MonthKey
    )

    if ($null -eq $Entry) {
        return $false
    }

    $entryDate = [string]$Entry.date
    if ([string]::IsNullOrWhiteSpace($entryDate) -or -not $entryDate.StartsWith($MonthKey, [System.StringComparison]::Ordinal)) {
        return $false
    }

    $status = ([string]$Entry.status).Trim().ToLowerInvariant()
    if ([string]::IsNullOrWhiteSpace($status)) {
        $status = "pending"
    }
    if ($status -eq "rejected") {
        return $false
    }

    if ([string]::IsNullOrWhiteSpace([string]$Entry.punchIn) -or [string]::IsNullOrWhiteSpace([string]$Entry.punchOut)) {
        return $false
    }

    # A completed short entry can intentionally carry 00:00:00 so a
    # supervisor can see it in Review. It must not create an empty GC179 row.
    return (-not [string]::IsNullOrWhiteSpace((ConvertTo-Gc179DurationText -Entry $Entry)))
}

function Get-Gc179EntrySortKey {
    param($Entry)

    try {
        return [DateTime]::ParseExact(("{0} {1}" -f $Entry.date, $Entry.punchIn), "yyyy-MM-dd HH:mm:ss", [System.Globalization.CultureInfo]::InvariantCulture)
    }
    catch {
        try {
            return [DateTime]::ParseExact(("{0} {1}" -f $Entry.date, $Entry.punchIn), "yyyy-MM-dd HH:mm", [System.Globalization.CultureInfo]::InvariantCulture)
        }
        catch {
            return [DateTime]::MinValue
        }
    }
}

function Get-Gc179ExportEntries {
    param(
        [Parameter(Mandatory = $true)][string]$EmployeeCode,
        [Parameter(Mandatory = $true)][string]$MonthKey
    )

    $dataFile = Ensure-EmployeeDataFile -EmployeeCode $EmployeeCode
    $entries = @(Get-CachedEmployeeEntriesForFile -DataFile $dataFile)
    return @(
        $entries |
            Where-Object { Test-Gc179ExportableEntry -Entry $_ -MonthKey $MonthKey } |
            Sort-Object @{ Expression = { Get-Gc179EntrySortKey -Entry $_ } }
    )
}

function ConvertTo-Gc179ExportRows {
    param([AllowEmptyCollection()][object[]]$Entries)

    foreach ($entry in $Entries) {
        if (-not (Test-Gc179DiverseEntry -Entry $entry)) { $entry; continue }

        try {
            $start = [DateTime]::ParseExact(
                ("{0} {1}" -f $entry.date, (ConvertTo-Gc179TimeText -TimeText ([string]$entry.punchIn))),
                "yyyy-MM-dd HH:mm", [System.Globalization.CultureInfo]::InvariantCulture)
            $end = [DateTime]::ParseExact(
                ("{0} {1}" -f $entry.date, (ConvertTo-Gc179TimeText -TimeText ([string]$entry.punchOut))),
                "yyyy-MM-dd HH:mm", [System.Globalization.CultureInfo]::InvariantCulture)
        }
        catch { $entry; continue }

        # Split on the times the form will display, so rounding cannot leave
        # an empty second row. This does not change overnight handling.
        if (($end - $start).TotalHours -le 7.5) { $entry; continue }

        $boundary = $start.AddHours(7.5)
        $first = $entry.PSObject.Copy()
        $second = $entry.PSObject.Copy()
        $first.punchOut = $boundary.ToString("HH:mm:ss", [System.Globalization.CultureInfo]::InvariantCulture)
        $first | Add-Member -NotePropertyName overtime -NotePropertyValue "07:30:00" -Force
        $second.punchIn = $first.punchOut
        $second | Add-Member -NotePropertyName overtime -NotePropertyValue (($end - $boundary).ToString("hh\:mm\:ss", [System.Globalization.CultureInfo]::InvariantCulture)) -Force
        $first
        $second
    }
}

function Get-Gc179PreparedExportRows {
    param([AllowEmptyCollection()][object[]]$Entries, $HeaderValues, $WorkedDateSet)

    $creditedHours = @{}
    $previous = $null; $previousDouble = $false
    foreach ($entry in $Entries) {
        if ($entry.PSObject.Properties.Name -contains "_gc179DurationFields") { $entry; continue }
        # Approved history carries its own classification. A later promotion
        # must not switch old PA entries to IT rules (or the reverse).
        $classification = if ([string]$entry.compensationSnapshot.snapshotStatus -eq "final" -and
            -not [string]::IsNullOrWhiteSpace([string]$entry.compensationSnapshot.classification.group)) { $entry.compensationSnapshot.classification } else { $null }
        $Group = if ($classification) { [string]$classification.group } else { [string]$HeaderValues.Group }
        $subGroup = if ($classification) { [string]$classification.subGroup } else { [string]$HeaderValues.SubGroup }
        $level = if ($classification) { [string]$classification.level } else { [string]$HeaderValues.Level }
        $fields = @{}
        if (-not (Test-Gc179DiverseEntry -Entry $entry)) {
            $fields = Get-Gc179ExportDurationFields -Entry $entry
            $category = Get-Gc179EntryDurationCategory -OvertimeCode ([string]$entry.overtimeCode)
            $usageKey = "{0}|{1}" -f $entry.date, $category
            $used = if ($creditedHours.ContainsKey($usageKey)) { [double]$creditedHours[$usageKey] } else { 0.0 }
            $date = [DateTime]::MinValue
            $validDate = [DateTime]::TryParseExact([string]$entry.date, "yyyy-MM-dd", [System.Globalization.CultureInfo]::InvariantCulture, [System.Globalization.DateTimeStyles]::None, [ref]$date)
            if ($fields.Count -eq 0 -and $validDate) {
                $adjacentRest = $false
                if ($Group -eq "IT" -and $category -eq "holiday") {
                    foreach ($day in @($date.AddDays(-1), $date.AddDays(1))) {
                        $key = $day.ToString("yyyy-MM-dd", [System.Globalization.CultureInfo]::InvariantCulture)
                        if ((Test-Gc179WorkedDateCode $WorkedDateSet $key "261") -or (Test-Gc179WorkedDateCode $WorkedDateSet $key "262")) { $adjacentRest = $true }
                    }
                }
                $holidayNotScheduled = if ($entry.PSObject.Properties.Name -contains "holidayNotScheduledWorkday" -and $entry.holidayNotScheduledWorkday -is [bool]) { [bool]$entry.holidayNotScheduledWorkday } else { $null }
                $continueDouble = $Group -eq "IT" -and $previousDouble -and (Saphir.OvertimeCompensation\Test-SaphirOvertimeEntriesContinuous -PreviousEntry $previous -Entry $entry)
                $fields = Get-Gc179CalculatedDurationFields -Entry $entry `
                    -CompressedWorkWeek ((Get-Gc179EntryWorkSchedule -Entry $entry) -eq "compressed") `
                    -PreviouslyCreditedHours $used -Group $Group `
                    -HolidayAdjacentToSecondRest ($category -eq "holiday" -and (Test-Gc179HolidayAdjacentToSecondRest $date $WorkedDateSet)) `
                    -HolidayAdjacentToWorkedRest $adjacentRest -HolidayNotScheduledWorkday $holidayNotScheduled -ContinueAtDoubleTime $continueDouble
            }
            $hours = 0.0
            if ([double]::TryParse((ConvertTo-Gc179DurationText -Entry $entry), [System.Globalization.NumberStyles]::Float, [System.Globalization.CultureInfo]::InvariantCulture, [ref]$hours)) { $creditedHours[$usageKey] = $used + $hours }
        }
        $copy = $entry.PSObject.Copy()
        $copy | Add-Member -NotePropertyName _gc179DurationFields -NotePropertyValue $fields
        $copy | Add-Member -NotePropertyName _gc179ExportGroup -NotePropertyValue $Group
        $copy | Add-Member -NotePropertyName _gc179ExportSubGroup -NotePropertyValue $subGroup
        $copy | Add-Member -NotePropertyName _gc179ExportLevel -NotePropertyValue $level
        $copy
        $previous = $entry
        $previousDouble = @($fields.Keys | Where-Object { $_ -in @("RegTimeDouble", "FirstDayTimeDbl", "SubseqTimeDbl", "HolidayTimeDbl") -and [double]$fields[$_] -gt 0 }).Count -gt 0
    }
}

function New-Gc179FdfExportPart {
    param(
        [Parameter(Mandatory = $true)][string]$EmployeeCode,
        [Parameter(Mandatory = $true)]$MonthParts,
        [Parameter(Mandatory = $true)]$Entries,
        [Parameter(Mandatory = $true)]$WorkedDateSet,
        [int]$PartNumber = 1,
        [int]$PartCount = 1
    )

    $entries = @($Entries)
    foreach ($entry in $entries) { Assert-Gc179EntrySchedule -Entry $entry }
    $schedules = @($entries | ForEach-Object { Get-Gc179EntryWorkSchedule -Entry $_ } | Select-Object -Unique)
    if ($schedules.Count -gt 1) { throw "A GC179 form cannot combine regular and compressed schedules. Export separate parts." }
    $builder = New-Object System.Text.StringBuilder
    [void]$builder.AppendLine("%FDF-1.2")
    [void]$builder.AppendLine("1 0 obj")
    [void]$builder.AppendLine("<<")
    [void]$builder.AppendLine("/FDF <<")
    [void]$builder.AppendLine("/F $(ConvertTo-Gc179FdfStringToken -Value "GC179.pdf")")
    [void]$builder.AppendLine("/Fields [")

    $headerValues = Get-Gc179HeaderValues -EmployeeCode $EmployeeCode -MonthParts $MonthParts
    $entries = @(Get-Gc179PreparedExportRows -Entries $entries -HeaderValues $headerValues -WorkedDateSet $WorkedDateSet)
    $classes = @($entries | Group-Object _gc179ExportGroup, _gc179ExportSubGroup, _gc179ExportLevel)
    if ($classes.Count -gt 1) { throw "A GC179 form cannot combine classifications. Export separate parts." }
    if ($entries.Count -gt 0) {
        $headerValues.Group = $entries[0]._gc179ExportGroup
        $headerValues.SubGroup = $entries[0]._gc179ExportSubGroup
        $headerValues.Level = $entries[0]._gc179ExportLevel
    }
    if ($schedules.Count -eq 1) {
        $headerValues.WorkWeek = switch ($schedules[0]) {
            "regular" { "1" }
            "compressed" { "2" }
            default { "Off" }
        }
    }
    Add-Gc179FdfTextField -Builder $builder -Name "Month" -Value ([string]$headerValues.Month)
    Add-Gc179FdfTextField -Builder $builder -Name "Year" -Value ([string]$headerValues.Year)
    Add-Gc179FdfTextField -Builder $builder -Name "Department" -Value ([string]$headerValues.Department)
    Add-Gc179FdfTextField -Builder $builder -Name "Branch" -Value ([string]$headerValues.Branch)
    Add-Gc179FdfTextField -Builder $builder -Name "Paylist" -Value ([string]$headerValues.Paylist)
    Add-Gc179FdfTextField -Builder $builder -Name "Group" -Value ([string]$headerValues.Group)
    Add-Gc179FdfTextField -Builder $builder -Name "SubGroup" -Value ([string]$headerValues.SubGroup)
    Add-Gc179FdfTextField -Builder $builder -Name "Surname" -Value ([string]$headerValues.Surname)
    Add-Gc179FdfTextField -Builder $builder -Name "Given" -Value ([string]$headerValues.Given)
    Add-Gc179FdfTextField -Builder $builder -Name "Initials" -Value ([string]$headerValues.Initials)
    Add-Gc179FdfTextField -Builder $builder -Name "PRI" -Value ([string]$headerValues.PRI)
    Add-Gc179FdfTextField -Builder $builder -Name "Level" -Value ([string]$headerValues.Level)
    Add-Gc179FdfNameField -Builder $builder -Name "WorkWeek" -ValueName ([string]$headerValues.WorkWeek)

    for ($index = 0; $index -lt 16; $index++) {
        if ($index -lt $entries.Count) {
            $entry = $entries[$index]
            try {
                $entryDate = [DateTime]::ParseExact([string]$entry.date, "yyyy-MM-dd", [System.Globalization.CultureInfo]::InvariantCulture)
            }
            catch {
                $entryDate = $null
            }

            if ($null -ne $entryDate) {
                $isDiverse = Test-Gc179DiverseEntry -Entry $entry
                $reasonCode = if ($isDiverse) { "D" } else { [string]$entry.reasonCode }
                $overtimeCode = if ($isDiverse) { "260" } else { [string]$entry.overtimeCode }
                $paymentOption = if ($isDiverse) { "cash" } else { [string]$entry.paymentOption }
                Add-Gc179FdfTextField -Builder $builder -Name ("DayofWeek.{0}" -f $index) -Value (ConvertTo-Gc179DayText -Date $entryDate)
                Add-Gc179FdfTextField -Builder $builder -Name ("OTCODE.{0}" -f $index) -Value $reasonCode
                Add-Gc179FdfTextField -Builder $builder -Name ("DayWorked.{0}" -f $index) -Value (ConvertTo-Gc179WeekdayText -Date $entryDate)
                Add-Gc179FdfTextField -Builder $builder -Name ("StartTime.{0}" -f $index) -Value (ConvertTo-Gc179TimeText -TimeText ([string]$entry.punchIn))
                Add-Gc179FdfTextField -Builder $builder -Name ("EndTime.{0}" -f $index) -Value (ConvertTo-Gc179TimeText -TimeText ([string]$entry.punchOut))
                Add-Gc179FdfTextField -Builder $builder -Name ("OvertimeCode.{0}" -f $index) -Value $overtimeCode

                if ($isDiverse) {
                    # Export-only defaults: never rewrite the source entry or
                    # let diverse time consume an overtime rate threshold.
                    Add-Gc179DurationFields -Builder $builder -RowIndex $index -DurationFields @{}
                    Add-Gc179FdfNameField -Builder $builder -Name (Get-Gc179PaymentFieldName -RowIndex $index) -ValueName (Get-Gc179PaymentValueName -PaymentOption $paymentOption)
                    continue
                }

                Add-Gc179DurationFields -Builder $builder -RowIndex $index -DurationFields $entry._gc179DurationFields
                Add-Gc179FdfNameField -Builder $builder -Name (Get-Gc179PaymentFieldName -RowIndex $index) -ValueName (Get-Gc179PaymentValueName -PaymentOption $paymentOption)
                continue
            }
        }

        Add-Gc179FdfTextField -Builder $builder -Name ("DayofWeek.{0}" -f $index) -Value ""
        Add-Gc179FdfTextField -Builder $builder -Name ("OTCODE.{0}" -f $index) -Value ""
        Add-Gc179FdfTextField -Builder $builder -Name ("DayWorked.{0}" -f $index) -Value ""
        Add-Gc179FdfTextField -Builder $builder -Name ("StartTime.{0}" -f $index) -Value ""
        Add-Gc179FdfTextField -Builder $builder -Name ("EndTime.{0}" -f $index) -Value ""
        Add-Gc179FdfTextField -Builder $builder -Name ("OvertimeCode.{0}" -f $index) -Value ""
        Add-Gc179DurationFields -Builder $builder -RowIndex $index -DurationFields @{}
        Add-Gc179FdfNameField -Builder $builder -Name (Get-Gc179PaymentFieldName -RowIndex $index) -ValueName "Off"
    }

    [void]$builder.AppendLine("]")
    [void]$builder.AppendLine(">>")
    [void]$builder.AppendLine(">>")
    [void]$builder.AppendLine("endobj")
    [void]$builder.AppendLine("trailer")
    [void]$builder.AppendLine("<< /Root 1 0 R >>")
    [void]$builder.AppendLine("%%EOF")

    $includesTimePayment = @(
        $entries | Where-Object {
            -not (Test-Gc179DiverseEntry -Entry $_) -and
            (Get-Gc179PaymentValueName -PaymentOption ([string]$_.paymentOption)) -eq "2"
        }
    ).Count -gt 0
    $baseFileName = Get-Gc179ExportBaseFileName -EmployeeCode $EmployeeCode -HeaderValues $headerValues -MonthParts $MonthParts -PartNumber $PartNumber -PartCount $PartCount -IncludesTimePayment $includesTimePayment
    $fileName = "{0}.fdf" -f $baseFileName

    return [PSCustomObject]@{
        Content    = $builder.ToString()
        FileName   = $fileName
        BaseName   = $baseFileName
        RowCount   = $entries.Count
        PartNumber = $PartNumber
        PartCount  = $PartCount
        WorkSchedule = if ($schedules.Count -eq 1) { [string]$schedules[0] } else { "" }
    }
}

function New-Gc179FdfExportSet {
    param(
        [Parameter(Mandatory = $true)][string]$EmployeeCode,
        [Parameter(Mandatory = $true)][string]$MonthKey
    )

    $monthParts = ConvertTo-Gc179MonthParts -MonthKey $MonthKey
    $entries = @(Get-Gc179ExportEntries -EmployeeCode $EmployeeCode -MonthKey $monthParts.MonthKey)
    # Expand before pagination so a second diverse row can never disappear
    # at the form's 16-row boundary. Keep Entries as the original source count.
    $exportRows = @(ConvertTo-Gc179ExportRows -Entries $entries)
    $workedDateSet = Get-Gc179WorkedDateSet -EmployeeCode $EmployeeCode
    $header = Get-Gc179HeaderValues -EmployeeCode $EmployeeCode -MonthParts $monthParts
    $exportRows = @(Get-Gc179PreparedExportRows -Entries $exportRows -HeaderValues $header -WorkedDateSet $workedDateSet)
    # WorkWeek is a form-level choice: never let today's profile overwrite an
    # entry's historical schedule, and never mix schedules on a single form.
    $chunks = New-Object System.Collections.ArrayList
    foreach ($schedule in @("regular", "compressed", "unconfirmed")) {
        $scheduleEntries = @($exportRows | Where-Object { (Get-Gc179EntryWorkSchedule -Entry $_) -eq $schedule })
        foreach ($entry in $scheduleEntries) { Assert-Gc179EntrySchedule -Entry $entry }
        foreach ($classGroup in @($scheduleEntries | Group-Object _gc179ExportGroup, _gc179ExportSubGroup, _gc179ExportLevel)) {
            $classEntries = @($classGroup.Group)
            for ($startIndex = 0; $startIndex -lt $classEntries.Count; $startIndex += 16) {
                $endIndex = [math]::Min($startIndex + 15, $classEntries.Count - 1)
                [void]$chunks.Add(@($classEntries[$startIndex..$endIndex]))
            }
        }
    }
    if ($chunks.Count -eq 0) { [void]$chunks.Add(@()) }
    $partCount = $chunks.Count
    $exports = New-Object System.Collections.ArrayList
    for ($partIndex = 0; $partIndex -lt $partCount; $partIndex++) {
        $partExport = New-Gc179FdfExportPart -EmployeeCode $EmployeeCode -MonthParts $monthParts -Entries @($chunks[$partIndex]) -WorkedDateSet $workedDateSet -PartNumber ($partIndex + 1) -PartCount $partCount
        [void]$exports.Add($partExport)
    }

    return [PSCustomObject]@{
        MonthParts = $monthParts
        Entries    = @($entries)
        Exports    = @($exports.ToArray())
    }
}

function ConvertTo-Gc179Utf8BomBytes {
    param([Parameter(Mandatory = $true)][string]$Text)

    $encoding = New-Object System.Text.UTF8Encoding -ArgumentList $true
    $preamble = $encoding.GetPreamble()
    $contentBytes = $encoding.GetBytes($Text)
    $bytes = New-Object byte[] ($preamble.Length + $contentBytes.Length)
    [System.Array]::Copy($preamble, 0, $bytes, 0, $preamble.Length)
    [System.Array]::Copy($contentBytes, 0, $bytes, $preamble.Length, $contentBytes.Length)
    return $bytes
}

function Get-Gc179TemplatePdfPath {
    $templatePath = Join-Path -Path $repoRoot -ChildPath "docs/GC179.pdf"
    if (-not (Test-Path -Path $templatePath -PathType Leaf)) {
        throw "GC179 template not found at docs/GC179.pdf."
    }

    return $templatePath
}

function New-Gc179OpenFdfScript {
    return @'
$ErrorActionPreference = "Stop"

function ConvertTo-Gc179FdfLiteral {
    param([AllowNull()][string]$Value)

    $text = if ($null -eq $Value) { "" } else { [string]$Value }
    $text = $text.Replace("\", "\\")
    $text = $text.Replace("(", "\(")
    $text = $text.Replace(")", "\)")
    $text = $text.Replace("`r`n", "\r")
    $text = $text.Replace("`r", "\r")
    $text = $text.Replace("`n", "\r")
    return $text
}

function ConvertTo-Gc179FdfStringToken {
    param([AllowNull()][string]$Value)

    $text = if ($null -eq $Value) { "" } else { [string]$Value }
    if ($text -notmatch "[^\x00-\x7F]") {
        return "($(ConvertTo-Gc179FdfLiteral -Value $text))"
    }

    $bytes = [System.Text.Encoding]::BigEndianUnicode.GetBytes($text)
    $hex = "FEFF" + ([System.BitConverter]::ToString($bytes)).Replace("-", "")
    return "<$hex>"
}

function Get-Gc179FullPath {
    param([Parameter(Mandatory = $true)][string]$Path)

    return [System.IO.Path]::GetFullPath($Path)
}

function New-Gc179LaunchFdf {
    param(
        [Parameter(Mandatory = $true)]$FdfFile,
        [Parameter(Mandatory = $true)][string]$TemplatePath,
        [Parameter(Mandatory = $true)][string]$OutputDirectory
    )

    $baseName = [System.IO.Path]::GetFileNameWithoutExtension([string]$FdfFile.Name)
    $launchFdfPath = Join-Path -Path $OutputDirectory -ChildPath ("{0}-ouvrir.fdf" -f $baseName)
    $fdfText = [System.IO.File]::ReadAllText([string]$FdfFile.FullName, [System.Text.Encoding]::ASCII)
    $templateDirectory = Split-Path -Path $TemplatePath -Parent
    $partTemplatePath = Join-Path -Path $templateDirectory -ChildPath ("{0}.pdf" -f $baseName)
    $effectiveTemplatePath = if (Test-Path -Path $partTemplatePath -PathType Leaf) {
        $partTemplatePath
    }
    else {
        $TemplatePath
    }
    $templateToken = ConvertTo-Gc179FdfStringToken -Value (Get-Gc179FullPath -Path $effectiveTemplatePath)
    $fieldReference = "/F $templateToken"

    if ($fdfText -match "/F\s*(?:\((?:\\.|[^)])*\)|<[0-9A-Fa-f\s]+>)") {
        $safeReplacement = $fieldReference.Replace('$', '$$')
        $fdfText = [System.Text.RegularExpressions.Regex]::Replace($fdfText, "/F\s*(?:\((?:\\.|[^)])*\)|<[0-9A-Fa-f\s]+>)", $safeReplacement, 1)
    }
    else {
        $fdfText = $fdfText -replace "/FDF\s*<<", ("/FDF <<" + [Environment]::NewLine + $fieldReference)
    }

    [System.IO.File]::WriteAllText($launchFdfPath, $fdfText, [System.Text.Encoding]::ASCII)
    return $launchFdfPath
}

function Start-Gc179File {
    param([Parameter(Mandatory = $true)][string]$Path)

    if ([System.Environment]::OSVersion.Platform -eq [System.PlatformID]::Win32NT) {
        Start-Process -FilePath $Path | Out-Null
        return
    }

    $openCommand = Get-Command -Name "open" -ErrorAction SilentlyContinue
    if ($null -ne $openCommand) {
        & $openCommand.Source $Path | Out-Null
        return
    }

    Start-Process -FilePath $Path | Out-Null
}

$root = Split-Path -Path $MyInvocation.MyCommand.Path -Parent
$templatePath = Join-Path -Path $root -ChildPath "GC179.pdf"
$outputDirectory = Join-Path -Path $root -ChildPath "FDF-ouverture"

if (-not (Test-Path -Path $templatePath -PathType Leaf)) {
    throw "GC179.pdf is missing from the local export folder."
}

if (-not (Test-Path -Path $outputDirectory -PathType Container)) {
    New-Item -ItemType Directory -Path $outputDirectory -Force | Out-Null
}

$fdfFiles = @(
    Get-ChildItem -Path $root -Filter "*.fdf" -ErrorAction SilentlyContinue |
        Where-Object { -not $_.PSIsContainer -and $_.Name -notlike "*-ouvrir.fdf" } |
        Sort-Object Name
)

if ($fdfFiles.Count -lt 1) {
    throw "No GC179 FDF file was found in the local export folder."
}

foreach ($fdfFile in $fdfFiles) {
    $launchFdfPath = New-Gc179LaunchFdf -FdfFile $fdfFile -TemplatePath $templatePath -OutputDirectory $outputDirectory
    Start-Gc179File -Path $launchFdfPath
    Start-Sleep -Milliseconds 1400
}
'@
}

function Get-Gc179LocalExportRoot {
    $appConfig = Get-Variable -Name config -ValueOnly -ErrorAction SilentlyContinue
    $configuredPath = if ($appConfig) { [string]$appConfig.Gc179LocalExportPath } else { "" }
    if (-not [string]::IsNullOrWhiteSpace($configuredPath)) {
        if ([System.IO.Path]::IsPathRooted($configuredPath)) {
            return [System.IO.Path]::GetFullPath($configuredPath)
        }
        return [System.IO.Path]::GetFullPath((Join-Path $backendRoot $configuredPath))
    }
    if ([System.Environment]::OSVersion.Platform -eq [System.PlatformID]::Win32NT) {
        $basePath = [string]$env:LOCALAPPDATA
        if ([string]::IsNullOrWhiteSpace($basePath)) {
            $basePath = Join-Path -Path ([System.Environment]::GetFolderPath("LocalApplicationData")) -ChildPath "SAPHIR"
        }
        else {
            $basePath = Join-Path -Path $basePath -ChildPath "SAPHIR"
        }

        return (Join-Path -Path $basePath -ChildPath "GC179")
    }

    if (-not [string]::IsNullOrWhiteSpace([string]$env:HOME)) {
        $basePath = Join-Path -Path ([string]$env:HOME) -ChildPath "Library/Application Support/SAPHIR"
        return (Join-Path -Path $basePath -ChildPath "GC179")
    }

    $fallbackBasePath = Join-Path -Path ([System.IO.Path]::GetTempPath()) -ChildPath "SAPHIR"
    return (Join-Path -Path $fallbackBasePath -ChildPath "GC179")
}

function Remove-OldGc179LocalExportFolders {
    param(
        [Parameter(Mandatory = $true)][string]$RootPath,
        [int]$RetentionDays = 14
    )

    if (-not (Test-Path -Path $RootPath -PathType Container)) {
        return
    }

    $cutoff = (Get-Date).AddDays(-1 * [math]::Max(1, $RetentionDays))
    Get-ChildItem -Path $RootPath -Directory -ErrorAction SilentlyContinue |
        Where-Object { $_.LastWriteTime -lt $cutoff } |
        ForEach-Object {
            try {
                Remove-Item -LiteralPath $_.FullName -Recurse -Force -ErrorAction Stop
            }
            catch {
            }
        }
}

function New-Gc179LocalExportFolder {
    param(
        [Parameter(Mandatory = $true)][string]$EmployeeCode,
        [Parameter(Mandatory = $true)][string]$MonthKey
    )

    $safeEmployeeCode = ([string]$EmployeeCode) -replace "[^0-9A-Za-z_-]", "_"
    $safeMonthKey = ([string]$MonthKey) -replace "[^0-9A-Za-z_-]", "_"
    $folderName = "gc179-{0}-{1}-{2}" -f $safeEmployeeCode, $safeMonthKey, (Get-Date).ToString("yyyyMMdd-HHmmss")
    $rootPath = Get-Gc179LocalExportRoot
    if (-not (Test-Path -Path $rootPath -PathType Container)) {
        New-Item -ItemType Directory -Path $rootPath -Force | Out-Null
    }
    Remove-OldGc179LocalExportFolders -RootPath $rootPath

    $folderPath = Join-Path -Path $rootPath -ChildPath $folderName
    New-Item -ItemType Directory -Path $folderPath -Force | Out-Null
    return $folderPath
}

function Write-Gc179LocalExportWorkspace {
    param(
        [Parameter(Mandatory = $true)][string]$FolderPath,
        [Parameter(Mandatory = $true)]$ExportSet
    )

    $templateBytes = [System.IO.File]::ReadAllBytes((Get-Gc179TemplatePdfPath))
    [System.IO.File]::WriteAllBytes((Join-Path -Path $FolderPath -ChildPath "GC179.pdf"), $templateBytes)
    [System.IO.File]::WriteAllBytes((Join-Path -Path $FolderPath -ChildPath "GENERER-GC179.ps1"), (ConvertTo-Gc179Utf8BomBytes -Text (New-Gc179OpenFdfScript)))

    foreach ($export in @($ExportSet.Exports)) {
        $fdfPath = Join-Path -Path $FolderPath -ChildPath ([string]$export.FileName)
        $pdfBaseName = [System.IO.Path]::GetFileNameWithoutExtension([string]$export.FileName)
        $pdfPath = Join-Path -Path $FolderPath -ChildPath ("{0}.pdf" -f $pdfBaseName)
        [System.IO.File]::WriteAllText($fdfPath, [string]$export.Content, [System.Text.Encoding]::ASCII)
        [System.IO.File]::WriteAllBytes($pdfPath, $templateBytes)
    }
}

function Get-Gc179PowerShellExecutable {
    if ([System.Environment]::OSVersion.Platform -eq [System.PlatformID]::Win32NT) {
        $systemRoot = [string]$env:SystemRoot
        if ([string]::IsNullOrWhiteSpace($systemRoot)) {
            $systemRoot = "C:\Windows"
        }

        $candidate = Join-Path -Path $systemRoot -ChildPath "System32\WindowsPowerShell\v1.0\powershell.exe"
        if (Test-Path -Path $candidate -PathType Leaf) {
            return $candidate
        }

        return "powershell.exe"
    }

    $pwsh = Get-Command -Name "pwsh" -ErrorAction SilentlyContinue
    if ($null -ne $pwsh) {
        return [string]$pwsh.Source
    }

    $powershell = Get-Command -Name "powershell" -ErrorAction SilentlyContinue
    if ($null -ne $powershell) {
        return [string]$powershell.Source
    }

    return "pwsh"
}

function Start-Gc179LocalExportWorkspace {
    param([Parameter(Mandatory = $true)][string]$FolderPath)

    $scriptPath = Join-Path -Path $FolderPath -ChildPath "GENERER-GC179.ps1"
    $stdoutPath = Join-Path -Path $FolderPath -ChildPath "gc179-launch.log"
    $stderrPath = Join-Path -Path $FolderPath -ChildPath "gc179-launch-error.log"
    $powershellPath = Get-Gc179PowerShellExecutable
    $quotedScriptPath = '"' + ([string]$scriptPath).Replace('"', '\"') + '"'
    $argumentList = if ([System.Environment]::OSVersion.Platform -eq [System.PlatformID]::Win32NT) {
        "-NoProfile -ExecutionPolicy RemoteSigned -File $quotedScriptPath"
    }
    else {
        "-NoProfile -File $quotedScriptPath"
    }

    $process = $null
    if ([System.Environment]::OSVersion.Platform -eq [System.PlatformID]::Win32NT) {
        try {
            $process = Start-Process -FilePath $powershellPath -ArgumentList $argumentList -WorkingDirectory $FolderPath -WindowStyle Hidden -RedirectStandardOutput $stdoutPath -RedirectStandardError $stderrPath -PassThru -ErrorAction Stop
        }
        catch {
            $process = Start-Process -FilePath $powershellPath -ArgumentList $argumentList -WorkingDirectory $FolderPath -PassThru -ErrorAction Stop
        }
    }
    else {
        $process = Start-Process -FilePath $powershellPath -ArgumentList $argumentList -WorkingDirectory $FolderPath -RedirectStandardOutput $stdoutPath -RedirectStandardError $stderrPath -PassThru -ErrorAction Stop
    }

    $processId = if ($null -ne $process) { [int]$process.Id } else { 0 }
    return [PSCustomObject]@{
        ProcessId    = $processId
        LogPath      = $stdoutPath
        ErrorLogPath = $stderrPath
    }
}

function Start-Gc179LocalExport {
    param(
        [Parameter(Mandatory = $true)][string]$EmployeeCode,
        [Parameter(Mandatory = $true)][string]$MonthKey
    )

    $exportSet = New-Gc179FdfExportSet -EmployeeCode $EmployeeCode -MonthKey $MonthKey
    $folderPath = New-Gc179LocalExportFolder -EmployeeCode $EmployeeCode -MonthKey ([string]$exportSet.MonthParts.MonthKey)
    Write-Gc179LocalExportWorkspace -FolderPath $folderPath -ExportSet $exportSet

    # From here on the files have been saved. An opening failure must not
    # hide them or imply that the employee has to generate a new copy.
    $launch = $null
    try {
        $launch = Start-Gc179LocalExportWorkspace -FolderPath $folderPath
    }
    catch {
        Write-Warning "GC179 export saved but the local opening process could not be started."
    }
    $openingRequested = ($null -ne $launch -and $launch.ProcessId -gt 0)
    $pendingCount = 0
    foreach ($entry in $exportSet.Entries) {
        $status = ([string]$entry.status).Trim()
        if ($status -eq "" -or $status -eq "pending") { $pendingCount++ }
    }
    $rowCount = 0
    foreach ($part in $exportSet.Exports) { $rowCount += $part.RowCount }

    return [PSCustomObject]@{
        prepared     = $true
        launched     = $openingRequested
        monthKey     = [string]$exportSet.MonthParts.MonthKey
        folderPath   = $folderPath
        logPath      = if ($null -ne $launch) { [string]$launch.LogPath } else { "" }
        errorLogPath = if ($null -ne $launch) { [string]$launch.ErrorLogPath } else { "" }
        processId    = if ($null -ne $launch) { [int]$launch.ProcessId } else { 0 }
        entryCount   = @($exportSet.Entries).Count
        pendingCount = $pendingCount
        rowCount     = $rowCount
        partCount    = @($exportSet.Exports).Count
        message      = if ($openingRequested) { "GC179 export prepared; local opening requested." } else { "GC179 export prepared; local opening could not be started." }
    }
}
