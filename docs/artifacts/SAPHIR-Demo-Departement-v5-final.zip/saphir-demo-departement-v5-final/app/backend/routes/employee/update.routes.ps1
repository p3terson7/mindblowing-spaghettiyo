        # PUT /employee/{employeeCode}: Update overtime entry.
        if ($request.HttpMethod -eq "PUT" -and $request.Url.AbsolutePath -match "^/employee/(\d+)$") {
            $employeeCode = $matches[1]
            $dataFile = Join-Path -Path $sharedFolder -ChildPath "${employeeCode}_data.json"

            if (Test-CurrentUserMatchesEmployeeCode -CurrentUser $currentUser -EmployeeCode $employeeCode) {
                respondWithError $response 403 "Administrators cannot update entries in their own employee profile."
                continue
            }

            if (-not (Test-SaphirFileExists -Path $dataFile)) {
                respondWithError $response 404 "Employee not found"
                continue
            }

            $payload = Read-JsonRequestBody -Request $request
            $entryId = if ($null -ne $payload -and ($payload.PSObject.Properties.Name -contains "entryId")) { [string]$payload.entryId } else { "" }
            $date = if ($null -ne $payload) { [string]$payload.date } else { "" }
            $newDateProvided = ($null -ne $payload -and ($payload.PSObject.Properties.Name -contains "newDate"))
            $newDate = if ($newDateProvided) { [string]$payload.newDate } else { "" }
            $originalPunchIn = if ($null -ne $payload -and ($payload.PSObject.Properties.Name -contains "originalPunchIn")) { [string]$payload.originalPunchIn } else { "" }
            $managerMessage = if ($null -ne $payload -and ($payload.PSObject.Properties.Name -contains "message")) { [string]$payload.message } else { "" }
            $replaceManagerMessage = $null -ne $payload -and ($payload.messageChanged -isnot [bool] -or $payload.messageChanged)
            $statusProvided = ($null -ne $payload -and ($payload.PSObject.Properties.Name -contains "status"))
            $requestedStatus = ""
            $payloadEntryType = if ($null -ne $payload -and ($payload.PSObject.Properties.Name -contains "entryType")) { ([string]$payload.entryType).Trim().ToLowerInvariant() } else { "" }
            $workCommentProvided = ($null -ne $payload -and ($payload.PSObject.Properties.Name -contains "workComment"))
            $payloadWorkComment = if ($workCommentProvided) { ([string]$payload.workComment).Trim() } else { "" }
            $diverseSummaryProvided = ($null -ne $payload -and ($payload.PSObject.Properties.Name -contains "diverseSummary"))
            $payloadDiverseSummary = if ($diverseSummaryProvided) { ([string]$payload.diverseSummary).Trim() } else { "" }
            $workScheduleProvided = ($null -ne $payload -and ($payload.PSObject.Properties.Name -contains "workSchedule"))
            $requestedWorkSchedule = if ($workScheduleProvided) { ([string]$payload.workSchedule).Trim().ToLowerInvariant() } else { "" }
            $holidayScheduleProvided = ($null -ne $payload -and $payload.PSObject.Properties.Name -contains "holidayNotScheduledWorkday")
            if ($holidayScheduleProvided -and $null -ne $payload.holidayNotScheduledWorkday -and $payload.holidayNotScheduledWorkday -isnot [bool]) {
                respondWithError $response 400 "holidayNotScheduledWorkday must be true, false or null."
                continue
            }

            if ([string]::IsNullOrWhiteSpace($date) -or ([string]::IsNullOrWhiteSpace($entryId) -and [string]::IsNullOrWhiteSpace($originalPunchIn))) {
                respondWithError $response 400 "Missing required identifier: date and entryId/originalPunchIn are required."
                continue
            }

            $normalizedDate = Convert-ToNormalizedDateText -DateText $date
            if ([string]::IsNullOrWhiteSpace($normalizedDate)) {
                respondWithError $response 400 "Date must use the yyyy-MM-dd format."
                continue
            }
            $date = $normalizedDate

            if ($newDateProvided) {
                $normalizedNewDate = Convert-ToNormalizedDateText -DateText $newDate
                if ([string]::IsNullOrWhiteSpace($normalizedNewDate)) {
                    respondWithError $response 400 "If provided, newDate must use the yyyy-MM-dd format."
                    continue
                }
                $newDate = $normalizedNewDate
            }

            if ([string]::IsNullOrWhiteSpace($managerMessage)) {
                respondWithError $response 400 "A manager message is required when updating an entry."
                continue
            }
            if ($managerMessage.Trim().Length -gt 1000) {
                respondWithError $response 400 "Supervisor notes cannot exceed 1000 characters."
                continue
            }

            if ($statusProvided) {
                $requestedStatus = ([string]$payload.status).Trim().ToLowerInvariant()
                if (@("approved", "rejected", "pending") -notcontains $requestedStatus) {
                    respondWithError $response 400 "If provided, status must be approved, rejected, or pending."
                    continue
                }
            }

            if (-not [string]::IsNullOrWhiteSpace($payloadEntryType) -and @("overtime", "diverse") -notcontains $payloadEntryType) {
                respondWithError $response 400 "If provided, entryType must be overtime or diverse."
                continue
            }

            if ($workScheduleProvided -and @("regular", "compressed") -notcontains $requestedWorkSchedule) {
                respondWithError $response 400 "If provided, workSchedule must be regular or compressed."
                continue
            }

            if ($payloadEntryType -ne "diverse" -and $payload.PSObject.Properties.Name -contains "projectCode") {
                if (-not $payload.projectCode) {
                    respondWithError $response 400 "If provided, projectCode cannot be empty."
                    continue
                }
                $projects = Get-ActiveProjects
                $projectExists = $projects | Where-Object { $_.projectCode -eq $payload.projectCode }
                if (-not $projectExists) {
                    respondWithError $response 400 "Invalid projectCode: $($payload.projectCode) does not exist."
                    continue
                }

                if (-not (Test-CurrentUserCanModifyProjectCode -CurrentUser $currentUser -ProjectCode ([string]$payload.projectCode)) ) {
                    respondWithError $response 403 "You can view project $($payload.projectCode), but only assigned project admins can modify entries for it."
                    continue
                }
            }

            if ($payloadEntryType -ne "diverse" -and $payload.PSObject.Properties.Name -contains "overtimeCode") {
                $overtimeCodes = Get-OvertimeCodes
                if (-not (Test-OptionCode -Options $overtimeCodes -Code ([string]$payload.overtimeCode) -AllowBlank $true)) {
                    respondWithError $response 400 "Invalid overtimeCode: $($payload.overtimeCode) does not exist."
                    continue
                }
            }

            if ($payloadEntryType -ne "diverse" -and $payload.PSObject.Properties.Name -contains "paymentOption") {
                if (-not $payload.paymentOption) {
                    respondWithError $response 400 "If provided, paymentOption cannot be empty."
                    continue
                }
                $paymentOptions = Get-PaymentOptions
                if (-not (Test-OptionCode -Options $paymentOptions -Code ([string]$payload.paymentOption) -AllowBlank $false)) {
                    respondWithError $response 400 "Invalid paymentOption: $($payload.paymentOption) does not exist."
                    continue
                }
            }

            if ($payloadEntryType -ne "diverse" -and $payload.PSObject.Properties.Name -contains "reasonCode") {
                $reasonCodes = Get-ReasonCodes
                if (-not (Test-OptionCode -Options $reasonCodes -Code ([string]$payload.reasonCode) -AllowBlank $true)) {
                    respondWithError $response 400 "Invalid reasonCode: $($payload.reasonCode) does not exist."
                    continue
                }
            }

            $entryMutationCommitted = $false
            $entryMutationError = $null
            $postCommitWarnings = New-Object System.Collections.ArrayList
            $lockHandle = $null
            $projectReferenceLockHandle = $null
            try {
                if ($payloadEntryType -ne "diverse" -and $payload.PSObject.Properties.Name -contains "projectCode") {
                    $projectReferenceLockHandle = Acquire-ProjectReferenceLock
                    if (-not (Test-ActiveProjectCodeFromDisk -ProjectCode ([string]$payload.projectCode))) {
                        respondWithError $response 409 "The selected project is no longer active. Refresh and choose another project."
                        continue
                    }
                    if (-not (Test-CurrentUserCanModifyActiveProjectCodeFromDisk -CurrentUser $currentUser -ProjectCode ([string]$payload.projectCode))) {
                        respondWithError $response 403 "Your permission for the selected project changed. Refresh and try again."
                        continue
                    }
                }

                $lockHandle = Acquire-ResourceLock -ResourcePath $dataFile
                try {
                    $existingData = @(Read-JsonArrayFile -Path $dataFile)
                $foundIndex = Find-EntryIndex -Entries $existingData -EntryId $entryId -Date $date -PunchIn $originalPunchIn
                if ($foundIndex -eq -1) {
                    respondWithError $response 404 "Entry not found"
                    continue
                }

                $existingEntry = $existingData[$foundIndex]
                if (-not (Get-EntryIdentifierValue -Entry $existingEntry)) {
                    $existingEntry | Add-Member -NotePropertyName entryId -NotePropertyValue (New-EntryIdentifier) -Force
                }

                if (-not (Test-CurrentUserCanManageEntry -CurrentUser $currentUser -Entry $existingEntry)) {
                    respondWithError $response 403 "You do not have access to this entry's project."
                    continue
                }

                $originalRoundedPunchIn = [string]$existingEntry.punchIn
                $originalRoundedPunchOut = if ($existingEntry.punchOut) { [string]$existingEntry.punchOut } else { $null }
                $originalEntryDate = Convert-ToNormalizedDateText -DateText ([string]$existingEntry.date)
                if ([string]::IsNullOrWhiteSpace($originalEntryDate)) {
                    respondWithError $response 409 "The stored entry date is invalid. Correct the data before editing this entry."
                    continue
                }
                $updatedEntryDate = if ($newDateProvided) { $newDate } else { $originalEntryDate }
                $originalProjectCode = if ($existingEntry.projectCode) { [string]$existingEntry.projectCode } else { "" }
                $originalOvertimeCode = if ($existingEntry.overtimeCode) { [string]$existingEntry.overtimeCode } else { "" }
                $originalPaymentOption = if ($existingEntry.paymentOption) { [string]$existingEntry.paymentOption } else { "cash" }
                $originalReasonCode = if ($existingEntry.reasonCode) { [string]$existingEntry.reasonCode } else { "" }
                $originalWorkComment = if ($existingEntry.PSObject.Properties.Name -contains "workComment") { ([string]$existingEntry.workComment).Trim() } else { "" }
                $originalStatus = if ($existingEntry.status) { ([string]$existingEntry.status).ToLowerInvariant() } else { "pending" }
                $existingEntryType = if ($existingEntry.PSObject.Properties.Name -contains "entryType" -and -not [string]::IsNullOrWhiteSpace([string]$existingEntry.entryType)) { ([string]$existingEntry.entryType).Trim().ToLowerInvariant() } else { "overtime" }
                $originalWorkSchedule = if ($existingEntry.PSObject.Properties.Name -contains "workSchedule" -and ([string]$existingEntry.workSchedule).Trim().ToLowerInvariant() -in @("regular", "compressed")) { ([string]$existingEntry.workSchedule).Trim().ToLowerInvariant() } else { "unconfirmed" }
                $originalDiverseReason = if ($existingEntry.PSObject.Properties.Name -contains "diverseReason") { [string]$existingEntry.diverseReason } else { "" }
                $originalDiverseSummary = if ($existingEntry.PSObject.Properties.Name -contains "diverseSummary") { ([string]$existingEntry.diverseSummary).Trim() } else { "" }

                if (-not [string]::IsNullOrWhiteSpace($payloadEntryType) -and $payloadEntryType -ne $existingEntryType) {
                    respondWithError $response 400 "Entry type cannot be changed after creation."
                    continue
                }

                if ($existingEntryType -eq "diverse" -and $payload.PSObject.Properties.Name -contains "diverseReason" -and [string]::IsNullOrWhiteSpace([string]$payload.diverseReason)) {
                    respondWithError $response 400 "Diverse entries require a reason."
                    continue
                }

                # Old clients may echo the original text, but neither manager
                # role can replace or clear employee-authored text.
                if (($workCommentProvided -and $payloadWorkComment -cne $originalWorkComment) -or
                    ($diverseSummaryProvided -and $payloadDiverseSummary -cne $originalDiverseSummary) -or
                    ($payload.PSObject.Properties.Name -contains "employeeCommentAdditions")) {
                    respondWithError $response 403 "Employee comments are read-only."
                    continue
                }

                if ($statusProvided -and $requestedStatus -ne $originalStatus) {
                    $employeeRole = Get-EmployeeRoleByCode -EmployeeCode $employeeCode
                    if (-not (Test-CurrentUserCanApproveEmployeeRole -CurrentUser $currentUser -EmployeeRole $employeeRole)) {
                        respondWithError $response 403 "Only super admins can change the approval status of admin entries."
                        continue
                    }
                }

                $newExactPunchIn = if ($payload.newPunchIn) {
                    Convert-ToNormalizedTimeText -TimeText ([string]$payload.newPunchIn)
                }
                else {
                    Get-EntryExactPunchInText -Entry $existingEntry
                }

                if ([string]::IsNullOrWhiteSpace($newExactPunchIn)) {
                    respondWithError $response 400 "Punch In must use a valid time format."
                    continue
                }

                $newExactPunchOut = $null
                if ($payload.PSObject.Properties.Name -contains "punchOut") {
                    if ([string]::IsNullOrWhiteSpace([string]$payload.punchOut)) {
                        $newExactPunchOut = $null
                    }
                    else {
                        $newExactPunchOut = Convert-ToNormalizedTimeText -TimeText ([string]$payload.punchOut)
                        if ([string]::IsNullOrWhiteSpace($newExactPunchOut)) {
                            respondWithError $response 400 "Punch Out must use a valid time format."
                            continue
                        }
                    }
                }
                else {
                    $newExactPunchOut = Get-EntryExactPunchOutText -Entry $existingEntry
                }

                $newRoundedPunchIn = Convert-ToNearestQuarterHourText -Date $updatedEntryDate -TimeText $newExactPunchIn
                $newRoundedPunchOut = if ($newExactPunchOut) { Convert-ToNearestQuarterHourText -Date $updatedEntryDate -TimeText $newExactPunchOut } else { $null }

                $newCreditSummary = $null
                if ($newRoundedPunchOut) {
                    # Compare exact times instead of their rounded display
                    # values: a short completed interval is saved at 00:00 so
                    # it can be shown to a supervisor in Review.
                    $newCreditSummary = Get-QuarterHourCreditSummary -Date $updatedEntryDate -PunchIn $newExactPunchIn -PunchOut $newExactPunchOut
                    if (-not [bool]$newCreditSummary.isValid) {
                        respondWithError $response 400 "Punch Out must be after Punch In."
                        continue
                    }
                }

                if ($statusProvided -and $requestedStatus -ne "pending" -and -not $newRoundedPunchOut) {
                    respondWithError $response 400 "Open overtime sessions must be completed before they can be approved or rejected."
                    continue
                }

                $messages = @()
                if ($originalEntryDate -ne $updatedEntryDate) {
                    $messages += "Date from <strong>$originalEntryDate</strong> to <strong>$updatedEntryDate</strong>."
                }
                if ($originalRoundedPunchIn -ne $newRoundedPunchIn) {
                    $messages += "Punch In from <strong>$(Format-TimeForHistory $originalRoundedPunchIn)</strong> to <strong>$(Format-TimeForHistory $newRoundedPunchIn)</strong>."
                }

                if ($newRoundedPunchOut) {
                    if ($originalRoundedPunchOut -and $originalRoundedPunchOut -ne $newRoundedPunchOut) {
                        $messages += "Punch Out from <strong>$(Format-TimeForHistory $originalRoundedPunchOut)</strong> to <strong>$(Format-TimeForHistory $newRoundedPunchOut)</strong>."
                    }
                    elseif (-not $originalRoundedPunchOut) {
                        $messages += "Punch Out recorded at <strong>$(Format-TimeForHistory $newRoundedPunchOut)</strong>."
                    }
                }

                if ($existingEntryType -ne "diverse" -and $payload.PSObject.Properties.Name -contains "projectCode" -and $originalProjectCode -ne [string]$payload.projectCode) {
                    $messages += "Project Code updated."
                }

                if ($existingEntryType -ne "diverse" -and $payload.PSObject.Properties.Name -contains "overtimeCode" -and $originalOvertimeCode -ne [string]$payload.overtimeCode) {
                    $messages += "Overtime Code updated."
                }

                if ($existingEntryType -ne "diverse" -and $payload.PSObject.Properties.Name -contains "paymentOption" -and $originalPaymentOption -ne [string]$payload.paymentOption) {
                    $messages += "Payment option updated."
                }

                if ($existingEntryType -ne "diverse" -and $payload.PSObject.Properties.Name -contains "reasonCode" -and $originalReasonCode -ne [string]$payload.reasonCode) {
                    $messages += "Reason code updated."
                }

                if ($existingEntryType -eq "diverse" -and $payload.PSObject.Properties.Name -contains "diverseReason" -and $originalDiverseReason -ne [string]$payload.diverseReason) {
                    $messages += "Diverse reason updated."
                }

                if ($statusProvided -and $originalStatus -ne $requestedStatus) {
                    $messages += "Status changed from <strong>$originalStatus</strong> to <strong>$requestedStatus</strong>."
                }

                if ($workScheduleProvided -and $originalWorkSchedule -ne $requestedWorkSchedule) {
                    $messages += "Work schedule changed from <strong>$originalWorkSchedule</strong> to <strong>$requestedWorkSchedule</strong>."
                }

                Set-EntryPropertyValue -Entry $existingEntry -Name "date" -Value $updatedEntryDate
                $existingEntry.punchIn = $newRoundedPunchIn
                Set-EntryPropertyValue -Entry $existingEntry -Name "exactPunchIn" -Value $newExactPunchIn
                $existingEntry.punchOut = $newRoundedPunchOut
                Set-EntryPropertyValue -Entry $existingEntry -Name "exactPunchOut" -Value $newExactPunchOut
                if ($newRoundedPunchOut) {
                    Clear-EntryForgottenClockOutReview -Entry $existingEntry
                }
                if ($existingEntryType -ne "diverse" -and $payload.PSObject.Properties.Name -contains "projectCode") {
                    $existingEntry.projectCode = [string]$payload.projectCode
                }
                if ($existingEntryType -ne "diverse" -and $payload.PSObject.Properties.Name -contains "overtimeCode") {
                    Set-EntryPropertyValue -Entry $existingEntry -Name "overtimeCode" -Value ([string]$payload.overtimeCode)
                }
                if ($existingEntryType -ne "diverse" -and $payload.PSObject.Properties.Name -contains "paymentOption") {
                    Set-EntryPropertyValue -Entry $existingEntry -Name "paymentOption" -Value ([string]$payload.paymentOption)
                }
                if ($existingEntryType -ne "diverse" -and $payload.PSObject.Properties.Name -contains "reasonCode") {
                    Set-EntryPropertyValue -Entry $existingEntry -Name "reasonCode" -Value ([string]$payload.reasonCode)
                }
                if ($existingEntryType -eq "diverse") {
                    Set-EntryPropertyValue -Entry $existingEntry -Name "entryType" -Value "diverse"
                    Set-EntryPropertyValue -Entry $existingEntry -Name "projectCode" -Value ""
                    Set-EntryPropertyValue -Entry $existingEntry -Name "overtimeCode" -Value ""
                    Set-EntryPropertyValue -Entry $existingEntry -Name "paymentOption" -Value ""
                    Set-EntryPropertyValue -Entry $existingEntry -Name "reasonCode" -Value ""
                    if ($payload.PSObject.Properties.Name -contains "diverseReason") {
                        Set-EntryPropertyValue -Entry $existingEntry -Name "diverseReason" -Value ([string]$payload.diverseReason)
                    }
                }
                if ($statusProvided) {
                    $existingEntry.status = $requestedStatus
                }
                if ($workScheduleProvided -and $originalWorkSchedule -ne $requestedWorkSchedule) {
                    Set-EntryPropertyValue -Entry $existingEntry -Name "workSchedule" -Value $requestedWorkSchedule
                    Set-EntryPropertyValue -Entry $existingEntry -Name "workScheduleSource" -Value "supervisor-edit"
                }
                if ($replaceManagerMessage -and ([string]$existingEntry.message).Trim() -cne $managerMessage.Trim()) {
                    Set-EntrySupervisorNote -Entry $existingEntry -Note $managerMessage -CurrentUser $currentUser | Out-Null
                }
                if ($holidayScheduleProvided -and $existingEntryType -ne "diverse") {
                    Set-EntryPropertyValue -Entry $existingEntry -Name "holidayNotScheduledWorkday" -Value $payload.holidayNotScheduledWorkday
                    $messages += "IT holiday schedule confirmed or reset."
                }
                Update-EntryComputedOvertime -Entry $existingEntry
                if (Get-Command -Name Set-ApprovedEntryCompensationSnapshots -ErrorAction SilentlyContinue) {
                    Set-ApprovedEntryCompensationSnapshots -EmployeeCode $employeeCode -Entries $existingData | Out-Null
                }

                    Write-JsonArrayAtomic -Path $dataFile -Items $existingData -Depth 8
                    $entryMutationCommitted = $true
                    Release-ResourceLock -LockHandle $lockHandle
                    $lockHandle = $null
                    Release-ResourceLock -LockHandle $projectReferenceLockHandle
                    $projectReferenceLockHandle = $null

                    $historyWarning = Invoke-PostCommitActionSafely -Description "Entry update saved, but history logging failed" -Action {
                        $employeeName = Get-EmployeeName $employeeCode
                        $formattedDate = (Get-Date $updatedEntryDate).ToString("MMMM dd, yyyy")
                        $historySpan = Get-EntryHistorySpanText -StartTime ([string]$existingEntry.punchIn) -EndTime ([string]$existingEntry.punchOut)
                        if ($messages.Count -eq 0) {
                            $finalMessage = "Updated an entry on $formattedDate $historySpan."
                        }
                        else {
                            $finalMessage = "Updated an entry on $formattedDate $historySpan. " + ($messages -join " ")
                        }
                        logHistory "Update" $finalMessage $employeeName -PublishChange:$false
                    }
                    if (-not [string]::IsNullOrWhiteSpace($historyWarning)) {
                        [void]$postCommitWarnings.Add($historyWarning)
                    }
                }
                catch {
                    $entryMutationError = $_
                    throw
                }
                finally {
                    if ($entryMutationCommitted) {
                        $syncWarning = Invoke-PostCommitActionSafely -Description "Entry update saved, but cross-machine refresh publication failed" -Action {
                            Publish-DataChange -Category "employee" -Resource $employeeCode | Out-Null
                        }
                        if (-not [string]::IsNullOrWhiteSpace($syncWarning)) {
                            [void]$postCommitWarnings.Add($syncWarning)
                        }
                    }
                }

                respondWithSuccess $response (([PSCustomObject]@{
                    message = ($messages -join "<br>")
                    entryId = [string]$existingEntry.entryId
                    warnings = @($postCommitWarnings.ToArray())
                }) | ConvertTo-Json -Depth 4)
            }
            catch {
                Rethrow-HttpStatusException -Exception $_.Exception
                Write-Warning ("Unable to update employee entry: {0}" -f $_.Exception.Message)
                respondWithError $response 500 "Unable to update the employee entry."
            }
            finally {
                Release-ResourceLock -LockHandle $lockHandle
                Release-ResourceLock -LockHandle $projectReferenceLockHandle
            }
            continue
        }
