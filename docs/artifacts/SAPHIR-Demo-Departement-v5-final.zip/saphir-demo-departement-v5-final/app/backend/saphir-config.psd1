@{
    ListenerPrefix = "http://localhost:8095/"
    DataFolderPath = "../../data"
    Gc179LocalExportPath = "../../runtime/GC179"
    EnableDemoSeed = $false
    EnableGc179Import = $true
}